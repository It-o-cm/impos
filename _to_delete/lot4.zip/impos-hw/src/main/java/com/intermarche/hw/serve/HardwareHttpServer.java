package com.intermarche.hw.serve;

import java.io.IOException;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

/**
 * The HTTP transport of the hardware surface, on the JDK's own server — no dependency,
 * like the rest of this project.
 *
 * <p>One context is registered on {@code /api/hardware} and the routing happens inside:
 * the POS client addresses six fixed paths under that prefix, so a single dispatch keeps
 * the whole surface visible in one place, and anything outside it answers 404 rather than
 * silently matching a prefix.
 *
 * <p>The server owns no hardware: it turns a request into a call on
 * {@link HardwareEndpoints} and writes back the {@link HttpReply} it decided.
 */
public final class HardwareHttpServer {

    /** Path prefix of the whole hardware surface, as declared by the POS client. */
    static final String CONTEXT = "/api/hardware";

    /** Threads serving requests; the POS calls one at a time, a small pool is plenty. */
    private static final int THREADS = 4;

    /** The port to listen on. */
    private final int port;

    /** The endpoints deciding every answer. */
    private final HardwareEndpoints endpoints;

    /** Where the server narrates its lifecycle and refusals. */
    private final Consumer<String> log;

    /** The running server, or {@code null} before {@link #start()}. */
    private HttpServer server;

    /** The request executor, or {@code null} before {@link #start()}. */
    private ExecutorService executor;

    /**
     * Builds the server over the endpoints it will call.
     *
     * @param port      the TCP port to listen on
     * @param endpoints the endpoints deciding every answer
     * @param log       destination of the lifecycle log lines
     */
    public HardwareHttpServer(int port, HardwareEndpoints endpoints, Consumer<String> log) {
        this.port = port;
        this.endpoints = endpoints;
        this.log = log;
    }

    /**
     * Binds the port and starts serving.
     *
     * @throws IOException if the port cannot be bound
     */
    public void start() throws IOException {
        server = HttpServer.create(new InetSocketAddress(port), 0);
        executor = Executors.newFixedThreadPool(THREADS);
        server.setExecutor(executor);
        server.createContext(CONTEXT, this::handle);
        server.start();
    }

    /**
     * Stops serving and releases the port.
     */
    public void stop() {
        if (server != null) {
            server.stop(0);
            server = null;
        }
        if (executor != null) {
            executor.shutdownNow();
            executor = null;
        }
    }

    /**
     * The address the server listens on, for logs.
     *
     * @return the base URL of the hardware surface
     */
    public String baseUrl() {
        return "http://0.0.0.0:" + port + CONTEXT;
    }

    /**
     * Handles one request: routes it to an endpoint and writes the reply. Any failure
     * of the handler itself answers 500 rather than dropping the connection, which the
     * POS would otherwise see as a timeout.
     *
     * @param exchange the request being served
     * @throws IOException if the response cannot be written
     */
    private void handle(HttpExchange exchange) throws IOException {
        try {
            send(exchange, route(exchange));
        } catch (RuntimeException e) {
            log.accept("http         500 on " + exchange.getRequestURI().getPath() + ": " + e);
            send(exchange, HttpReply.error(500, "INTERNAL_ERROR"));
        } finally {
            exchange.close();
        }
    }

    /**
     * Chooses the endpoint for a request, by path then by method.
     *
     * @param exchange the request being served
     * @return the reply of the matching endpoint, 405 when the path exists under another
     *         method, 404 when it does not exist at all
     * @throws IOException if the request body cannot be read
     */
    private HttpReply route(HttpExchange exchange) throws IOException {
        String path = exchange.getRequestURI().getPath().substring(CONTEXT.length());
        String method = exchange.getRequestMethod();
        return switch (path) {
            case "/weight" -> get(method, endpoints::weight);
            case "/display" -> post(method, () -> endpoints.display(body(exchange)));
            case "/drawer/open" -> post(method, endpoints::openDrawer);
            case "/drawer/status" -> get(method, endpoints::drawerStatus);
            case "/printer/print" -> post(method, () -> endpoints.printTicket(body(exchange)));
            case "/printer/cut" -> post(method, endpoints::cutPaper);
            default -> notFound(exchange);
        };
    }

    /**
     * Applies an endpoint when the request is a GET.
     *
     * @param method   the request method
     * @param endpoint the endpoint to apply
     * @return the endpoint's reply, or 405
     */
    private HttpReply get(String method, java.util.function.Supplier<HttpReply> endpoint) {
        return "GET".equals(method) ? endpoint.get() : HttpReply.error(405, "METHOD_NOT_ALLOWED");
    }

    /**
     * Applies an endpoint when the request is a POST.
     *
     * @param method   the request method
     * @param endpoint the endpoint to apply
     * @return the endpoint's reply, or 405
     * @throws IOException if the endpoint had to read the body and could not
     */
    private HttpReply post(String method, BodyEndpoint endpoint) throws IOException {
        return "POST".equals(method) ? endpoint.apply() : HttpReply.error(405, "METHOD_NOT_ALLOWED");
    }

    /**
     * Answers an unknown path, naming it so a contract drift is visible in the log
     * instead of being read as a hardware failure.
     *
     * @param exchange the request being served
     * @return 404
     */
    private HttpReply notFound(HttpExchange exchange) {
        log.accept("http         404 " + exchange.getRequestMethod() + " "
                + exchange.getRequestURI().getPath());
        return HttpReply.error(404, "NOT_FOUND");
    }

    /**
     * Reads the request body as UTF-8 text.
     *
     * @param exchange the request being served
     * @return the body text, empty when there is none
     * @throws IOException if the body cannot be read
     */
    private String body(HttpExchange exchange) throws IOException {
        try (InputStream in = exchange.getRequestBody()) {
            return new String(in.readAllBytes(), StandardCharsets.UTF_8);
        }
    }

    /**
     * Writes a reply.
     *
     * @param exchange the request being served
     * @param reply    the reply to write
     * @throws IOException if the response cannot be written
     */
    private void send(HttpExchange exchange, HttpReply reply) throws IOException {
        if (reply.contentType() == null) {
            exchange.sendResponseHeaders(reply.status(), -1);
            return;
        }
        byte[] body = reply.bodyBytes();
        exchange.getResponseHeaders().set("Content-Type", reply.contentType());
        exchange.sendResponseHeaders(reply.status(), body.length);
        exchange.getResponseBody().write(body);
    }

    /**
     * An endpoint that may need to read the request body.
     */
    @FunctionalInterface
    private interface BodyEndpoint {

        /**
         * Applies the endpoint.
         *
         * @return its reply
         * @throws IOException if the body cannot be read
         */
        HttpReply apply() throws IOException;
    }
}

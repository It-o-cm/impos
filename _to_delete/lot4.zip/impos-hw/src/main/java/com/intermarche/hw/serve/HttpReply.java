package com.intermarche.hw.serve;

import java.nio.charset.StandardCharsets;

/**
 * One HTTP answer of the hardware surface, decided by {@link HardwareEndpoints}
 * and written by {@link HardwareHttpServer}.
 *
 * <p>Keeping the decision (what to answer) apart from the transport (how to write it)
 * is what makes every endpoint a pure, testable method: the endpoints never touch an
 * {@code HttpExchange}.
 *
 * @param status      the HTTP status code
 * @param contentType the response content type, or {@code null} for a body-less answer
 * @param body        the response body, empty for a body-less answer
 */
public record HttpReply(int status, String contentType, String body) {

    /** Content type of every textual answer of this surface. */
    private static final String TEXT_PLAIN = "text/plain; charset=utf-8";

    /**
     * A 200 carrying a plain-text body — the answer of the two reading endpoints
     * ({@code GET /weight}, {@code GET /drawer/status}), whose POS-side client
     * declares a {@code String} return.
     *
     * @param body the text to return
     * @return the reply
     */
    public static HttpReply text(String body) {
        return new HttpReply(200, TEXT_PLAIN, body);
    }

    /**
     * A 204 with no body — the answer of the acting endpoints (display, drawer
     * open, print, cut), whose POS-side client declares {@code void}.
     *
     * @return the reply
     */
    public static HttpReply done() {
        return new HttpReply(204, null, "");
    }

    /**
     * An error answer carrying a machine-readable code, so the POS log names the
     * cause rather than an anonymous status.
     *
     * @param status the HTTP status code
     * @param code   the error code, e.g. {@code NO_DEVICE_BOUND}
     * @return the reply
     */
    public static HttpReply error(int status, String code) {
        return new HttpReply(status, TEXT_PLAIN, code);
    }

    /**
     * The body encoded for the wire.
     *
     * @return the UTF-8 bytes of the body
     */
    public byte[] bodyBytes() {
        return body.getBytes(StandardCharsets.UTF_8);
    }
}

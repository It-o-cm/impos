package com.intermarche.hw.serve;

import java.io.IOException;
import java.nio.file.Path;
import java.time.Duration;
import java.util.function.Consumer;

import com.intermarche.hw.driver.EscPosPrinter;
import com.intermarche.hw.driver.ReceiptPrinter;

/**
 * The hardware surface the POS calls, one method per endpoint of its rest client.
 *
 * <p>The contract is not defined here: it belongs to impos, whose
 * {@code @RegisterRestClient} hardware client declares exactly six calls under
 * {@code /api/hardware} — {@code GET /weight}, {@code POST /display},
 * {@code POST /drawer/open}, {@code GET /drawer/status}, {@code POST /printer/print},
 * {@code POST /printer/cut}. This class answers those six and nothing else: the
 * extra endpoints of the POS test double (set-weight, drawer/close, printer/content,
 * printer/status, tpe) exist for its simulator page and are never called on a real
 * hardware bridge.
 *
 * <p>Answers on this till, per the bindings proven on 2026-09-04:
 * <ul>
 *   <li><b>printer</b> — real: ESC/POS on the node discovery picked. The node is opened
 *       for the request and released right after, so {@code printer-test} and the other
 *       commands can still open it between two receipts.</li>
 *   <li><b>drawer</b> — real, and it has no existence of its own: it hangs on the
 *       printer's drawer-kick connector, so the open order is an ESC/POS pulse on that
 *       connector and the state is the level of its pin 3. The polarity is not
 *       guessable and was measured with {@code drawer-test} on this park's wiring
 *       (pin low at rest, high once open); {@link #DRAWER_OPEN_HIGH} carries it. With
 *       no printer bound there is no drawer either, and both endpoints say so.</li>
 *   <li><b>display</b> — the Diebold Nixdorf BA9x is present but its protocol is not
 *       known, so the text is logged and the call answers 501.</li>
 *   <li><b>scale</b> — none on this till, so the weight answers 503
 *       {@code NO_DEVICE_BOUND}.</li>
 * </ul>
 * Any role with no device bound answers 503 {@code NO_DEVICE_BOUND}; a bound device that
 * fails answers 503 with its own code, so an absent peripheral and a broken one are never
 * confused in the POS log.
 */
public final class HardwareEndpoints {

    /** Error code of a role that has no device bound to it. */
    static final String NO_DEVICE_BOUND = "NO_DEVICE_BOUND";

    /** Error code of a bound printer that could not be reached. */
    static final String PRINTER_ERROR = "PRINTER_ERROR";

    /** Error code of the display, present on the bus but not driven yet. */
    static final String DISPLAY_NOT_IMPLEMENTED = "DISPLAY_NOT_IMPLEMENTED";

    /** Error code of a drawer whose printer connector could not be reached. */
    static final String DRAWER_ERROR = "DRAWER_ERROR";

    /** Drawer status the POS reads as "open"; anything else is closed. */
    static final String DRAWER_OPEN = "OPEN";

    /** Drawer status meaning the till may go on selling. */
    static final String DRAWER_CLOSED = "CLOSED";

    /**
     * Level of connector pin 3 that means "drawer open", as measured by
     * {@code drawer-test} on this park's wiring. It cannot be deduced: the same
     * level covers "closed" and "no drawer at all", and the micro-switch wiring
     * decides. The day a till differs, this comes from its binding.
     */
    static final boolean DRAWER_OPEN_HIGH = true;

    /** Connector output carrying the pulse: 0 for pin 2, 1 for pin 5. */
    private static final int DRAWER_OUTPUT = 0;

    /** Pulse high time, in units of 2 ms. */
    private static final int DRAWER_ON_TIME = 25;

    /** Pulse low time, in units of 2 ms. */
    private static final int DRAWER_OFF_TIME = 250;

    /** The printer node chosen by discovery, or {@code null} when none was bound. */
    private final Path printerNode;

    /** Reply timeout of the printer dialogue. */
    private final Duration timeout;

    /** Where the daemon narrates what it did, one line per call. */
    private final Consumer<String> log;

    /**
     * Builds the endpoints over the devices the daemon bound at startup.
     *
     * @param printerNode the receipt printer node, or {@code null} when discovery found none
     * @param timeout     reply timeout of the printer dialogue
     * @param log         destination of the per-call log lines
     */
    public HardwareEndpoints(Path printerNode, Duration timeout, Consumer<String> log) {
        this.printerNode = printerNode;
        this.timeout = timeout;
        this.log = log;
    }

    /**
     * Reads the scale — {@code GET /weight}.
     *
     * <p>No scale is bound on this till, so the call reports the role as unbound rather
     * than inventing a weight: a fabricated 0 would read as "nothing on the plate" and
     * hide the absence.
     *
     * @return 503 {@code NO_DEVICE_BOUND}
     */
    public HttpReply weight() {
        return HttpReply.error(503, NO_DEVICE_BOUND);
    }

    /**
     * Shows a text on the customer display — {@code POST /display}.
     *
     * <p>The BA9x is on the bus but its protocol is not known yet, so the text is logged
     * and the call answers "not implemented" rather than pretending to have displayed it.
     *
     * @param text the text the POS wants displayed
     * @return 501 {@code DISPLAY_NOT_IMPLEMENTED}
     */
    public HttpReply display(String text) {
        log.accept("display      (not implemented) " + text);
        return HttpReply.error(501, DISPLAY_NOT_IMPLEMENTED);
    }

    /**
     * Fires the drawer-opening pulse — {@code POST /drawer/open}.
     *
     * <p>The pulse travels on the printer's drawer-kick connector, the drawer having no
     * other electrical existence.
     *
     * @return 204 when the pulse was sent, 503 when no printer is bound or the pulse
     *         could not be written
     */
    public HttpReply openDrawer() {
        if (printerNode == null) {
            log.accept("drawer       open refused: no printer bound, so no drawer either");
            return HttpReply.error(503, NO_DEVICE_BOUND);
        }
        try (ReceiptPrinter printer = new EscPosPrinter(printerNode, timeout)) {
            printer.kickDrawer(DRAWER_OUTPUT, DRAWER_ON_TIME, DRAWER_OFF_TIME);
            log.accept("drawer       pulse sent on output " + DRAWER_OUTPUT);
            return HttpReply.done();
        } catch (IOException e) {
            log.accept("drawer       open failed: " + e.getMessage());
            return HttpReply.error(503, DRAWER_ERROR + ": " + e.getMessage());
        }
    }

    /**
     * Reads the drawer state — {@code GET /drawer/status}.
     *
     * <p>The connector reports one bit, the level of pin 3; {@link #DRAWER_OPEN_HIGH}
     * says which level means open on this wiring.
     *
     * @return 200 {@code OPEN} or {@code CLOSED}, 503 when no printer is bound or the
     *         connector could not be read
     */
    public HttpReply drawerStatus() {
        if (printerNode == null) {
            return HttpReply.error(503, NO_DEVICE_BOUND);
        }
        try (ReceiptPrinter printer = new EscPosPrinter(printerNode, timeout)) {
            boolean pinHigh = printer.status().drawerPinHigh();
            return HttpReply.text(pinHigh == DRAWER_OPEN_HIGH ? DRAWER_OPEN : DRAWER_CLOSED);
        } catch (IOException e) {
            log.accept("drawer       status failed: " + e.getMessage());
            return HttpReply.error(503, DRAWER_ERROR + ": " + e.getMessage());
        }
    }

    /**
     * Prints a receipt — {@code POST /printer/print}.
     *
     * @param content the 42-column text to print
     * @return 204 when printed, 503 when no printer is bound or the printer failed
     */
    public HttpReply printTicket(String content) {
        return onPrinter("print", printer -> printer.printText(content));
    }

    /**
     * Feeds to the cut position and cuts the paper — {@code POST /printer/cut}.
     *
     * @return 204 when cut, 503 when no printer is bound or the printer failed
     */
    public HttpReply cutPaper() {
        return onPrinter("cut", ReceiptPrinter::cut);
    }

    /**
     * Runs one action on the receipt printer, opening the node for the call and
     * releasing it right after.
     *
     * @param what   the action name, for the log line
     * @param action the action to run on the open printer
     * @return 204 on success, 503 when unbound or on an I/O failure
     */
    private HttpReply onPrinter(String what, PrinterAction action) {
        if (printerNode == null) {
            log.accept("printer      " + what + " refused: no printer bound");
            return HttpReply.error(503, NO_DEVICE_BOUND);
        }
        try (ReceiptPrinter printer = new EscPosPrinter(printerNode, timeout)) {
            action.run(printer);
            log.accept("printer      " + what + " on " + printerNode);
            return HttpReply.done();
        } catch (IOException e) {
            log.accept("printer      " + what + " failed: " + e.getMessage());
            return HttpReply.error(503, PRINTER_ERROR + ": " + e.getMessage());
        }
    }

    /**
     * One action performed on an open receipt printer.
     */
    @FunctionalInterface
    private interface PrinterAction {

        /**
         * Runs the action.
         *
         * @param printer the open printer
         * @throws IOException if the device cannot be written
         */
        void run(ReceiptPrinter printer) throws IOException;
    }
}

package com.intermarche.pos.ui.hardware;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.eclipse.microprofile.rest.client.inject.RestClient;
import org.jboss.logging.Logger;

/**
 * Facade over the hardware REST client, and the place where the register's
 * DEGRADED-MODE PHILOSOPHY lives — in two tiers, deliberately different:
 * <ul>
 *   <li>AT THE DOOR ({@link #probeDevices()}): unavailable hardware BLOCKS
 *       the register. The unlock gate probes the peripherals and refuses to
 *       open the lane while any is unreachable, showing which ones — a till
 *       must not start selling with no drawer and no printer behind it.</li>
 *   <li>MID-SALE (every other method): a peripheral call swallows its
 *       exceptions — a scale, display, drawer or printer dying DURING a sale
 *       is logged and never blocks the transaction in flight (the fiscal
 *       path cannot hostage-take on a cable). {@link #requestWeighing()}
 *       answers 0.0 on failure (callers treat it as "no weight"), and
 *       {@link #isDrawerOpen()} answers FALSE on failure so a broken drawer
 *       sensor cannot trap the register behind the drawer guard.</li>
 * </ul>
 */
@ApplicationScoped
public class HardwareService {

    private static final Logger LOGGER = Logger.getLogger(HardwareService.class);

    @Inject
    @RestClient
    HardwareClient hardwareClient;

    /**
     * One peripheral's availability as seen from the entry probe.
     *
     * @param name the operator-facing device name (French, upper case)
     * @param available true when the device answered its probe
     */
    public record DeviceStatus(String name, boolean available) {
    }

    /**
     * Probes the peripherals for the unlock gate and returns one status per
     * device. Read-only or harmless probes only: the scale is read
     * ({@code GET /weight}), the drawer sensor is read
     * ({@code GET /drawer/status}), the customer display is probed with the
     * idle greeting (what it shows anyway). The printer has no harmless
     * probe in the hardware contract (printing or cutting are physical
     * acts), so its status is inherited: unavailable when every probed
     * device is down (no hardware bridge at all), presumed available
     * otherwise — the day the bridge exposes {@code /printer/status}, probe
     * it here instead.
     *
     * @return the four device statuses, in display order
     */
    public java.util.List<DeviceStatus> probeDevices() {
        boolean scale = probe(() -> hardwareClient.getWeight());
        boolean drawer = probe(() -> hardwareClient.getDrawerStatus());
        boolean display = probe(() -> hardwareClient.setDisplay("BONJOUR"));
        boolean bridgeUp = scale || drawer || display;
        return java.util.List.of(
                new DeviceStatus("BALANCE", scale),
                new DeviceStatus("TIROIR-CAISSE", drawer),
                new DeviceStatus("AFFICHEUR CLIENT", display),
                new DeviceStatus("IMPRIMANTE TICKETS", bridgeUp));
    }

    /**
     * Runs one probe call, translating any failure into "unavailable"
     * without logging a stack trace — an unreachable device is the state
     * the probe exists to report, not an incident.
     *
     * @param call the client call to attempt
     * @return true when the call succeeded
     */
    private boolean probe(Runnable call) {
        try {
            call.run();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Requests a weighing from the scale, tolerating the French decimal
     * comma.
     *
     * @return the weight in kilograms, or 0.0 on any failure
     */
    public double requestWeighing() {
        try {
            String weightStr = hardwareClient.getWeight();
            return Double.parseDouble(weightStr.replace(',', '.'));
        } catch (Exception e) {
            LOGGER.error("Erreur de communication avec la balance", e);
            return 0.0;
        }
    }

    /**
     * Shows a message on the customer line display.
     *
     * @param message the message to display
     */
    public void displayMessage(String message) {
        try {
            hardwareClient.setDisplay(message);
        } catch (Exception e) {
            LOGGER.error("Erreur d'affichage", e);
        }
    }

    /**
     * Fires the drawer-opening pulse.
     */
    public void openDrawer() {
        try {
            hardwareClient.openDrawer();
            LOGGER.info("Ordre d'ouverture du tiroir envoyé.");
        } catch (Exception e) {
            LOGGER.error("Erreur lors de l'ouverture du tiroir", e);
        }
    }

    /**
     * Reads the physical drawer state for the drawer guard filter.
     *
     * @return true when the drawer answers OPEN; false otherwise, including
     *         on failure — a dead sensor never locks the register
     */
    public boolean isDrawerOpen() {
        try {
            String status = hardwareClient.getDrawerStatus();
            return "OPEN".equalsIgnoreCase(status);
        } catch (Exception e) {
            LOGGER.error("Erreur de communication avec le tiroir", e);
            return false; // Sécurité : en cas d'erreur, on ne bloque pas la caisse
        }
    }

    /**
     * Sends a formatted receipt to the printer.
     *
     * @param content the 42-column formatted text
     */
    public void printReceipt(String content) {
        try {
            hardwareClient.printTicket(content);
            LOGGER.info("Ticket envoyé à l'imprimante.");
        } catch (Exception e) {
            LOGGER.error("Erreur d'impression", e);
        }
    }

    /**
     * Cuts the printer paper.
     */
    public void cutPaper() {
        try {
            hardwareClient.cutPaper();
            LOGGER.info("Coupe papier envoyée.");
        } catch (Exception e) {
            LOGGER.error("Erreur coupe papier", e);
        }
    }
}

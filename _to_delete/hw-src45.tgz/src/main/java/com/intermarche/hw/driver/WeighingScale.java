package com.intermarche.hw.driver;

import java.io.IOException;

/**
 * What the POS needs from a checkout scale.
 *
 * <p>One method, and it takes a unit price: a checkout scale is not a sensor the till
 * reads at will, it is a legal instrument that weighs an ARTICLE. The price is part of
 * the request because the scale computes and displays the amount itself, on its own
 * certified display, and that display is what the customer is entitled to see.
 */
public interface WeighingScale extends AutoCloseable {

    /**
     * Weighs what is on the platter.
     *
     * @param unitPriceCents the article's unit price in cents, shown by the scale
     * @return the reading
     * @throws IOException if the scale cannot be reached or refuses the dialogue
     */
    Reading weigh(long unitPriceCents) throws IOException;

    /**
     * Releases the port.
     */
    @Override
    void close();

    /**
     * A dialogue that did not reach an answer, carrying what was exchanged.
     *
     * <p>An ordinary {@link IOException} loses the frames, and the frames are the whole
     * value of a failure here: they describe a scale model, or a wiring, that the driver
     * does not handle yet. Whoever catches this can print them.
     */
    class ExchangeFailed extends IOException {

        /** Serial version of this exception. */
        private static final long serialVersionUID = 1L;

        /** The frames exchanged before the failure. */
        private final transient java.util.List<String> frames;

        /**
         * Builds the failure.
         *
         * @param message what went wrong
         * @param frames  the frames exchanged before it went wrong
         */
        public ExchangeFailed(String message, java.util.List<String> frames) {
            super(message);
            this.frames = java.util.List.copyOf(frames);
        }

        /**
         * The frames exchanged before the failure.
         *
         * @return the frames, in order
         */
        public java.util.List<String> frames() {
            return frames;
        }
    }

    /**
     * One answer of the scale.
     *
     * @param grams          the net weight in grams, or {@code null} when the scale
     *                       answered something that carries no weight
     * @param status         the scale's own indicator, as it sent it
     * @param calculatedPrice the amount the scale computed and displayed, as it sent it
     * @param rawFrames      every frame exchanged, for the log and for the day a model
     *                       answers something this driver does not know yet
     */
    record Reading(Integer grams, String status, String calculatedPrice,
            java.util.List<String> rawFrames) {
    }
}

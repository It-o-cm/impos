package com.intermarche.hw.discovery;

import java.util.Set;

/**
 * A device node under {@code /dev} created by a kernel driver for a USB interface.
 *
 * @param kind          node family
 * @param devPath       absolute path of the node, e.g. {@code /dev/hidraw5}
 * @param byIdPath      stable {@code /dev/serial/by-id} link for TTY nodes, may be {@code null}
 * @param hidName       HID_NAME reported by the HID core, may be {@code null}
 * @param hidUsagePages usage pages found in the HID report descriptor, empty for non-HID nodes
 */
public record DeviceNode(
        Kind kind,
        String devPath,
        String byIdPath,
        String hidName,
        Set<Integer> hidUsagePages) {

    /** HID point-of-sale usage page (HID POS usage tables). */
    public static final int USAGE_PAGE_POS = 0x8C;
    /** IBM vendor usage page used by scanners and scales in IBM 46xx USB modes. */
    public static final int USAGE_PAGE_IBM_POS = 0xFF45;
    /** Generic desktop usage page (keyboards, mice). */
    public static final int USAGE_PAGE_GENERIC_DESKTOP = 0x01;

    /** Families of device nodes the discovery understands. */
    public enum Kind {
        /** Raw HID node, {@code /dev/hidrawN}. */
        HIDRAW,
        /** Serial TTY, {@code /dev/ttyACMn} or {@code /dev/ttyUSBn}. */
        TTY,
        /** USB printer node, {@code /dev/usb/lpN}. */
        LP
    }

    /**
     * Tells whether the report descriptor declares a vendor-defined usage page (0xFF00-0xFFFF).
     *
     * @return {@code true} if any usage page is vendor-defined
     */
    public boolean hasVendorUsagePage() {
        return hidUsagePages.stream().anyMatch(p -> p >= 0xFF00);
    }
}

package com.intermarche.hw.driver;

import java.io.IOException;
import java.time.Duration;
import java.time.Instant;

/**
 * Proves that a cash drawer is wired to the printer and learns its polarity.
 *
 * <p>The drawer-kick connector only reports the level of pin 3; that level is the same
 * for "drawer closed" and "no drawer at all", and which level means "open" depends on
 * how the drawer's micro-switch is wired. The only proof is dynamic: read the level,
 * send the pulse, watch the level change. The level observed after the pulse is, by
 * construction, the "open" level.
 *
 * <p>The probe physically opens the drawer, so it belongs to commissioning or to an
 * explicit operator request, never to a routine start-up.
 */
public final class DrawerProbe {

    /** Default pulse high time, 25 x 2 ms = 50 ms. */
    public static final int DEFAULT_ON_TIME = 25;
    /** Default pulse low time, 250 x 2 ms = 500 ms. */
    public static final int DEFAULT_OFF_TIME = 250;

    private static final Duration POLL_INTERVAL = Duration.ofMillis(100);

    private final ReceiptPrinter printer;
    private final Duration window;

    /**
     * Creates a probe on a printer.
     *
     * @param printer the printer the drawer hangs behind
     * @param window  how long to wait for the level to change after the pulse
     */
    public DrawerProbe(ReceiptPrinter printer, Duration window) {
        this.printer = printer;
        this.window = window;
    }

    /**
     * Runs the probe with the default pulse.
     *
     * @return the outcome
     * @throws IOException if the printer cannot be reached
     */
    public Result run() throws IOException {
        return run(0, DEFAULT_ON_TIME, DEFAULT_OFF_TIME);
    }

    /**
     * Runs the probe.
     *
     * @param output  connector output, 0 (pin 2) or 1 (pin 5)
     * @param onTime  pulse high time in units of 2 ms
     * @param offTime pulse low time in units of 2 ms
     * @return the outcome
     * @throws IOException if the printer cannot be reached
     */
    public Result run(int output, int onTime, int offTime) throws IOException {
        boolean before = printer.status().drawerPinHigh();
        Instant start = Instant.now();
        printer.kickDrawer(output, onTime, offTime);
        Instant deadline = start.plus(window);
        while (Instant.now().isBefore(deadline)) {
            sleep(POLL_INTERVAL);
            boolean now = printer.status().drawerPinHigh();
            if (now != before) {
                return new Result(true, before, now, Duration.between(start, Instant.now()));
            }
        }
        return new Result(false, before, before, window);
    }

    /**
     * Sleeps, converting an interruption into an early return.
     *
     * @param d the duration
     */
    private static void sleep(Duration d) {
        try {
            Thread.sleep(d.toMillis());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    /**
     * Outcome of a probe.
     *
     * @param detected   {@code true} when the pin level changed after the pulse
     * @param pinBefore  pin 3 level before the pulse
     * @param pinAfter   pin 3 level when the change was seen (equals {@code pinBefore} when not detected)
     * @param elapsed    time between the pulse and the change, or the full window when not detected
     */
    public record Result(boolean detected, boolean pinBefore, boolean pinAfter, Duration elapsed) {

        /**
         * Tells which pin level means "drawer open" once detected.
         *
         * @return {@code true} when a high level means open
         * @throws IllegalStateException when the drawer was not detected
         */
        public boolean openIsHigh() {
            if (!detected) {
                throw new IllegalStateException("Drawer not detected: polarity unknown");
            }
            return pinAfter;
        }
    }
}

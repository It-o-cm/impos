package com.intermarche.hw.driver;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * The magnetic line of a French cheque, split into its three zones.
 *
 * <p>This exists because the printer vendor's service does NOT split it the French way.
 * On a cheque read from this till it answered bank {@code 000}, branch
 * {@code 800000000909} and account {@code 000000000000}: the second zone handed back
 * whole under the wrong name, and a bank code invented out of nothing. Its READING is
 * trustworthy -- the raw line was exact -- so the reading is what is kept and the
 * splitting is done here.
 *
 * <p>The CMC7 standard puts three groups of digits between control symbols, which the
 * vendor transliterates into letters. The lengths are fixed and are what identifies the
 * zones:
 * <pre>
 * a0007639 a800000000909r 000000000000i
 *  |1|      |2|            |3|
 * 1: 7 digits  -- the cheque number
 * 2: 12 digits -- bank 5, branch 5, RLMC key 2
 * 3: 12 digits -- account 11, key 1
 * </pre>
 */
public record Cmc7Line(String cheque, String bank, String branch, String bankKey,
        String account, String accountKey) {

    /** Digits in the first zone: the cheque number. */
    private static final int CHEQUE_LENGTH = 7;

    /** Digits in the second and third zones. */
    private static final int ZONE_LENGTH = 12;

    /** Where the bank code ends and the branch code starts, in the second zone. */
    private static final int BANK_LENGTH = 5;

    /** Where the branch code ends and the RLMC key starts, in the second zone. */
    private static final int BRANCH_END = 10;

    /** Where the account number ends and its key starts, in the third zone. */
    private static final int ACCOUNT_LENGTH = 11;

    /**
     * Splits a magnetic line.
     *
     * <p>Nothing is guessed. A line whose three groups are not of the expected lengths
     * is REFUSED rather than cut at those offsets anyway: a cheque from another country,
     * a partial reading or a line the vendor transliterates differently would otherwise
     * yield a bank code and an account number that look perfectly plausible and are
     * wrong, which is the one outcome a payment must never have.
     *
     * @param raw the line as the reader gave it, control symbols included
     * @return the zones, or empty when the line is not a French cheque line
     */
    public static Optional<Cmc7Line> parse(String raw) {
        if (raw == null) {
            return Optional.empty();
        }
        List<String> groups = digitGroups(raw);
        if (groups.size() != 3
                || groups.get(0).length() != CHEQUE_LENGTH
                || groups.get(1).length() != ZONE_LENGTH
                || groups.get(2).length() != ZONE_LENGTH) {
            return Optional.empty();
        }
        String second = groups.get(1);
        String third = groups.get(2);
        return Optional.of(new Cmc7Line(groups.get(0),
                second.substring(0, BANK_LENGTH),
                second.substring(BANK_LENGTH, BRANCH_END),
                second.substring(BRANCH_END),
                third.substring(0, ACCOUNT_LENGTH),
                third.substring(ACCOUNT_LENGTH)));
    }

    /**
     * Collects the runs of digits of a line, in order.
     *
     * <p>Everything that is not a digit separates: the control symbols, the spaces the
     * vendor inserts, and whatever another vendor would insert instead. That is what
     * makes the splitting depend on the zone lengths alone rather than on one vendor's
     * choice of transliteration.
     *
     * @param raw the line
     * @return its groups of digits
     */
    private static List<String> digitGroups(String raw) {
        List<String> groups = new ArrayList<>();
        StringBuilder current = new StringBuilder();
        for (int i = 0; i < raw.length(); i++) {
            char c = raw.charAt(i);
            if (c >= '0' && c <= '9') {
                current.append(c);
                continue;
            }
            if (current.length() > 0) {
                groups.add(current.toString());
                current.setLength(0);
            }
        }
        if (current.length() > 0) {
            groups.add(current.toString());
        }
        return groups;
    }
}

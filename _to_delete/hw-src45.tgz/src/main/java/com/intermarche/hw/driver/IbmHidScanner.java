package com.intermarche.hw.driver;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.Arrays;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * {@link BarcodeScanner} for a scanner in IBM hand-held / table-top USB mode.
 *
 * <p>In that mode the scanner is a HID device on IBM's vendor usage page 0xFF45 and
 * every read is delivered as one input report on {@code /dev/hidrawN}. The report
 * format, as read off this till on 2026-09-08 from both a table-top scanner and a
 * hand-held one chained on its auxiliary port:
 * <pre>
 * 12 | 10 | 03 00 | 03 01 07 08 05 03 00 04 00 03 00 02 02 | 16          (table-top)
 * 14 | 10 | 03 00 | 32 33 30 34 37 39 36 30 31 30 30 30 36 | 00 ff 0b    (hand-held)
 * ln   typ  sym fl   the label                                trailer
 * </pre>
 * The FIRST byte is the total length of the report, padding excluded — not a report
 * id. It reads like one because a 13-digit EAN-13 report from the table-top scanner is
 * exactly 18 bytes long and 18 is 0x12; the hand-held's 40-byte GS1 report is the
 * counter-example that settles it. Reading it as an id made every label of another
 * length undecodable, the table-top scanner's own EAN-8 and Code 128 included.
 *
 * <p>The second byte is the message type, {@code 0x10} for a label. The label itself is
 * carried either as one binary digit per byte (table-top, numeric symbologies) or as
 * ASCII (hand-held), and ends either on a {@code 16} terminator or on a {@code 00}
 * followed by an {@code ff 0b} trailer. The decoder accepts both and reports what it
 * could not read rather than guessing.
 *
 * <p>The node is located by a supplier rather than fixed, because the kernel renumbers
 * {@code hidrawN} at every plug: the supplier resolves the device's stable identity to
 * its current node, and is asked again whenever the read fails.
 */
public final class IbmHidScanner implements BarcodeScanner {

    /** Message type of a label report, carried by the second byte. */
    static final int MESSAGE_TYPE_LABEL = 0x10;
    /** Terminator closing the label data of a table-top report. */
    static final int TERMINATOR = 0x16;
    /** First byte of the trailer closing a hand-held report. */
    private static final int TRAILER_FIRST = 0xFF;
    /** Second byte of the trailer closing a hand-held report. */
    private static final int TRAILER_SECOND = 0x0B;
    /** Separator a GS1 label carries between two application identifiers. */
    private static final int GROUP_SEPARATOR = 0x1D;
    private static final int REPORT_SIZE = 64;
    /** Index of the total length, of the message type, of the symbology, of the flags. */
    private static final int LENGTH_INDEX = 0;
    private static final int TYPE_INDEX = 1;
    private static final int SYMBOLOGY_INDEX = 2;
    /** Where the label itself starts: after length, type, symbology and flags. */
    private static final int PAYLOAD_START = 4;

    private final Supplier<Optional<Path>> nodeLocator;
    private final Duration retryDelay;
    private final Consumer<String> log;

    /**
     * Creates a scanner.
     *
     * @param nodeLocator resolves the current hidraw node of the scanner, empty when absent
     * @param retryDelay  wait between two attempts to find or reopen the node
     * @param log         receives lifecycle messages (node found, lost, undecodable report)
     */
    public IbmHidScanner(Supplier<Optional<Path>> nodeLocator, Duration retryDelay, Consumer<String> log) {
        this.nodeLocator = nodeLocator;
        this.retryDelay = retryDelay;
        this.log = log;
    }

    /** {@inheritDoc} */
    @Override
    public void run(Consumer<ScanEvent> listener) {
        while (!Thread.currentThread().isInterrupted()) {
            Optional<Path> node = nodeLocator.get();
            if (node.isEmpty()) {
                log.accept("scanner not present, waiting");
                sleep();
                continue;
            }
            log.accept("reading " + node.get());
            try (InputStream in = Files.newInputStream(node.get())) {
                readLoop(in, listener);
            } catch (IOException e) {
                log.accept("scanner lost (" + e.getMessage() + "), waiting for it to come back");
            }
            sleep();
        }
    }

    /**
     * Reads reports until the stream fails; each read returns one complete report.
     *
     * @param in       the open node
     * @param listener receives decoded scans
     * @throws IOException when the node fails, typically on unplug
     */
    private void readLoop(InputStream in, Consumer<ScanEvent> listener) throws IOException {
        byte[] buf = new byte[REPORT_SIZE];
        int n;
        while ((n = in.read(buf)) > 0) {
            byte[] report = Arrays.copyOf(buf, n);
            Optional<ScanEvent> event = decode(report);
            if (event.isPresent()) {
                listener.accept(event.get());
            } else {
                log.accept("undecodable report: " + new ScanEvent("", "", report).rawHex());
            }
        }
        throw new IOException("end of stream");
    }

    /**
     * Decodes one label report.
     *
     * @param report the raw report
     * @return the scan, or empty when the report is not a readable label
     */
    static Optional<ScanEvent> decode(byte[] report) {
        if (report.length <= PAYLOAD_START || (report[TYPE_INDEX] & 0xFF) != MESSAGE_TYPE_LABEL) {
            return Optional.empty();
        }
        int end = Math.min(report[LENGTH_INDEX] & 0xFF, report.length);
        end = trimTrailer(report, end);
        if (end <= PAYLOAD_START) {
            return Optional.empty();
        }
        byte[] data = Arrays.copyOfRange(report, PAYLOAD_START, end);
        String symbology = symbologyName(report[SYMBOLOGY_INDEX] & 0xFF);
        String code = allBinaryDigits(data) ? digitsToText(data) : asciiOrEmpty(data);
        if (code.isEmpty()) {
            return Optional.empty();
        }
        return Optional.of(new ScanEvent(code, symbology, report));
    }

    /**
     * Drops whatever closes the label, leaving the label alone.
     *
     * <p>Two endings exist and they cannot be told apart by looking for a NUL: in a
     * binary-digit label a {@code 00} byte is the digit zero, and there are three of
     * them in the very first report this driver ever decoded. So the hand-held's
     * {@code ff 0b} trailer is what identifies its ending, and only once it is found is
     * the {@code 00} before it read as a terminator.
     *
     * @param report the raw report
     * @param end    one past the last byte the length announces
     * @return one past the last byte of the label itself
     */
    private static int trimTrailer(byte[] report, int end) {
        if (end >= PAYLOAD_START + 2
                && (report[end - 2] & 0xFF) == TRAILER_FIRST
                && (report[end - 1] & 0xFF) == TRAILER_SECOND) {
            int trimmed = end - 2;
            return trimmed > PAYLOAD_START && report[trimmed - 1] == 0 ? trimmed - 1 : trimmed;
        }
        if (end > PAYLOAD_START && (report[end - 1] & 0xFF) == TERMINATOR) {
            return end - 1;
        }
        return end;
    }

    /**
     * Names a symbology byte. EAN-13 = 0x03 is observed; the others follow the IBM 4690
     * label-type numbering and are to be confirmed on the scanner.
     *
     * @param type the symbology byte
     * @return a name, or {@code IBM-0xNN} when unknown
     */
    private static String symbologyName(int type) {
        return switch (type) {
            case 0x01 -> "UPC-A";
            case 0x02 -> "UPC-E";
            case 0x03 -> "EAN-13";
            case 0x04 -> "EAN-8";
            default -> String.format("IBM-0x%02x", type);
        };
    }

    /**
     * Tells whether every byte is a binary digit 0-9.
     *
     * @param data the label bytes
     * @return {@code true} for a numeric label encoded one digit per byte
     */
    private static boolean allBinaryDigits(byte[] data) {
        for (byte b : data) {
            if (b < 0 || b > 9) {
                return false;
            }
        }
        return true;
    }

    /**
     * Converts binary digits to their text.
     *
     * @param data one digit per byte
     * @return the digit string
     */
    private static String digitsToText(byte[] data) {
        StringBuilder sb = new StringBuilder(data.length);
        for (byte b : data) {
            sb.append((char) ('0' + b));
        }
        return sb.toString();
    }

    /**
     * Accepts the bytes as text when they are all printable ASCII.
     *
     * @param data the label bytes
     * @return the text, or empty when a byte is not printable ASCII
     */
    private static String asciiOrEmpty(byte[] data) {
        for (byte b : data) {
            // The group separator is not printable but IS part of the label: a GS1
            // code carries it between two application identifiers, and dropping the
            // whole label because of it would lose every batch-and-date barcode.
            if ((b < 0x20 || b > 0x7E) && (b & 0xFF) != GROUP_SEPARATOR) {
                return "";
            }
        }
        return new String(data, java.nio.charset.StandardCharsets.US_ASCII);
    }

    /**
     * Waits the retry delay, ending the run loop on interruption.
     */
    private void sleep() {
        try {
            Thread.sleep(retryDelay.toMillis());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}

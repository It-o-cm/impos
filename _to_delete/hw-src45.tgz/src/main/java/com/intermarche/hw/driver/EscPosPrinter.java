package com.intermarche.hw.driver;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.ByteChannel;
import java.nio.channels.FileChannel;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.Duration;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/**
 * {@link ReceiptPrinter} speaking ESC/POS on a kernel printer node such as {@code /dev/usb/lp0}.
 *
 * <p>Only the subset common to the ESC/POS family is used (initialise, text, feed, cut,
 * drawer kick, real-time status, printer identification), so the class applies to Epson,
 * Bixolon, Citizen, Diebold Nixdorf TH and Star-in-emulation printers alike.
 *
 * <p>The node is opened once, read-write: {@code usblp} allows a single opener, so the
 * reply to a query must be read through the same descriptor that wrote it. A reply that
 * does not come within the timeout is detected by closing the channel from another
 * thread, which is the only way to abort a blocking read on a character device from
 * pure Java; the channel is reopened lazily on the next operation.
 */
public final class EscPosPrinter implements ReceiptPrinter {

    /** Opens the channel to the device; injectable so the dialect can be tested off-hardware. */
    @FunctionalInterface
    public interface ChannelOpener {
        /**
         * Opens a read-write channel to the printer.
         *
         * @return the channel
         * @throws IOException if the device cannot be opened
         */
        ByteChannel open() throws IOException;
    }

    private static final byte ESC = 0x1B;
    private static final byte GS = 0x1D;
    private static final byte DLE = 0x10;
    private static final byte EOT = 0x04;
    private static final byte[] INITIALIZE = {ESC, '@'};
    private static final byte[] CODE_PAGE_858 = {ESC, 't', 19};
    private static final byte[] FEED_AND_PARTIAL_CUT = {GS, 'V', 66, 0};

    /** Centre the following lines, then go back to the left. */
    private static final byte[] ALIGN_CENTRE = {ESC, 'a', 1};
    private static final byte[] ALIGN_LEFT = {ESC, 'a', 0};

    /** Print the barcode value under the bars, in the small font. */
    private static final byte[] HRI_BELOW = {GS, 'H', 2};
    private static final byte[] HRI_FONT_B = {GS, 'f', 1};

    /** Bar height in dots and bar width in dots. */
    private static final byte[] BARCODE_HEIGHT = {GS, 'h', 80};
    private static final byte[] BARCODE_WIDTH = {GS, 'w', 2};

    /**
     * Barcode symbology: CODE128, the only one that takes a ticket number as it is.
     *
     * <p>EAN and UPC would not: they are fixed-length and digits only, and a ticket
     * number carries letters and a dash. CODE128 data must announce its character set,
     * hence the {@code {B} prefix that starts the data.
     */
    private static final byte BARCODE_CODE128 = 73;

    /** Announces the CODE128 character set covering ASCII 32 to 127. */
    private static final byte[] CODE128_SET_B = {'{', 'B'};

    /** Raster image mode: normal size, no scaling. */
    private static final byte[] RASTER_NORMAL = {GS, 'v', '0', 0};

    /** Pixels packed in one byte of a raster row. */
    private static final int PIXELS_PER_BYTE = 8;

    /** Longest barcode data one label can carry, the command's length being one byte. */
    private static final int MAX_BARCODE_DATA = 255;
    private static final byte IDENTITY_HEADER = 0x5F;
    private static final int STATUS_BIT_DRAWER_PIN = 0x04;
    private static final int STATUS_BIT_OFFLINE = 0x08;
    private static final int OFFLINE_BIT_COVER_OPEN = 0x04;
    private static final int OFFLINE_BIT_ERROR = 0x40;
    private static final int PAPER_BITS_NEAR_END = 0x0C;
    private static final int PAPER_BITS_OUT = 0x60;
    private static final int MAX_IDENTITY_LENGTH = 80;
    private static final Duration EMPTY_READ_PAUSE = Duration.ofMillis(20);

    private final ChannelOpener opener;
    private final Duration timeout;
    private final Charset charset;
    private ByteChannel channel;

    /**
     * Creates a printer on a device node.
     *
     * @param node    the printer node, e.g. {@code /dev/usb/lp0}
     * @param timeout maximum wait for a reply to a query
     */
    public EscPosPrinter(Path node, Duration timeout) {
        this(() -> FileChannel.open(node, StandardOpenOption.READ, StandardOpenOption.WRITE), timeout);
    }

    /**
     * Creates a printer on an arbitrary channel source.
     *
     * @param opener  opens the channel on demand
     * @param timeout maximum wait for a reply to a query
     */
    public EscPosPrinter(ChannelOpener opener, Duration timeout) {
        this.opener = opener;
        this.timeout = timeout;
        this.charset = Charset.isSupported("IBM00858") ? Charset.forName("IBM00858") : StandardCharsets.US_ASCII;
    }

    /**
     * {@inheritDoc}
     *
     * <p>Uses {@code GS I 66} and {@code GS I 67}, whose replies are framed as
     * {@code 5F <string> 00}.
     */
    @Override
    public PrinterIdentity identify() throws IOException {
        String manufacturer = queryString(new byte[] {GS, 'I', 66});
        String model = queryString(new byte[] {GS, 'I', 67});
        return new PrinterIdentity(manufacturer, model);
    }

    /**
     * {@inheritDoc}
     *
     * <p>Reads {@code DLE EOT 1} (printer), {@code DLE EOT 2} (offline cause) and
     * {@code DLE EOT 4} (paper sensors), one byte each.
     */
    @Override
    public PrinterStatus status() throws IOException {
        int printer = queryByte(new byte[] {DLE, EOT, 1});
        int offline = queryByte(new byte[] {DLE, EOT, 2});
        int paper = queryByte(new byte[] {DLE, EOT, 4});
        return new PrinterStatus(
                (printer & STATUS_BIT_OFFLINE) == 0,
                (offline & OFFLINE_BIT_COVER_OPEN) != 0,
                (paper & PAPER_BITS_NEAR_END) == PAPER_BITS_NEAR_END,
                (paper & PAPER_BITS_OUT) == PAPER_BITS_OUT,
                (offline & OFFLINE_BIT_ERROR) != 0,
                (printer & STATUS_BIT_DRAWER_PIN) != 0);
    }

    /**
     * {@inheritDoc}
     *
     * <p>Selects code page 858 first so accented characters print correctly.
     */
    @Override
    public void printText(String text) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        out.writeBytes(INITIALIZE);
        out.writeBytes(CODE_PAGE_858);
        out.writeBytes(text.getBytes(charset));
        write(out.toByteArray());
    }

    /**
     * {@inheritDoc}
     *
     * <p>Sends {@code GS k 73}, whose data is length-prefixed rather than
     * NUL-terminated — the older {@code GS k m d1..dn NUL} form cannot carry a value
     * containing a NUL and is not what CODE128 expects.
     */
    @Override
    public void printBarcode(String value) throws IOException {
        byte[] data = value.getBytes(java.nio.charset.StandardCharsets.US_ASCII);
        int length = CODE128_SET_B.length + data.length;
        if (length > MAX_BARCODE_DATA) {
            throw new IOException("barcode value too long for one label: " + value);
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        out.writeBytes(ALIGN_CENTRE);
        out.writeBytes(HRI_BELOW);
        out.writeBytes(HRI_FONT_B);
        out.writeBytes(BARCODE_HEIGHT);
        out.writeBytes(BARCODE_WIDTH);
        out.writeBytes(new byte[] {GS, 'k', BARCODE_CODE128, (byte) length});
        out.writeBytes(CODE128_SET_B);
        out.writeBytes(data);
        out.writeBytes(ALIGN_LEFT);
        write(out.toByteArray());
    }

    /**
     * {@inheritDoc}
     *
     * <p>Sends {@code GS v 0}, whose header counts BYTES per row and ROWS, not pixels.
     */
    @Override
    public void printImage(int width, int height, byte[] bits) throws IOException {
        int bytesPerRow = (width + PIXELS_PER_BYTE - 1) / PIXELS_PER_BYTE;
        if (bytesPerRow * height != bits.length) {
            throw new IOException("image is " + bits.length + " bytes, expected "
                    + bytesPerRow * height + " for " + width + "x" + height);
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        out.writeBytes(ALIGN_CENTRE);
        out.writeBytes(RASTER_NORMAL);
        out.writeBytes(new byte[] {(byte) bytesPerRow, (byte) (bytesPerRow >> 8),
                (byte) height, (byte) (height >> 8)});
        out.writeBytes(bits);
        out.writeBytes(ALIGN_LEFT);
        write(out.toByteArray());
    }

    /** {@inheritDoc} */
    @Override
    public void feed(int lines) throws IOException {
        write(new byte[] {ESC, 'd', (byte) clamp(lines)});
    }

    /** {@inheritDoc} */
    @Override
    public void cut() throws IOException {
        write(FEED_AND_PARTIAL_CUT);
    }

    /**
     * {@inheritDoc}
     *
     * <p>Sends {@code ESC p m t1 t2}.
     */
    @Override
    public void kickDrawer(int output, int onTime, int offTime) throws IOException {
        write(new byte[] {ESC, 'p', (byte) (output == 0 ? 0 : 1), (byte) clamp(onTime), (byte) clamp(offTime)});
    }

    /** {@inheritDoc} */
    @Override
    public void close() {
        ByteChannel c = channel;
        channel = null;
        if (c != null) {
            try {
                c.close();
            } catch (IOException ignored) {
                // Nothing useful can be done with a failed close on a character device.
            }
        }
    }

    /**
     * Sends a query and reads a single reply byte.
     *
     * @param command the command
     * @return the reply byte
     * @throws IOException if the printer does not answer in time
     */
    private int queryByte(byte[] command) throws IOException {
        byte[] reply = query(command, 1, false);
        if (reply.length == 0) {
            throw new IOException("Printer sent an empty reply");
        }
        return reply[0] & 0xFF;
    }

    /**
     * Sends a query whose reply is a NUL-terminated string with a {@code 5F} header.
     *
     * @param command the command
     * @return the string, header and terminator stripped
     * @throws IOException if the printer does not answer in time
     */
    private String queryString(byte[] command) throws IOException {
        byte[] reply = query(command, MAX_IDENTITY_LENGTH, true);
        int start = reply.length > 0 && reply[0] == IDENTITY_HEADER ? 1 : 0;
        int end = start;
        while (end < reply.length && reply[end] != 0) {
            end++;
        }
        return new String(reply, start, end - start, StandardCharsets.US_ASCII);
    }

    /**
     * Writes a command and collects its reply.
     *
     * @param command      the command
     * @param maxLength    upper bound of the reply length
     * @param untilNul     {@code true} to stop at the first NUL, {@code false} to stop at one byte
     * @return the raw reply
     * @throws IOException if the reply does not arrive within the timeout
     */
    private byte[] query(byte[] command, int maxLength, boolean untilNul) throws IOException {
        ByteChannel c = channel();
        c.write(ByteBuffer.wrap(command));
        ExecutorService reader = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "escpos-reader");
            t.setDaemon(true);
            return t;
        });
        try {
            Future<byte[]> future = reader.submit(() -> readReply(c, maxLength, untilNul));
            return future.get(timeout.toMillis(), TimeUnit.MILLISECONDS);
        } catch (TimeoutException e) {
            close();
            throw new IOException("Printer did not answer within " + timeout.toMillis() + " ms");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            close();
            throw new IOException("Interrupted while waiting for the printer", e);
        } catch (ExecutionException e) {
            close();
            throw new IOException("Printer read failed", e.getCause());
        } finally {
            reader.shutdownNow();
        }
    }

    /**
     * Reads a reply from the channel; runs on the reader thread.
     *
     * <p>A read returning no byte is not the end of the reply: {@code usblp} hands back
     * zero-length reads when the printer has not answered yet or sent an empty packet.
     * The loop keeps polling until bytes arrive or the caller's timeout closes the
     * channel, which surfaces here as an exception.
     *
     * @param c         the channel
     * @param maxLength upper bound of the reply length
     * @param untilNul  {@code true} to stop at the first NUL
     * @return the bytes read
     * @throws IOException if the channel fails or is closed by the timeout
     */
    private static byte[] readReply(ByteChannel c, int maxLength, boolean untilNul) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        ByteBuffer buf = ByteBuffer.allocate(64);
        while (out.size() < maxLength) {
            buf.clear();
            int n = c.read(buf);
            if (n <= 0) {
                try {
                    Thread.sleep(EMPTY_READ_PAUSE.toMillis());
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    throw new IOException("Interrupted while waiting for the printer reply", e);
                }
                continue;
            }
            buf.flip();
            while (buf.hasRemaining()) {
                byte b = buf.get();
                out.write(b);
                if (!untilNul || b == 0) {
                    return out.toByteArray();
                }
            }
        }
        return out.toByteArray();
    }

    /**
     * Writes raw bytes to the printer.
     *
     * @param bytes the bytes
     * @throws IOException if the device cannot be written
     */
    private void write(byte[] bytes) throws IOException {
        ByteBuffer buf = ByteBuffer.wrap(bytes);
        ByteChannel c = channel();
        while (buf.hasRemaining()) {
            c.write(buf);
        }
    }

    /**
     * Returns the open channel, opening it on first use or after a timeout closed it.
     *
     * @return the channel
     * @throws IOException if the device cannot be opened
     */
    private ByteChannel channel() throws IOException {
        if (channel == null || !channel.isOpen()) {
            channel = opener.open();
        }
        return channel;
    }

    /**
     * Clamps a parameter to the 1..255 range ESC/POS accepts.
     *
     * @param value the requested value
     * @return the clamped value
     */
    private static int clamp(int value) {
        return Math.max(1, Math.min(255, value));
    }
}

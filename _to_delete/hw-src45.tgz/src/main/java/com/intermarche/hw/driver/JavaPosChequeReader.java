package com.intermarche.hw.driver;

import java.io.IOException;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;

/**
 * A cheque reader driven through the printer vendor's own JavaPOS service.
 *
 * <p>Same choice as for the payment terminal, for the same reason: the vendor ships a
 * service that already knows how to wait for a document, pull it in, drive the magnetic
 * head, decode the French CMC7 line and report the twenty ways it can fail. Rewriting
 * that from guessed ESC/POS bytes would be slower to build and worse. Here the service
 * is Epson's, installed on the till, configured for CMC7.
 *
 * <p>EVERYTHING IS REFLECTION, and that is deliberate: this project compiles against
 * nothing, and the vendor's jars live on the till rather than in the build. They are
 * loaded from their install directory at run time, exactly as the payment client's
 * shared library is. The cost is this file; the benefit is that the daemon still builds
 * and runs on a machine that has no JavaPOS at all.
 *
 * <p>ONE LAUNCH CONSTRAINT the code cannot fix by itself: the service loads a native
 * library, and {@code java.library.path} is read once when the JVM starts. The daemon
 * must therefore be launched with {@code -Djava.library.path=<install>/bin}. Setting
 * the property from here would be silently ignored.
 */
public final class JavaPosChequeReader implements ChequeReader {

    /** JavaPOS result code meaning "look at the extended code". */
    private static final int EXTENDED = 114;

    /** Extended codes of the cheque reader, as its own constants name them. */
    private static final int NO_CHECK = 201;
    private static final int CHECK_PRESENT = 202;
    private static final int BAD_DATA = 203;
    private static final int NO_DATA = 204;
    private static final int BAD_SIZE = 205;
    private static final int JAM = 206;
    private static final int CHECK_DIGIT = 207;
    private static final int COVER_OPEN = 208;

    /** How long to wait for the reading once the document is in, in seconds. */
    private static final int READ_TIMEOUT_SECONDS = 60;

    /** How long to wait for the exclusive claim on the device, in milliseconds. */
    private static final int CLAIM_TIMEOUT = 5000;

    /** Property naming the file the JavaPOS loader reads its devices from. */
    private static final String CONFIG_PROPERTY = "jpos.config.populatorFile";

    /** Property naming the loader that reads that file. */
    private static final String LOADER_PROPERTY = "jpos.config.regPopulatorClass";

    /** The loader that reads an XML device file. */
    private static final String XML_LOADER = "jpos.config.simple.xml.SimpleXmlRegPopulator";

    /** Where the reader narrates what it does. */
    private final Consumer<String> log;

    /** The vendor's classes, loaded from their install directory. */
    private final URLClassLoader vendor;

    /** The vendor's {@code jpos.MICR} instance. */
    private final Object micr;

    /** Its class, kept so every call is made on the right one. */
    private final Class<?> micrClass;

    /** Counts down when the service has read a document or reported a failure. */
    private volatile CountDownLatch done = new CountDownLatch(1);

    /** The extended code of the last failure, zero when the last read succeeded. */
    private final AtomicInteger failure = new AtomicInteger();

    /**
     * Opens the vendor's service and takes the reader.
     *
     * @param installDirectory the vendor's install directory, holding {@code lib}
     * @param configFile       the JavaPOS device file declaring the reader
     * @param logicalName      the reader's logical name in that file
     * @param log              destination of the log lines
     * @throws IOException if the vendor's classes are missing, or the service refuses
     */
    public JavaPosChequeReader(Path installDirectory, Path configFile, String logicalName,
            Consumer<String> log) throws IOException {
        this.log = log;
        System.setProperty(CONFIG_PROPERTY, configFile.toAbsolutePath().toString());
        System.setProperty(LOADER_PROPERTY, XML_LOADER);
        this.vendor = new URLClassLoader(jars(installDirectory.resolve("lib")),
                JavaPosChequeReader.class.getClassLoader());
        try {
            this.micrClass = vendor.loadClass("jpos.MICR");
            this.micr = micrClass.getDeclaredConstructor().newInstance();
            listen("addDataListener", "jpos.events.DataListener");
            listen("addErrorListener", "jpos.events.ErrorListener");
            log.accept("cheque       ouverture de " + logicalName);
            call("open", new Class<?>[] {String.class}, logicalName);
            call("claim", new Class<?>[] {int.class}, CLAIM_TIMEOUT);
            call("setDeviceEnabled", new Class<?>[] {boolean.class}, true);
            call("setDataEventEnabled", new Class<?>[] {boolean.class}, true);
        } catch (ReflectiveOperationException e) {
            closeQuietly();
            throw new IOException("the vendor's cheque service could not be opened: " + e, e);
        }
    }

    /** {@inheritDoc} */
    @Override
    public Reading read(Duration insertionTimeout) throws IOException {
        done = new CountDownLatch(1);
        failure.set(0);
        try {
            log.accept("cheque       en attente du cheque ("
                    + insertionTimeout.toSeconds() + " s)");
            call("beginInsertion", new Class<?>[] {int.class}, (int) insertionTimeout.toMillis());
            call("endInsertion", new Class<?>[] {}, new Object[0]);
            if (!done.await(READ_TIMEOUT_SECONDS, TimeUnit.SECONDS)) {
                throw new IOException("the reader answered nothing within "
                        + READ_TIMEOUT_SECONDS + " s");
            }
            int code = failure.get();
            if (code != 0) {
                throw new IOException(describe(code));
            }
            String raw = text("getRawData");
            log.accept("cheque       " + raw);
            // The vendor's own parsing is NOT the French layout: on this till it named
            // the whole second zone "branch" and invented a three-digit bank code. Its
            // reading is exact, so the reading is kept and the splitting redone; when
            // the line is not a French one, its fields are all that is left.
            return Cmc7Line.parse(raw)
                    .map(line -> new Reading(raw, line.account(), line.bank(), line.branch(),
                            line.cheque()))
                    .orElseGet(() -> vendorReading(raw));
        } catch (ReflectiveOperationException e) {
            throw new IOException("the cheque exchange failed: " + e, e);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException("the cheque exchange was interrupted", e);
        } finally {
            giveBack(insertionTimeout);
        }
    }

    /** {@inheritDoc} */
    @Override
    public void close() {
        closeQuietly();
    }

    /**
     * Falls back on what the vendor parsed, for a line this driver cannot split.
     *
     * <p>Its fields are approximate on a French cheque, but a line that is not one --
     * another country, another transliteration -- is better reported as the vendor read
     * it than not at all. A failure to read every property leaves the fields empty: the
     * raw line is the part that matters and it is already in hand.
     *
     * @param raw the line as read
     * @return the reading
     */
    private Reading vendorReading(String raw) {
        try {
            return new Reading(raw, text("getAccountNumber"), text("getBankNumber"),
                    text("getTransitNumber"), text("getSerialNumber"));
        } catch (ReflectiveOperationException e) {
            log.accept("cheque       champs du service illisibles: " + e);
            return new Reading(raw, "", "", "", "");
        }
    }

    /**
     * Gives the document back, whatever happened to the reading.
     *
     * <p>In a {@code finally} on purpose: a cheque left inside the printer blocks the
     * next customer, and a failed read is exactly when that is most likely to happen.
     *
     * @param timeout how long the operator has to take it back
     */
    private void giveBack(Duration timeout) {
        try {
            call("beginRemoval", new Class<?>[] {int.class}, (int) timeout.toMillis());
            call("endRemoval", new Class<?>[] {}, new Object[0]);
        } catch (ReflectiveOperationException e) {
            log.accept("cheque       le document n'a pas pu etre rendu: " + e);
        }
    }

    /**
     * Registers a proxy on one of the service's listener interfaces.
     *
     * <p>The interfaces belong to the vendor's classes, so an implementation of them
     * cannot be written here; a dynamic proxy is the only way to hand the service
     * something it accepts.
     *
     * @param adder     the name of the method registering the listener
     * @param interfaceName the listener interface to implement
     * @throws ReflectiveOperationException if the class or the method is missing
     */
    private void listen(String adder, String interfaceName) throws ReflectiveOperationException {
        Class<?> listener = vendor.loadClass(interfaceName);
        Object proxy = Proxy.newProxyInstance(vendor, new Class<?>[] {listener}, handler());
        micrClass.getMethod(adder, listener).invoke(micr, proxy);
    }

    /**
     * The behaviour of both listeners: record the outcome and release the wait.
     *
     * @return the handler
     */
    private InvocationHandler handler() {
        return (proxy, method, args) -> {
            if (args != null && args.length == 1 && method.getName().startsWith("error")) {
                failure.set(extendedCode(args[0]));
            }
            if (method.getName().startsWith("data") || method.getName().startsWith("error")) {
                done.countDown();
            }
            return null;
        };
    }

    /**
     * Reads the extended code out of an error event.
     *
     * @param event the vendor's error event
     * @return the extended code, or -1 when it cannot be read
     */
    private int extendedCode(Object event) {
        try {
            return (int) event.getClass().getMethod("getErrorCodeExtended").invoke(event);
        } catch (ReflectiveOperationException e) {
            return -1;
        }
    }

    /**
     * Names a failure of the reader.
     *
     * <p>The distinction matters at the till: "no magnetic data" is not a breakdown, it
     * is what a photocopy or a specimen answers, and the cashier must be told to use a
     * real cheque rather than to call support.
     *
     * @param code the extended code
     * @return the failure, in French, as the operator should read it
     */
    private static String describe(int code) {
        return switch (code) {
            case NO_CHECK -> "aucun document dans le lecteur";
            case CHECK_PRESENT -> "un document est deja dans le lecteur";
            case BAD_DATA -> "ligne magnetique illisible";
            case NO_DATA -> "aucune donnee magnetique: document sans encre magnetique";
            case BAD_SIZE -> "format de document non gere";
            case JAM -> "bourrage dans le lecteur";
            case CHECK_DIGIT -> "cle de controle de la ligne magnetique invalide";
            case COVER_OPEN -> "capot ouvert";
            case EXTENDED -> "echec du lecteur sans code etendu";
            default -> "echec du lecteur, code " + code;
        };
    }

    /**
     * Reads one String property of the service.
     *
     * @param getter the property's getter
     * @return its value, empty when it is null
     * @throws ReflectiveOperationException if the getter is missing or fails
     */
    private String text(String getter) throws ReflectiveOperationException {
        Object value = micrClass.getMethod(getter).invoke(micr);
        return value == null ? "" : value.toString();
    }

    /**
     * Calls one method of the service.
     *
     * @param name       the method name
     * @param signature  its parameter types
     * @param arguments  its arguments
     * @throws ReflectiveOperationException if the method is missing or fails
     */
    private void call(String name, Class<?>[] signature, Object... arguments)
            throws ReflectiveOperationException {
        micrClass.getMethod(name, signature).invoke(micr, arguments);
    }

    /**
     * Releases the device and the vendor's classes, reporting nothing.
     *
     * <p>Closing is a best effort by nature: it runs when something has already gone
     * wrong, and a failure to release must not hide the failure that caused it.
     */
    private void closeQuietly() {
        try {
            call("setDeviceEnabled", new Class<?>[] {boolean.class}, false);
            call("release", new Class<?>[] {}, new Object[0]);
            call("close", new Class<?>[] {}, new Object[0]);
        } catch (ReflectiveOperationException e) {
            log.accept("cheque       fermeture incomplete: " + e);
        }
        try {
            vendor.close();
        } catch (IOException e) {
            log.accept("cheque       classes non liberees: " + e);
        }
    }

    /**
     * Lists the vendor's jars.
     *
     * @param libraryDirectory the directory holding them
     * @return their URLs
     * @throws IOException if the directory cannot be read or holds no jar
     */
    private static URL[] jars(Path libraryDirectory) throws IOException {
        List<URL> urls = new ArrayList<>();
        try (DirectoryStream<Path> jars = Files.newDirectoryStream(libraryDirectory, "*.jar")) {
            for (Path jar : jars) {
                urls.add(jar.toUri().toURL());
            }
        }
        if (urls.isEmpty()) {
            throw new IOException("no vendor jar found in " + libraryDirectory);
        }
        return urls.toArray(new URL[0]);
    }
}

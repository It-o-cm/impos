package com.intermarche.hw.discovery;

/**
 * A serial port that is not backed by a USB interface of the inventory:
 * a native UART on the motherboard.
 *
 * @param devPath  absolute path, e.g. {@code /dev/ttyS0}
 * @param uartType UART type reported by the kernel, e.g. {@code 16550A}
 */
public record SerialPort(String devPath, String uartType) {
}

package com.intermarche.hw.driver;

import java.io.IOException;

/**
 * What the POS needs from a cash drawer, wherever the drawer actually hangs.
 *
 * <p>On most tills the drawer is wired to the receipt printer's kick connector and
 * {@link ReceiptPrinter#kickDrawer(int, int, int)} is the whole story. On a Diebold
 * Nixdorf BEETLE it is not: the drawer sits on the terminal's own mini-DIN port,
 * behind an I2C GPIO extender, and the printer connector is empty. This interface
 * exists so the daemon can bind a drawer to whichever of the two a till really has,
 * instead of assuming the printer.
 */
public interface CashDrawer {

    /**
     * Fires the opening pulse.
     *
     * @throws IOException if the drawer cannot be commanded
     */
    void open() throws IOException;

    /**
     * Reads the drawer state.
     *
     * @return true when the drawer is open, false when closed, {@code null} when the
     *         binding cannot tell — a state the POS reads as "not known", never as a
     *         breakdown
     * @throws IOException if the drawer cannot be reached at all
     */
    Boolean isOpen() throws IOException;

    /**
     * Releases whatever the binding holds.
     */
    void close();
}

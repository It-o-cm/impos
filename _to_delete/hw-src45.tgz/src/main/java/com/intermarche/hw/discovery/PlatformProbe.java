package com.intermarche.hw.discovery;

/**
 * One way of finding hardware that no bus declares.
 *
 * <p>A till's soldered hardware — drawer port, key lock, beeper, GPIO lines —
 * enumerates nowhere: there is no VID, no PID, no device node to walk. It is found
 * by other evidence entirely: the terminal model in the DMI table, a vendor stack
 * installed on the disk, a helper binary that only ships where the port exists, a
 * configuration file declaring what the integrator wired. Each such route is a
 * probe, and adding hardware to this project means adding one, not touching the
 * inventory.
 */
public interface PlatformProbe {

    /**
     * The probe's name, for the report and the logs.
     *
     * @return a short human-readable name
     */
    String name();

    /**
     * Looks for the hardware this probe knows about.
     *
     * @param context what may be read, and whether the hardware may be exercised
     * @return what was concluded, never null — an absent verdict is a result
     */
    PlatformFinding probe(PlatformContext context);
}

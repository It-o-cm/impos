package com.intermarche.hw.discovery;

import java.util.List;

/**
 * Everything the discovery found on the machine at one point in time.
 *
 * @param devices     USB devices, hubs excluded
 * @param nativePorts native serial ports with a real UART behind them
 */
public record Inventory(List<UsbDevice> devices, List<SerialPort> nativePorts) {
}

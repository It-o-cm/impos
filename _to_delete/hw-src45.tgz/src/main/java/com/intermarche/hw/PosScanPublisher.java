package com.intermarche.hw;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;

/**
 * Pushes a decoded code onto the POS hardware scan bus.
 *
 * <p>The bus is {@code POST /api/pos/scan} with the code as a {@code text/plain} body —
 * the same call the e2e tests and the simulator make. A POS that does not answer is not
 * a scanner failure: the publisher reports it and the scanner keeps reading.
 */
public final class PosScanPublisher {

    private static final String SCAN_PATH = "/api/pos/scan";

    private final HttpClient client;
    private final URI scanUri;
    private final Duration timeout;

    /**
     * Creates a publisher toward a POS.
     *
     * @param posBaseUrl base URL of the POS, e.g. {@code http://localhost:8080}
     * @param timeout    request timeout
     */
    public PosScanPublisher(String posBaseUrl, Duration timeout) {
        String base = posBaseUrl.endsWith("/") ? posBaseUrl.substring(0, posBaseUrl.length() - 1) : posBaseUrl;
        this.scanUri = URI.create(base + SCAN_PATH);
        this.timeout = timeout;
        this.client = HttpClient.newBuilder().connectTimeout(timeout).build();
    }

    /**
     * Posts one code.
     *
     * @param code the code text
     * @return the HTTP status returned by the POS
     * @throws IOException if the POS cannot be reached in time
     */
    public int publish(String code) throws IOException {
        HttpRequest request = HttpRequest.newBuilder(scanUri)
                .timeout(timeout)
                .header("Content-Type", "text/plain")
                .POST(HttpRequest.BodyPublishers.ofString(code))
                .build();
        try {
            return client.send(request, HttpResponse.BodyHandlers.discarding()).statusCode();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException("Interrupted while posting to " + scanUri, e);
        }
    }

    /**
     * Returns the target URI, for logs.
     *
     * @return the scan bus URI
     */
    public URI scanUri() {
        return scanUri;
    }
}

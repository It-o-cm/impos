package com.intermarche.hw.driver;

import java.io.IOException;

/**
 * What the POS needs from a payment terminal, whichever client actually owns the reader.
 *
 * <p>The till never drives the card reader itself: a certified client process owns it
 * and the bank dialogue, and everything goes through that process. So this interface is
 * deliberately small and says nothing about tags, services or shared memory -- those
 * belong to the binding, not to the POS.
 *
 * <p>A session is stateful in a way the other peripherals are not. The client must be
 * logged in before it takes the reader, the login is slow -- it can update the reader's
 * firmware and takes minutes when it does -- and it is done once, at start-up. A
 * payment is then a short exchange inside that session. Closing ends the session and
 * stops the client.
 */
public interface PaymentTerminal {

    /**
     * Highest result code that still means the operation was accepted.
     *
     * <p>The specification does not list accepted codes, it gives ranges: 00 to 09 are
     * variants of "accepted", 10 to 18 variants of "refused", and everything above names
     * one particular failure. Reading a payment as accepted only on 01 would report a
     * cashed transaction as a refusal.
     */
    int HIGHEST_ACCEPTED_RESULT = 9;

    /**
     * The outcome of one exchange with the payment client.
     *
     * @param code   the result code, empty when nothing came back
     * @param answer the whole answer, kept as it arrived so a refusal can be diagnosed
     */
    record Result(String code, String answer) {

        /**
         * Whether the operation was accepted.
         *
         * @return true when the result code falls in the accepted range, false when it
         *         is a refusal, a failure, or nothing at all
         */
        public boolean approved() {
            int value;
            try {
                value = Integer.parseInt(code);
            } catch (NumberFormatException e) {
                return false;
            }
            return value >= 0 && value <= HIGHEST_ACCEPTED_RESULT;
        }
    }

    /**
     * One line the payment client asks to be shown while an operation runs.
     *
     * <p>These are what the cardholder and the cashier need to see -- PRESENTEZ CARTE,
     * PATIENTEZ, the maintenance steps -- and they arrive on the same channel as the
     * answer, throughout the operation. There are two lines and they are addressed by
     * index, so a screen shows the pair rather than a scroll.
     *
     * @param line the line number, 0 for the first
     * @param text the text to show, already padded by the client
     */
    record Display(int line, String text) {
    }

    /**
     * Opens the payment session.
     *
     * @return the outcome
     * @throws IOException if the client could not be reached
     */
    Result login() throws IOException;

    /**
     * Asks for a card payment of the given amount.
     *
     * @param amountCents the amount in cents
     * @return the outcome
     * @throws IOException if the client could not be reached
     */
    Result debit(long amountCents) throws IOException;

    /**
     * Ends the session and releases whatever the binding holds.
     */
    void close();
}

package com.intermarche.hw.serve;

import java.nio.charset.StandardCharsets;

/**
 * One HTTP answer of the hardware surface, decided by {@link HardwareEndpoints}
 * and written by {@link HardwareHttpServer}.
 *
 * <p>Keeping the decision (what to answer) apart from the transport (how to write it)
 * is what makes every endpoint a pure, testable method: the endpoints never touch an
 * {@code HttpExchange}.
 *
 * @param status      the HTTP status code
 * @param contentType the response content type, or {@code null} for a body-less answer
 * @param body        the response body, empty for a body-less answer
 * @param errorCode   the machine-readable failure code, or {@code null} on a success
 */
public record HttpReply(int status, String contentType, String body, String errorCode) {

    /** Content type of every textual answer of this surface. */
    private static final String TEXT_PLAIN = "text/plain; charset=utf-8";

    /**
     * Header carrying the failure code of an error answer.
     *
     * <p>The code is in the body too, but a body is not always readable by the
     * caller: the POS client (RESTEasy) hands its exception a SANITIZED
     * response — status and headers kept, entity dropped — so a client that
     * has to tell "no device bound" from "device broken" can only do it from
     * a header. This one is that channel; the body stays for curl.
     */
    public static final String STATUS_HEADER = "X-Hardware-Status";

    /**
     * A 200 carrying a plain-text body — the answer of the two reading endpoints
     * ({@code GET /weight}, {@code GET /drawer/status}), whose POS-side client
     * declares a {@code String} return.
     *
     * @param body the text to return
     * @return the reply
     */
    public static HttpReply text(String body) {
        return new HttpReply(200, TEXT_PLAIN, body, null);
    }

    /**
     * A 204 with no body — the answer of the acting endpoints (display, drawer
     * open, print, cut), whose POS-side client declares {@code void}.
     *
     * @return the reply
     */
    public static HttpReply done() {
        return new HttpReply(204, null, "", null);
    }

    /**
     * An error answer carrying a machine-readable code, so the POS log names the
     * cause rather than an anonymous status.
     *
     * @param status the HTTP status code
     * @param code   the error code, e.g. {@code NO_DEVICE_BOUND}
     * @return the reply
     */
    public static HttpReply error(int status, String code) {
        return new HttpReply(status, TEXT_PLAIN, code, headerSafe(code));
    }

    /**
     * Reduces a code to something a header can carry: no line break, no
     * excessive length. A printer failure appends the driver's own message,
     * which is free text and could otherwise break the response.
     *
     * @param code the failure code, possibly carrying a driver message
     * @return the header-safe form of the code
     */
    private static String headerSafe(String code) {
        if (code == null) {
            return null;
        }
        String flat = code.replaceAll("[\\r\\n]+", " ").trim();
        return flat.length() > 200 ? flat.substring(0, 200) : flat;
    }

    /**
     * The body encoded for the wire.
     *
     * @return the UTF-8 bytes of the body
     */
    public byte[] bodyBytes() {
        return body.getBytes(StandardCharsets.UTF_8);
    }
}

package com.intermarche.hw.discovery;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Who the terminal itself is, read from the firmware's DMI table.
 *
 * <p>The bus inventory answers "what is plugged in". This answers "what is this
 * machine", and the two are not the same question: everything soldered to the
 * board — drawer port, key lock, beeper, tone generator, GPIO lines — has no bus
 * identity at all and can only be known from the terminal model. A catalog keyed
 * on VID/PID alone is therefore blind to half of a till's hardware.
 *
 * @param vendor  the system manufacturer, e.g. {@code Diebold Nixdorf}
 * @param product the product name, e.g. {@code BEETLE}
 * @param version the product version, often the exact sub-model
 */
public record MachineIdentity(String vendor, String product, String version) {

    /** Directory the firmware exposes its identity in. */
    private static final String DMI_DIR = "class/dmi/id";

    /** Value used when the firmware exposes nothing under a name. */
    private static final String UNKNOWN = "";

    /**
     * Reads the identity of the running machine.
     *
     * @param sysRoot the sysfs root, overridable to replay a copied tree
     * @return the identity, with empty fields where the firmware said nothing
     */
    public static MachineIdentity read(Path sysRoot) {
        Path dmi = sysRoot.resolve(DMI_DIR);
        return new MachineIdentity(value(dmi, "sys_vendor"), value(dmi, "product_name"),
                value(dmi, "product_version"));
    }

    /**
     * Reads one DMI value, tolerating a machine that exposes none.
     *
     * @param dmi  the DMI directory
     * @param name the file to read
     * @return the trimmed value, empty when unreadable
     */
    private static String value(Path dmi, String name) {
        try {
            return Files.readString(dmi.resolve(name)).trim();
        } catch (IOException | RuntimeException e) {
            return UNKNOWN;
        }
    }

    /**
     * Tells whether the firmware said anything at all.
     *
     * @return true when at least one field carries a value
     */
    public boolean isKnown() {
        return !vendor.isBlank() || !product.isBlank() || !version.isBlank();
    }

    /**
     * A one-line description for the report.
     *
     * @return vendor, product and version joined, or a plain statement of ignorance
     */
    public String describe() {
        if (!isKnown()) {
            return "(no DMI identity exposed by this firmware)";
        }
        StringBuilder sb = new StringBuilder();
        append(sb, vendor);
        append(sb, product);
        append(sb, version);
        return sb.toString();
    }

    /**
     * Appends one field to the description when it carries something.
     *
     * @param sb    the description being built
     * @param field the field to append
     */
    private static void append(StringBuilder sb, String field) {
        if (field.isBlank()) {
            return;
        }
        if (sb.length() > 0) {
            sb.append(' ');
        }
        sb.append(field);
    }
}

package com.intermarche.hw.catalog;

import java.util.List;

import com.intermarche.hw.discovery.UsbDevice;

/**
 * The outcome of resolving one device against the catalog and the bus evidence.
 *
 * @param device     the discovered device
 * @param candidates hypotheses ordered from the strongest to the weakest
 * @param verdict    what the daemon would do with the device as it stands
 */
public record Resolution(UsbDevice device, List<Candidate> candidates, Verdict verdict) {

    /** Outcome classes of a resolution. */
    public enum Verdict {
        /** A STRONG candidate exists: the binding can be created without a gesture. */
        IDENTIFIED,
        /** Best candidate is MEDIUM or WEAK: a confirmation gesture is expected. */
        PROPOSED,
        /** Nothing matched: the device is reported upward as unknown. */
        UNKNOWN,
        /** Best candidate is the IGNORE role: office peripheral, deliberately left alone. */
        IGNORED
    }

    /**
     * Returns the strongest candidate.
     *
     * @return the first candidate, or {@code null} when there is none
     */
    public Candidate best() {
        return candidates.isEmpty() ? null : candidates.get(0);
    }
}

package com.intermarche.hw.catalog;

/**
 * One hypothesis about a discovered device, with the evidence that produced it.
 *
 * @param role       proposed role
 * @param driver     proposed driver key, may be {@code null} when only the role is known
 * @param confidence strength of this hypothesis
 * @param evidence   human-readable justification, e.g. {@code catalog VID_PID 04b8:0202}
 */
public record Candidate(
        HardwareProfile.Role role,
        String driver,
        HardwareProfile.Confidence confidence,
        String evidence) {
}

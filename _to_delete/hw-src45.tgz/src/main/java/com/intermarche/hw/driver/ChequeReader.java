package com.intermarche.hw.driver;

import java.io.IOException;
import java.time.Duration;

/**
 * What the POS needs from a cheque reader, whatever drives the head.
 *
 * <p>A cheque is read by a magnetic head, not by looking at the paper: the bottom line
 * of a French cheque is printed in magnetic ink and the reader measures a field. That
 * is worth knowing before diagnosing anything, because a photocopy, a specimen or a
 * reprinted cheque is perfectly legible to the eye and completely silent to the head --
 * it answers "no data", which is the correct answer and not a fault.
 *
 * <p>The exchange is physical and takes as long as a person takes: the reader waits for
 * the document to be offered, pulls it in, reads it and gives it back. So the timeout
 * bounds a human, not a machine.
 */
public interface ChequeReader extends AutoCloseable {

    /**
     * What the reader decoded from the magnetic line.
     *
     * <p>The raw line is kept beside the parsed fields on purpose. Parsing is done by
     * the vendor's service and can be wrong or partial on an unusual cheque, whereas
     * the raw line is what was actually read; keeping it is what allows a refusal to be
     * diagnosed later instead of argued about.
     *
     * @param raw     the magnetic line as read, before any parsing
     * @param account the account number, empty when the service did not parse one
     * @param bank    the bank code, empty when the service did not parse one
     * @param branch  the branch code, empty when the service did not parse one
     * @param serial  the cheque number, empty when the service did not parse one
     */
    record Reading(String raw, String account, String bank, String branch, String serial) {
    }

    /**
     * Waits for a cheque, reads it and gives it back.
     *
     * @param insertionTimeout how long the operator has to offer the cheque
     * @return what was read
     * @throws IOException when nothing could be read, naming why -- an empty document,
     *                     a jam, an open cover and a cheque with no magnetic ink are
     *                     four different failures and are reported as such
     */
    Reading read(Duration insertionTimeout) throws IOException;

    /**
     * Releases the reader so another process can claim it.
     */
    @Override
    void close();
}

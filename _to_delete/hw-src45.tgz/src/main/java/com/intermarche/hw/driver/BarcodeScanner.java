package com.intermarche.hw.driver;

import java.util.HexFormat;
import java.util.function.Consumer;

/**
 * What the POS needs from a barcode scanner: a stream of decoded codes.
 *
 * <p>Implementations own the transport and the wire format (IBM HID reports today,
 * keyboard reports or a CDC line tomorrow); the POS only ever sees the text of the code.
 */
public interface BarcodeScanner {

    /**
     * Reads scans and hands each one to the listener until the thread is interrupted.
     *
     * <p>A device that disappears (unplugged, re-enumerated) is not an error: the
     * implementation waits for it to come back and resumes. The method returns only
     * on interruption.
     *
     * @param listener receives every decoded scan
     */
    void run(Consumer<ScanEvent> listener);

    /**
     * One decoded scan.
     *
     * @param code       the barcode text as the POS must receive it
     * @param symbology  symbology name when known, e.g. {@code EAN-13}
     * @param raw        the raw report the code was decoded from
     */
    record ScanEvent(String code, String symbology, byte[] raw) {

        /**
         * Formats the raw report as hex, for logs.
         *
         * @return space-separated hex bytes
         */
        public String rawHex() {
            return HexFormat.ofDelimiter(" ").formatHex(raw);
        }
    }
}

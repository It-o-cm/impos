package com.intermarche.hw.discovery;

import java.util.List;

/**
 * A USB device as declared on the bus, with the interfaces it exposes.
 *
 * @param sysName      sysfs entry name, e.g. {@code 1-1.2}
 * @param busNumber    USB bus number
 * @param deviceNumber device number on the bus
 * @param vendorId     idVendor, 4 lowercase hex digits
 * @param productId    idProduct, 4 lowercase hex digits
 * @param manufacturer manufacturer string descriptor, may be {@code null}
 * @param product      product string descriptor, may be {@code null}
 * @param serial       serial string descriptor, may be {@code null}
 * @param deviceClass  bDeviceClass, 2 hex digits, may be {@code null}
 * @param interfaces   interfaces exposed by the active configuration
 */
public record UsbDevice(
        String sysName,
        int busNumber,
        int deviceNumber,
        String vendorId,
        String productId,
        String manufacturer,
        String product,
        String serial,
        String deviceClass,
        List<UsbInterface> interfaces) {

    /**
     * Builds the {@code vvvv:pppp} identity key used by the catalog.
     *
     * @return vendor and product ids joined by a colon
     */
    public String vidPid() {
        return vendorId + ":" + productId;
    }

    /**
     * Builds the stable identity used to persist a binding across reboots.
     *
     * @return {@code vid:pid:serial}, or {@code vid:pid} when the device has no serial
     */
    public String stableIdentity() {
        return serial == null || serial.isBlank() ? vidPid() : vidPid() + ":" + serial;
    }

    /**
     * Tells whether the device is a USB hub (device class 09), never a POS peripheral.
     *
     * @return {@code true} for hubs and root hubs
     */
    public boolean isHub() {
        return "09".equals(deviceClass);
    }
}

package com.intermarche.hw.catalog;

import java.util.Locale;

/**
 * One line of the hardware knowledge base: how to recognise a device and how to talk to it.
 *
 * <p>Profiles are a store-level referential pulled by every POS; they describe models,
 * never the peripherals of one given POS (that is a binding, local to the POS).
 *
 * @param matchKind  how {@code matchValue} is compared with a discovered device
 * @param matchValue the value to compare: {@code vvvv:pppp}, {@code vvvv} or a keyword
 * @param role       what the matched device is for
 * @param driver     implementation key expected in the daemon, e.g. {@code ESCPOS}
 * @param confidence how much a match on this line proves on its own
 * @param params     free key=value parameters for the driver, may be empty
 */
public record HardwareProfile(
        MatchKind matchKind,
        String matchValue,
        Role role,
        String driver,
        Confidence confidence,
        String params) {

    /** Comparison levels, from the most to the least specific. */
    public enum MatchKind {
        /** Exact {@code vvvv:pppp}. */
        VID_PID,
        /** Vendor id only: a manufacturer of POS peripherals. */
        VID,
        /** Keyword contained in the product or manufacturer string, case-insensitive. */
        PRODUCT_KEYWORD
    }

    /** Roles a peripheral can play for the POS. */
    public enum Role {
        /** Barcode scanner. */
        SCANNER,
        /** Receipt printer (the cash drawer hangs behind it). */
        PRINTER,
        /** Customer line display. */
        DISPLAY,
        /** Payment terminal. */
        TPE,
        /** Checkout scale. */
        SCALE,
        /** Magnetic stripe reader. */
        MSR,
        /** Known device that is not a POS peripheral (keyboard, mouse, audio, touch). */
        IGNORE
    }

    /** How strongly a match identifies the device. */
    public enum Confidence {
        /** Identification is settled. */
        STRONG,
        /** Very likely; a local confirmation gesture is advised. */
        MEDIUM,
        /** A hint only; confirmation is required. */
        WEAK
    }

    /**
     * Tests this profile against a device's identity and strings.
     *
     * @param vidPid       the device {@code vvvv:pppp}
     * @param manufacturer manufacturer string, may be {@code null}
     * @param product      product string, may be {@code null}
     * @return {@code true} when the profile applies to the device
     */
    public boolean matches(String vidPid, String manufacturer, String product) {
        return switch (matchKind) {
            case VID_PID -> matchValue.equalsIgnoreCase(vidPid);
            case VID -> vidPid != null && vidPid.length() > 4 && vidPid.charAt(4) == ':'
                    && vidPid.regionMatches(true, 0, matchValue, 0, 4);
            case PRODUCT_KEYWORD -> contains(product, matchValue) || contains(manufacturer, matchValue);
        };
    }

    /**
     * Case-insensitive containment test tolerant to {@code null}.
     *
     * @param haystack the string to search, may be {@code null}
     * @param needle   the keyword
     * @return {@code true} when the keyword is found
     */
    private static boolean contains(String haystack, String needle) {
        return haystack != null && haystack.toLowerCase(Locale.ROOT).contains(needle.toLowerCase(Locale.ROOT));
    }
}

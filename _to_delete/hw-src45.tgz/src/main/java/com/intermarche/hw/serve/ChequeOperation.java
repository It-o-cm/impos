package com.intermarche.hw.serve;

import java.io.IOException;
import java.time.Duration;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;

import com.intermarche.hw.driver.ChequeReader;

/**
 * The cheque being read, and what the POS may read about it.
 *
 * <p>Same shape as {@link PaymentOperation}, for the same reason: reading a cheque
 * waits for a person to offer a document and give it back, which is far too long to
 * hold an HTTP request open. The POS starts a reading and then reads its state.
 *
 * <p>ONE DIFFERENCE, and it is not cosmetic: the reader is opened for the reading and
 * closed right after, never held. The vendor's service claims the printer exclusively,
 * and this daemon prints receipts on that same printer by opening its node per request.
 * A reader held open between two cheques would silently break every receipt.
 */
public final class ChequeOperation {

    /** Where a reading stands. */
    public enum State {

        /** No cheque has been asked for since the daemon started. */
        IDLE,

        /** A reading is running: the reader is waiting for the document. */
        RUNNING,

        /** The last reading is over, successfully or not. */
        DONE
    }

    /**
     * How a reader is opened.
     *
     * <p>Opening is what claims the printer, so it happens per reading and is allowed
     * to fail: the printer may be busy printing a receipt at that very moment.
     */
    @FunctionalInterface
    public interface ReaderFactory {

        /**
         * Opens the cheque reader.
         *
         * @return the reader, which the caller closes
         * @throws IOException if the vendor's service could not be opened
         */
        ChequeReader open() throws IOException;
    }

    /** How a reader is opened. */
    private final ReaderFactory factory;

    /** How long the operator has to offer the cheque. */
    private final Duration timeout;

    /** Where the operation narrates what it does. */
    private final Consumer<String> log;

    /** Runs the reading away from the request thread. */
    private final ExecutorService worker = Executors.newSingleThreadExecutor(runnable -> {
        Thread thread = new Thread(runnable, "cheque");
        thread.setDaemon(true);
        return thread;
    });

    /** Where the reading stands. */
    private State state = State.IDLE;

    /** What was read, or {@code null} until a reading succeeded. */
    private ChequeReader.Reading reading;

    /** Why the last reading failed, empty when it succeeded. */
    private String failure = "";

    /**
     * Builds an operation over a way of opening a reader, with nothing running yet.
     *
     * @param factory how a reader is opened
     * @param timeout how long the operator has to offer the cheque
     * @param log     destination of the log lines
     */
    public ChequeOperation(ReaderFactory factory, Duration timeout, Consumer<String> log) {
        this.factory = factory;
        this.timeout = timeout;
        this.log = log;
    }

    /**
     * Starts a reading.
     *
     * @return true when the reading was started, false when one is already running
     */
    public synchronized boolean start() {
        if (state == State.RUNNING) {
            return false;
        }
        state = State.RUNNING;
        reading = null;
        failure = "";
        worker.execute(this::run);
        return true;
    }

    /**
     * What the POS reads about the reading, one {@code key=value} per line.
     *
     * @return the state, then the zones of the magnetic line once there are any
     */
    public synchronized String report() {
        StringBuilder text = new StringBuilder();
        text.append("state=").append(state).append('\n');
        text.append("failure=").append(failure).append('\n');
        text.append("raw=").append(reading == null ? "" : reading.raw()).append('\n');
        text.append("bank=").append(reading == null ? "" : reading.bank()).append('\n');
        text.append("branch=").append(reading == null ? "" : reading.branch()).append('\n');
        text.append("account=").append(reading == null ? "" : reading.account()).append('\n');
        text.append("serial=").append(reading == null ? "" : reading.serial());
        return text.toString();
    }

    /**
     * Releases the worker thread.
     */
    public void close() {
        worker.shutdownNow();
    }

    /**
     * Runs one reading and records how it ended.
     *
     * <p>Every failure ends the operation, the unexpected ones included: leaving it on
     * {@link State#RUNNING} would make the POS poll a state that never moves again and
     * would refuse every later reading as busy.
     */
    private void run() {
        try (ChequeReader reader = factory.open()) {
            finish(reader.read(timeout), "");
            log.accept("cheque       lu");
        } catch (IOException e) {
            finish(null, e.getMessage());
            log.accept("cheque       lecture impossible: " + e.getMessage());
        } catch (RuntimeException e) {
            finish(null, e.toString());
            log.accept("cheque       lecture rompue: " + e);
        }
    }

    /**
     * Records the outcome of a reading.
     *
     * @param read  what was read, or {@code null} when nothing was
     * @param cause why nothing was read, empty when something was
     */
    private synchronized void finish(ChequeReader.Reading read, String cause) {
        reading = read;
        failure = cause;
        state = State.DONE;
    }
}

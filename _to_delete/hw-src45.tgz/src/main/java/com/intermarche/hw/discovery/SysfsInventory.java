package com.intermarche.hw.discovery;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.stream.Stream;

/**
 * Reads the hardware inventory from the kernel's virtual filesystems.
 *
 * <p>Everything comes from plain files: {@code /sys/bus/usb/devices} for devices and
 * interfaces, the interface subtree for the nodes each driver created,
 * {@code /dev/serial/by-id} for stable serial names and {@code /proc/tty/driver/serial}
 * for native UARTs. No native library and no external command is involved, so the
 * scan runs identically on any Linux and needs no privilege beyond read access.
 * The three roots are injectable so the scanner can be exercised on a copied tree.
 */
public final class SysfsInventory {

    private static final Pattern INTERFACE_NAME = Pattern.compile("^[0-9]+-[0-9.]+:[0-9]+\\.[0-9]+$");
    private static final Pattern DEVICE_NAME = Pattern.compile("^[0-9]+-[0-9.]+$");
    private static final Pattern HIDRAW_DIR = Pattern.compile("^hidraw[0-9]+$");
    private static final Pattern TTY_DIR = Pattern.compile("^tty[A-Za-z]+[0-9]+$");
    private static final Pattern LP_DIR = Pattern.compile("^lp[0-9]+$");
    private static final Pattern PROC_SERIAL_LINE = Pattern.compile("^(\\d+): uart:(\\S+)");
    private static final int NODE_SEARCH_DEPTH = 4;

    private final Path sysRoot;
    private final Path devRoot;
    private final Path procRoot;

    /**
     * Creates a scanner over the live kernel filesystems.
     */
    public SysfsInventory() {
        this(Path.of("/sys"), Path.of("/dev"), Path.of("/proc"));
    }

    /**
     * Creates a scanner over explicit roots, for tests on a copied tree.
     *
     * @param sysRoot  root standing for {@code /sys}
     * @param devRoot  root standing for {@code /dev}
     * @param procRoot root standing for {@code /proc}
     */
    public SysfsInventory(Path sysRoot, Path devRoot, Path procRoot) {
        this.sysRoot = sysRoot;
        this.devRoot = devRoot;
        this.procRoot = procRoot;
    }

    /**
     * Performs a full scan.
     *
     * @return the inventory, hubs excluded, devices ordered by bus then device number
     */
    public Inventory scan() {
        Map<String, String> byId = readSerialByIdLinks();
        List<UsbDevice> devices = readUsbDevices(byId);
        devices.removeIf(UsbDevice::isHub);
        devices.sort(Comparator.comparingInt(UsbDevice::busNumber).thenComparingInt(UsbDevice::deviceNumber));
        return new Inventory(List.copyOf(devices), readNativePorts());
    }

    /**
     * Reads every USB device entry under {@code /sys/bus/usb/devices}.
     *
     * @param byId stable serial links indexed by TTY name
     * @return mutable list of devices, hubs included
     */
    private List<UsbDevice> readUsbDevices(Map<String, String> byId) {
        Path devicesDir = sysRoot.resolve("bus/usb/devices");
        List<UsbDevice> result = new ArrayList<>();
        if (!Files.isDirectory(devicesDir)) {
            return result;
        }
        try (Stream<Path> entries = Files.list(devicesDir)) {
            entries.filter(p -> DEVICE_NAME.matcher(p.getFileName().toString()).matches())
                    .filter(p -> Files.exists(p.resolve("idVendor")))
                    .forEach(p -> result.add(readDevice(p, byId)));
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
        return result;
    }

    /**
     * Builds one device from its sysfs directory.
     *
     * @param deviceDir the device directory, e.g. {@code .../1-1.2}
     * @param byId      stable serial links indexed by TTY name
     * @return the device with its interfaces
     */
    private UsbDevice readDevice(Path deviceDir, Map<String, String> byId) {
        String name = deviceDir.getFileName().toString();
        return new UsbDevice(
                name,
                readInt(deviceDir, "busnum"),
                readInt(deviceDir, "devnum"),
                lower(readAttr(deviceDir, "idVendor")),
                lower(readAttr(deviceDir, "idProduct")),
                readAttr(deviceDir, "manufacturer"),
                readAttr(deviceDir, "product"),
                readAttr(deviceDir, "serial"),
                lower(readAttr(deviceDir, "bDeviceClass")),
                readInterfaces(deviceDir.getParent(), name, byId));
    }

    /**
     * Reads the interfaces of a device: sibling entries named {@code <device>:<config>.<number>}.
     *
     * @param devicesDir the {@code /sys/bus/usb/devices} directory
     * @param deviceName the device entry name
     * @param byId       stable serial links indexed by TTY name
     * @return interfaces ordered by interface number
     */
    private List<UsbInterface> readInterfaces(Path devicesDir, String deviceName, Map<String, String> byId) {
        List<UsbInterface> result = new ArrayList<>();
        try (Stream<Path> entries = Files.list(devicesDir)) {
            entries.filter(p -> p.getFileName().toString().startsWith(deviceName + ":"))
                    .filter(p -> INTERFACE_NAME.matcher(p.getFileName().toString()).matches())
                    .forEach(p -> result.add(readInterface(p, byId)));
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
        result.sort(Comparator.comparingInt(UsbInterface::number));
        return List.copyOf(result);
    }

    /**
     * Builds one interface from its sysfs directory.
     *
     * @param interfaceDir the interface directory, e.g. {@code .../1-1.2:1.0}
     * @param byId         stable serial links indexed by TTY name
     * @return the interface with its driver and nodes
     */
    private UsbInterface readInterface(Path interfaceDir, Map<String, String> byId) {
        List<DeviceNode> nodes = new ArrayList<>();
        collectNodes(interfaceDir, 0, nodes, byId);
        return new UsbInterface(
                interfaceDir.getFileName().toString(),
                readInt(interfaceDir, "bInterfaceNumber"),
                lower(readAttr(interfaceDir, "bInterfaceClass")),
                lower(readAttr(interfaceDir, "bInterfaceSubClass")),
                lower(readAttr(interfaceDir, "bInterfaceProtocol")),
                readLinkName(interfaceDir.resolve("driver")),
                List.copyOf(nodes));
    }

    /**
     * Walks the interface subtree looking for the directories drivers create for
     * their nodes: {@code hidrawN}, {@code ttyXXXn}, {@code lpN}.
     *
     * @param dir   directory to inspect
     * @param depth current depth below the interface directory
     * @param out   collector for the nodes found
     * @param byId  stable serial links indexed by TTY name
     */
    private void collectNodes(Path dir, int depth, List<DeviceNode> out, Map<String, String> byId) {
        if (depth > NODE_SEARCH_DEPTH) {
            return;
        }
        try (Stream<Path> children = Files.list(dir)) {
            for (Path child : children.filter(this::isRealDirectory).toList()) {
                String name = child.getFileName().toString();
                if (HIDRAW_DIR.matcher(name).matches()) {
                    out.add(readHidrawNode(child));
                } else if (TTY_DIR.matcher(name).matches() && "tty".equals(dir.getFileName().toString())) {
                    String devPath = devRoot.resolve(name).toString();
                    out.add(new DeviceNode(DeviceNode.Kind.TTY, devPath, byId.get(name), null, Set.of()));
                } else if (LP_DIR.matcher(name).matches() && "usbmisc".equals(dir.getFileName().toString())) {
                    out.add(new DeviceNode(DeviceNode.Kind.LP, devRoot.resolve("usb").resolve(name).toString(),
                            null, null, Set.of()));
                } else {
                    collectNodes(child, depth + 1, out, byId);
                }
            }
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    /**
     * Builds a hidraw node; the HID device directory is two levels up
     * ({@code <hid device>/hidraw/hidrawN}) and holds the descriptor and uevent.
     *
     * @param hidrawDir the {@code hidrawN} directory
     * @return the node with its HID name and usage pages
     */
    private DeviceNode readHidrawNode(Path hidrawDir) {
        Path hidDeviceDir = hidrawDir.getParent().getParent();
        String hidName = readUeventValue(hidDeviceDir.resolve("uevent"), "HID_NAME");
        Set<Integer> pages = readUsagePages(hidDeviceDir.resolve("report_descriptor"));
        return new DeviceNode(DeviceNode.Kind.HIDRAW,
                devRoot.resolve(hidrawDir.getFileName().toString()).toString(), null, hidName, pages);
    }

    /**
     * Reads the usage pages declared in a HID report descriptor.
     *
     * @param descriptor path of the binary {@code report_descriptor} attribute
     * @return usage pages in declaration order, empty when the file is absent
     */
    private static Set<Integer> readUsagePages(Path descriptor) {
        if (!Files.isReadable(descriptor)) {
            return Set.of();
        }
        try {
            return parseUsagePages(Files.readAllBytes(descriptor));
        } catch (IOException e) {
            return Set.of();
        }
    }

    /**
     * Parses HID short items and collects every Usage Page (global item, tag 0) value.
     *
     * @param bytes the raw report descriptor
     * @return usage pages in declaration order
     */
    static Set<Integer> parseUsagePages(byte[] bytes) {
        Set<Integer> pages = new LinkedHashSet<>();
        int i = 0;
        while (i < bytes.length) {
            int prefix = bytes[i] & 0xFF;
            if (prefix == 0xFE) {
                int longSize = i + 1 < bytes.length ? bytes[i + 1] & 0xFF : 0;
                i += 3 + longSize;
                continue;
            }
            int size = prefix & 0x03;
            if (size == 3) {
                size = 4;
            }
            int tagAndType = prefix & 0xFC;
            if (tagAndType == 0x04 && size > 0 && i + size < bytes.length) {
                int value = 0;
                for (int k = 0; k < size; k++) {
                    value |= (bytes[i + 1 + k] & 0xFF) << (8 * k);
                }
                pages.add(value);
            }
            i += 1 + size;
        }
        return pages;
    }

    /**
     * Indexes the {@code /dev/serial/by-id} links by the TTY name they point to.
     *
     * @return map from TTY name (e.g. {@code ttyACM0}) to the absolute by-id link path
     */
    private Map<String, String> readSerialByIdLinks() {
        Map<String, String> result = new HashMap<>();
        Path byIdDir = devRoot.resolve("serial/by-id");
        if (!Files.isDirectory(byIdDir)) {
            return result;
        }
        try (Stream<Path> links = Files.list(byIdDir)) {
            for (Path link : links.toList()) {
                String target = readLinkName(link);
                if (target != null) {
                    result.put(target, link.toString());
                }
            }
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
        return result;
    }

    /**
     * Reads the native UARTs from {@code /proc/tty/driver/serial}, skipping
     * entries whose type is {@code unknown} (no hardware behind the port).
     *
     * @return native ports with a real UART, empty when the file is unreadable
     */
    private List<SerialPort> readNativePorts() {
        Path serial = procRoot.resolve("tty/driver/serial");
        List<SerialPort> result = new ArrayList<>();
        if (!Files.isReadable(serial)) {
            return result;
        }
        try {
            for (String line : Files.readAllLines(serial, StandardCharsets.US_ASCII)) {
                var m = PROC_SERIAL_LINE.matcher(line);
                if (m.find() && !"unknown".equals(m.group(2))) {
                    result.add(new SerialPort(devRoot.resolve("ttyS" + m.group(1)).toString(), m.group(2)));
                }
            }
        } catch (IOException e) {
            return result;
        }
        return List.copyOf(result);
    }

    /**
     * Reads one value from a {@code uevent} file.
     *
     * @param uevent the uevent file
     * @param key    the key to look for
     * @return the value, or {@code null} when absent or unreadable
     */
    private static String readUeventValue(Path uevent, String key) {
        if (!Files.isReadable(uevent)) {
            return null;
        }
        try {
            return Files.readAllLines(uevent, StandardCharsets.UTF_8).stream()
                    .filter(l -> l.startsWith(key + "="))
                    .map(l -> l.substring(key.length() + 1).trim())
                    .findFirst()
                    .orElse(null);
        } catch (IOException e) {
            return null;
        }
    }

    /**
     * Reads a text attribute of a sysfs directory.
     *
     * @param dir  the directory
     * @param name attribute file name
     * @return the trimmed content, or {@code null} when absent or unreadable
     */
    private static String readAttr(Path dir, String name) {
        Path file = dir.resolve(name);
        if (!Files.isReadable(file)) {
            return null;
        }
        try {
            String value = Files.readString(file, StandardCharsets.UTF_8).trim();
            return value.isEmpty() ? null : value;
        } catch (IOException e) {
            return null;
        }
    }

    /**
     * Reads a numeric attribute of a sysfs directory.
     *
     * @param dir  the directory
     * @param name attribute file name
     * @return the value, or -1 when absent or not numeric
     */
    private static int readInt(Path dir, String name) {
        String value = readAttr(dir, name);
        if (value == null) {
            return -1;
        }
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    /**
     * Returns the last path element of a symbolic link target.
     *
     * @param link the link
     * @return the target's file name, or {@code null} when the link does not exist
     */
    private static String readLinkName(Path link) {
        if (!Files.isSymbolicLink(link)) {
            return null;
        }
        try {
            return Files.readSymbolicLink(link).getFileName().toString();
        } catch (IOException e) {
            return null;
        }
    }

    /**
     * Tells whether a path is a directory that is not a symbolic link, so the walk
     * never leaves the interface subtree through sysfs back-links.
     *
     * @param p the path
     * @return {@code true} for real directories only
     */
    private boolean isRealDirectory(Path p) {
        return Files.isDirectory(p) && !Files.isSymbolicLink(p);
    }

    /**
     * Lowercases a nullable hex attribute so keys compare uniformly.
     *
     * @param value the attribute value
     * @return the lowercase value, or {@code null}
     */
    private static String lower(String value) {
        return value == null ? null : value.toLowerCase();
    }
}

package com.intermarche.hw.discovery;

import java.util.List;

/**
 * What one platform probe concluded about one role of the terminal.
 *
 * <p>Deliberately shaped like the bus verdicts, so a report can present board
 * hardware and plugged hardware side by side: a role, a driver, a verdict, and
 * the evidence that led to it. The evidence is kept because these findings are
 * not self-evident — nobody can look at a cash drawer on an I2C line and see it,
 * so the report has to say WHY it believes what it says.
 *
 * @param role     the role found, e.g. {@code DRAWER}
 * @param driver   the driver that would serve it, e.g. {@code DN_PORTIO}
 * @param verdict  how sure the probe is
 * @param detail   one line of human explanation
 * @param evidence the facts checked, in the order they were checked
 */
public record PlatformFinding(String role, String driver, PlatformFinding.Verdict verdict,
        String detail, List<String> evidence) {

    /**
     * How sure a platform probe is of what it found.
     */
    public enum Verdict {

        /** The device answered an active proof: it is there and it works. */
        CONFIRMED,

        /** Passive evidence says the device should be there; nothing was exercised. */
        PROPOSED,

        /** The evidence this probe looks for is not on this machine. */
        ABSENT
    }

    /**
     * Builds a confirmed finding.
     *
     * @param role     the role found
     * @param driver   the driver serving it
     * @param detail   one line of explanation
     * @param evidence the facts checked
     * @return the finding
     */
    public static PlatformFinding confirmed(String role, String driver, String detail,
            List<String> evidence) {
        return new PlatformFinding(role, driver, Verdict.CONFIRMED, detail, evidence);
    }

    /**
     * Builds a proposed finding.
     *
     * @param role     the role found
     * @param driver   the driver serving it
     * @param detail   one line of explanation
     * @param evidence the facts checked
     * @return the finding
     */
    public static PlatformFinding proposed(String role, String driver, String detail,
            List<String> evidence) {
        return new PlatformFinding(role, driver, Verdict.PROPOSED, detail, evidence);
    }

    /**
     * Builds an absent finding.
     *
     * @param role     the role looked for
     * @param driver   the driver that would have served it
     * @param detail   one line of explanation
     * @param evidence the facts checked
     * @return the finding
     */
    public static PlatformFinding absent(String role, String driver, String detail,
            List<String> evidence) {
        return new PlatformFinding(role, driver, Verdict.ABSENT, detail, evidence);
    }
}

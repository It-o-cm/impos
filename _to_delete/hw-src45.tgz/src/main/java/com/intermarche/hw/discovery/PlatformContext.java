package com.intermarche.hw.discovery;

import java.nio.file.Path;
import java.util.function.Consumer;

/**
 * What a platform probe is allowed to look at, and how far it may go.
 *
 * <p>{@code active} is the whole point of this record. A passive probe reads files
 * and concludes; an active one runs the vendor's own helper to make the board
 * answer. The second proves much more and costs a process, so the caller decides:
 * {@code discover} stays passive by default and only goes active when asked.
 *
 * @param root    filesystem root, overridable to replay a copied tree
 * @param sysRoot sysfs root
 * @param active  true when the probe may exercise the hardware
 * @param log     where a probe narrates what it did
 */
public record PlatformContext(Path root, Path sysRoot, boolean active, Consumer<String> log) {
}

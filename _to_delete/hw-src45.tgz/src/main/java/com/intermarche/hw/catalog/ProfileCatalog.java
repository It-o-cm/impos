package com.intermarche.hw.catalog;

import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * The set of {@link HardwareProfile} lines known to this daemon.
 *
 * <p>Two sources, merged in order: the profiles embedded in the jar (the fallback that
 * lets a never-synchronised POS recognise common hardware on installation day), then an
 * optional file holding the profiles pulled from the store node. A later line with the
 * same match kind and value supersedes an earlier one, so the pulled referential wins.
 *
 * <p>File format, one profile per line, {@code |}-separated, {@code #} comments allowed:
 * <pre>MATCH_KIND|match_value|ROLE|DRIVER|CONFIDENCE|key=value;key=value</pre>
 */
public final class ProfileCatalog {

    private static final String EMBEDDED_RESOURCE = "/default-profiles.txt";

    private final List<HardwareProfile> profiles;

    /**
     * Creates a catalog over an explicit list of profiles.
     *
     * @param profiles the profiles, kept in order
     */
    public ProfileCatalog(List<HardwareProfile> profiles) {
        this.profiles = List.copyOf(profiles);
    }

    /**
     * Loads the embedded defaults, then merges the given file on top when present.
     *
     * @param pulledFile the store-pulled profiles file, may be {@code null}
     * @return the merged catalog
     */
    public static ProfileCatalog load(Path pulledFile) {
        List<HardwareProfile> merged = new ArrayList<>(loadEmbedded());
        if (pulledFile != null && Files.isReadable(pulledFile)) {
            try {
                merge(merged, parse(Files.readAllLines(pulledFile, StandardCharsets.UTF_8)));
            } catch (IOException e) {
                throw new UncheckedIOException(e);
            }
        }
        return new ProfileCatalog(merged);
    }

    /**
     * Reads the profiles shipped in the jar.
     *
     * @return the embedded profiles, empty when the resource is missing
     */
    static List<HardwareProfile> loadEmbedded() {
        try (InputStream in = ProfileCatalog.class.getResourceAsStream(EMBEDDED_RESOURCE)) {
            if (in == null) {
                return List.of();
            }
            return parse(new String(in.readAllBytes(), StandardCharsets.UTF_8).lines().toList());
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    /**
     * Parses profile lines, skipping blanks and comments.
     *
     * @param lines raw lines
     * @return the parsed profiles in file order
     * @throws IllegalArgumentException on a malformed line
     */
    static List<HardwareProfile> parse(List<String> lines) {
        List<HardwareProfile> result = new ArrayList<>();
        int number = 0;
        for (String raw : lines) {
            number++;
            String line = raw.strip();
            if (line.isEmpty() || line.startsWith("#")) {
                continue;
            }
            String[] f = line.split("\\|", -1);
            if (f.length < 5) {
                throw new IllegalArgumentException("Malformed profile line " + number + ": " + raw);
            }
            result.add(new HardwareProfile(
                    HardwareProfile.MatchKind.valueOf(f[0].strip()),
                    f[1].strip(),
                    HardwareProfile.Role.valueOf(f[2].strip()),
                    blankToNull(f[3]),
                    HardwareProfile.Confidence.valueOf(f[4].strip()),
                    f.length > 5 ? f[5].strip() : ""));
        }
        return result;
    }

    /**
     * Merges newer profiles into a list, replacing lines with the same match key.
     *
     * @param base  the list to update in place
     * @param newer the profiles that take precedence
     */
    private static void merge(List<HardwareProfile> base, List<HardwareProfile> newer) {
        for (HardwareProfile p : newer) {
            base.removeIf(b -> b.matchKind() == p.matchKind() && b.matchValue().equalsIgnoreCase(p.matchValue()));
            base.add(p);
        }
    }

    /**
     * Finds every profile matching a device, ordered by match kind then catalog order.
     *
     * @param vidPid       the device {@code vvvv:pppp}
     * @param manufacturer manufacturer string, may be {@code null}
     * @param product      product string, may be {@code null}
     * @return matching profiles, most specific first
     */
    public List<HardwareProfile> matching(String vidPid, String manufacturer, String product) {
        List<HardwareProfile> result = new ArrayList<>();
        for (HardwareProfile.MatchKind kind : HardwareProfile.MatchKind.values()) {
            for (HardwareProfile p : profiles) {
                if (p.matchKind() == kind && p.matches(vidPid, manufacturer, product)) {
                    result.add(p);
                }
            }
        }
        return result;
    }

    /**
     * Returns the number of profiles held.
     *
     * @return the profile count
     */
    public int size() {
        return profiles.size();
    }

    /**
     * Maps a blank string to {@code null}.
     *
     * @param s the string
     * @return the stripped string, or {@code null} when blank
     */
    private static String blankToNull(String s) {
        String v = s.strip();
        return v.isEmpty() ? null : v;
    }
}

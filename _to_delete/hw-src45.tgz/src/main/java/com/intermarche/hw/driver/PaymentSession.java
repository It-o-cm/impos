package com.intermarche.hw.driver;

import java.io.IOException;
import java.util.function.Consumer;

/**
 * A payment session that outlives the payments made through it, and comes back by itself
 * when it falls.
 *
 * <p>Opening a session is expensive: the login can spend minutes checking, and sometimes
 * updating, the reader's firmware. So it is done once, when the daemon starts, and never
 * per sale. The counterpart is that something must notice when the session dies -- the
 * payment client is a separate process and can be killed, crash, or be restarted under
 * the daemon -- and open a new one. That is this class.
 *
 * <p>The recovery is deliberately driven by use rather than by a timer. A session is only
 * ever needed at the moment of a payment; discovering it is dead there, opening a new one
 * and retrying the payment ONCE is both simpler and more honest than a background poll
 * that would claim health between two sales. The retry happens once and only once: a
 * second failure is a real failure and is reported as such.
 */
public final class PaymentSession implements PaymentTerminal {

    /**
     * How a new session is opened.
     *
     * <p>The session cannot merely re-login on the terminal it already has: the client
     * process is gone, so the whole binding has to be built again.
     */
    @FunctionalInterface
    public interface Opener {

        /**
         * Starts the payment client and returns a terminal that talks to it.
         *
         * @return the terminal
         * @throws IOException if the client could not be started
         */
        PaymentTerminal open() throws IOException;
    }

    /** How a new session is opened. */
    private final Opener opener;

    /** Where the session narrates what it does. */
    private final Consumer<String> log;

    /** The terminal of the open session, {@code null} when there is none. */
    private PaymentTerminal terminal;

    /**
     * Wraps a way of opening sessions; nothing is opened yet.
     *
     * @param opener how a new session is opened
     * @param log    destination of the log lines
     */
    public PaymentSession(Opener opener, Consumer<String> log) {
        this.opener = opener;
        this.log = log;
    }

    /** {@inheritDoc} */
    @Override
    public synchronized Result login() throws IOException {
        drop();
        return start();
    }

    /** {@inheritDoc} */
    @Override
    public synchronized Result debit(long amountCents) throws IOException {
        try {
            return open().debit(amountCents);
        } catch (IOException lost) {
            log.accept("tpe          session lost (" + lost.getMessage() + "), opening a new one");
            drop();
            Result again = start();
            if (!again.approved()) {
                throw new IOException("could not open a new session: " + again.answer(), lost);
            }
            return open().debit(amountCents);
        }
    }

    /** {@inheritDoc} */
    @Override
    public synchronized void close() {
        drop();
    }

    /**
     * Whether a session is open.
     *
     * @return true when a terminal is held
     */
    public synchronized boolean isOpen() {
        return terminal != null;
    }

    /**
     * The terminal of the open session, opening one if there is none.
     *
     * @return the terminal
     * @throws IOException if no session could be opened
     */
    private PaymentTerminal open() throws IOException {
        if (terminal == null) {
            Result opened = start();
            if (!opened.approved()) {
                throw new IOException("no payment session: login answered " + opened.answer());
            }
        }
        return terminal;
    }

    /**
     * Starts the client and logs in, keeping the terminal only if the login answered.
     *
     * @return the outcome of the login
     * @throws IOException if the client could not be started
     */
    private Result start() throws IOException {
        terminal = opener.open();
        try {
            Result result = terminal.login();
            log.accept("tpe          login " + (result.approved() ? "accepted" : "refused")
                    + ": " + result.answer());
            return result;
        } catch (IOException e) {
            drop();
            throw e;
        }
    }

    /**
     * Ends the session, if there is one.
     */
    private void drop() {
        if (terminal != null) {
            terminal.close();
            terminal = null;
        }
    }
}

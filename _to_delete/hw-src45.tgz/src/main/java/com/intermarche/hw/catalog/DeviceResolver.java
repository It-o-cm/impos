package com.intermarche.hw.catalog;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import com.intermarche.hw.catalog.HardwareProfile.Confidence;
import com.intermarche.hw.catalog.HardwareProfile.Role;
import com.intermarche.hw.discovery.DeviceNode;
import com.intermarche.hw.discovery.Inventory;
import com.intermarche.hw.discovery.UsbDevice;
import com.intermarche.hw.discovery.UsbInterface;

/**
 * Turns a discovered device into ranked hypotheses.
 *
 * <p>Two families of evidence are combined and every piece is kept with the candidate
 * it produced, so the operator can see why the daemon believes what it believes:
 * <ul>
 *   <li>the catalog, queried at its three levels (exact model, vendor, keyword);</li>
 *   <li>what the bus declares by itself: printer interface class, HID POS usage page,
 *       the keyboard-plus-vendor-interface pattern typical of scanners in keyboard
 *       emulation, CDC virtual serial functions.</li>
 * </ul>
 * Only passive evidence is used here: nothing is written to any device. Active probes
 * (ESC/POS identification, drawer kick test, calibration barcode) are a later step
 * that confirms a PROPOSED resolution.
 */
public final class DeviceResolver {

    private final ProfileCatalog catalog;

    /**
     * Creates a resolver over a catalog.
     *
     * @param catalog the profiles to match against
     */
    public DeviceResolver(ProfileCatalog catalog) {
        this.catalog = catalog;
    }

    /**
     * Resolves every device of an inventory.
     *
     * @param inventory the discovered inventory
     * @return one resolution per device, in inventory order
     */
    public List<Resolution> resolveAll(Inventory inventory) {
        return inventory.devices().stream().map(this::resolve).toList();
    }

    /**
     * Resolves one device.
     *
     * @param device the device
     * @return its candidates and verdict
     */
    public Resolution resolve(UsbDevice device) {
        List<Candidate> candidates = new ArrayList<>();
        for (HardwareProfile p : catalog.matching(device.vidPid(), device.manufacturer(), device.product())) {
            candidates.add(new Candidate(p.role(), p.driver(), p.confidence(),
                    "catalog " + p.matchKind() + " " + p.matchValue()));
        }
        addBusEvidence(device, candidates);
        candidates.sort(Comparator.comparing(Candidate::confidence));
        return new Resolution(device, List.copyOf(candidates), verdict(candidates));
    }

    /**
     * Adds the hypotheses the bus alone supports, without any catalog knowledge.
     *
     * @param device the device
     * @param out    collector for the candidates
     */
    private void addBusEvidence(UsbDevice device, List<Candidate> out) {
        boolean keyboard = false;
        boolean vendorHid = false;
        for (UsbInterface itf : device.interfaces()) {
            if (itf.isPrinterClass()) {
                out.add(new Candidate(Role.PRINTER, null, Confidence.MEDIUM,
                        "USB printer class on interface " + itf.number()));
            } else if (itf.nodes().stream().anyMatch(n -> n.kind() == DeviceNode.Kind.LP)) {
                out.add(new Candidate(Role.PRINTER, null, Confidence.MEDIUM,
                        "vendor-class interface " + itf.number() + " claimed by usblp (Epson-style printer)"));
            }
            if (itf.declaresUsagePage(DeviceNode.USAGE_PAGE_IBM_POS)) {
                out.add(new Candidate(Role.SCANNER, "IBM_HID", Confidence.MEDIUM,
                        "IBM POS usage page 0xff45 on interface " + itf.number()
                                + " (IBM hand-held / table-top USB mode)"));
            }
            if (itf.declaresUsagePage(DeviceNode.USAGE_PAGE_POS)) {
                out.add(new Candidate(Role.SCANNER, "HID_POS", Confidence.STRONG,
                        "HID POS usage page 0x8C on interface " + itf.number()));
            }
            if (itf.isHidKeyboard()) {
                keyboard = true;
            }
            if (itf.isHidNonBoot() && itf.nodes().stream().anyMatch(DeviceNode::hasVendorUsagePage)) {
                vendorHid = true;
            }
            if (itf.nodes().stream().anyMatch(n -> n.kind() == DeviceNode.Kind.TTY)) {
                out.add(new Candidate(null, "SERIAL_PROBE", Confidence.WEAK,
                        (itf.isCdc() ? "CDC virtual serial" : "USB-serial adapter " + itf.driver())
                                + " on interface " + itf.number() + ": the device behind needs a protocol probe"));
            }
        }
        if (keyboard && vendorHid) {
            out.add(new Candidate(Role.SCANNER, "HID_KEYBOARD", Confidence.MEDIUM,
                    "keyboard interface plus vendor HID interface: keyboard-emulation scanner pattern"));
        }
    }

    /**
     * Derives the verdict from the strongest candidate.
     *
     * @param sorted candidates ordered strongest first
     * @return the verdict
     */
    private static Resolution.Verdict verdict(List<Candidate> sorted) {
        if (sorted.isEmpty()) {
            return Resolution.Verdict.UNKNOWN;
        }
        Candidate best = sorted.get(0);
        if (best.role() == Role.IGNORE) {
            return Resolution.Verdict.IGNORED;
        }
        if (best.role() != null && best.confidence() == Confidence.STRONG) {
            return Resolution.Verdict.IDENTIFIED;
        }
        return sorted.stream().anyMatch(c -> c.role() != null)
                ? Resolution.Verdict.PROPOSED
                : Resolution.Verdict.UNKNOWN;
    }
}

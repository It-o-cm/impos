package com.intermarche.hw.discovery;

import java.util.List;

/**
 * One interface of a USB device, with the kernel driver bound to it and the
 * device nodes that driver created.
 *
 * @param sysName         sysfs entry name, e.g. {@code 1-1.2:1.0}
 * @param number          bInterfaceNumber
 * @param interfaceClass  bInterfaceClass, 2 hex digits
 * @param subClass        bInterfaceSubClass, 2 hex digits
 * @param protocol        bInterfaceProtocol, 2 hex digits
 * @param driver          kernel driver name, may be {@code null} when unbound
 * @param nodes           device nodes created under this interface
 */
public record UsbInterface(
        String sysName,
        int number,
        String interfaceClass,
        String subClass,
        String protocol,
        String driver,
        List<DeviceNode> nodes) {

    /** USB printer class. */
    public static final String CLASS_PRINTER = "07";
    /** USB HID class. */
    public static final String CLASS_HID = "03";
    /** USB CDC communications class. */
    public static final String CLASS_CDC = "02";
    /** USB CDC data class. */
    public static final String CLASS_CDC_DATA = "0a";
    /** HID boot protocol: keyboard. */
    public static final String PROTOCOL_KEYBOARD = "01";
    /** HID boot protocol: mouse. */
    public static final String PROTOCOL_MOUSE = "02";

    /**
     * Tells whether this interface declares the USB printer class.
     *
     * @return {@code true} for class 07
     */
    public boolean isPrinterClass() {
        return CLASS_PRINTER.equals(interfaceClass);
    }

    /**
     * Tells whether this interface is a HID boot keyboard.
     *
     * @return {@code true} for class 03 / protocol 01
     */
    public boolean isHidKeyboard() {
        return CLASS_HID.equals(interfaceClass) && PROTOCOL_KEYBOARD.equals(protocol);
    }

    /**
     * Tells whether this interface is a HID interface that is neither a keyboard nor a mouse.
     *
     * @return {@code true} for class 03 with protocol 00 or any non-boot protocol
     */
    public boolean isHidNonBoot() {
        return CLASS_HID.equals(interfaceClass)
                && !PROTOCOL_KEYBOARD.equals(protocol)
                && !PROTOCOL_MOUSE.equals(protocol);
    }

    /**
     * Tells whether this interface belongs to a CDC (virtual serial) function.
     *
     * @return {@code true} for class 02 or 0a
     */
    public boolean isCdc() {
        return CLASS_CDC.equals(interfaceClass) || CLASS_CDC_DATA.equals(interfaceClass);
    }

    /**
     * Looks for a HID node declaring the given usage page anywhere in its report descriptor.
     *
     * @param usagePage the HID usage page to look for
     * @return {@code true} if one hidraw node under this interface declares it
     */
    public boolean declaresUsagePage(int usagePage) {
        return nodes.stream().anyMatch(n -> n.hidUsagePages().contains(usagePage));
    }
}

package com.intermarche.hw.discovery;

import com.intermarche.hw.driver.PortIoDrawer;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * Finds the cash-drawer port built into a Diebold Nixdorf terminal.
 *
 * <p>This drawer hangs on an I2C GPIO extender on the mainboard. It has no bus
 * identity, no device node and no descriptive string: the inventory cannot see it,
 * and a till carrying one looks exactly like a till carrying none. Three pieces of
 * evidence, in increasing strength, say otherwise.
 *
 * <p>The DMI identity names the terminal, which is what decides whether a drawer
 * port exists at all on this model. The vendor helper on disk only ships with that
 * stack, so its presence is a second, independent sign. And the helper itself does
 * the real diagnosis at start-up: it walks the I2C buses looking for the extender,
 * says so, and exits when it finds none — so starting it and watching it survive
 * PROVES the port, without opening anything. That last step is the active proof,
 * and it only runs when the caller allows it.
 */
public final class DrawerPortProbe implements PlatformProbe {

    /** Role this probe fills. */
    public static final String ROLE = "DRAWER";

    /** Driver serving that role. */
    public static final String DRIVER = "DN_PORTIO";

    /** DMI vendor string of the terminals carrying this port. */
    private static final String VENDOR = "diebold";

    /** How long the helper is given to come up and create its pipe. */
    private static final long STARTUP_GRACE_MS = 1200;

    /** {@inheritDoc} */
    @Override
    public String name() {
        return "terminal cash-drawer port (Diebold Nixdorf)";
    }

    /** {@inheritDoc} */
    @Override
    public PlatformFinding probe(PlatformContext context) {
        List<String> evidence = new ArrayList<>();
        MachineIdentity machine = MachineIdentity.read(context.sysRoot());
        if (machine.isKnown()) {
            evidence.add("DMI: " + machine.describe());
        }
        Path helper = context.root().resolve(PortIoDrawer.HELPER);
        if (!Files.isExecutable(helper)) {
            evidence.add("vendor helper absent: " + helper);
            return PlatformFinding.absent(ROLE, DRIVER,
                    "no drawer port on this terminal, or the vendor stack is not installed",
                    evidence);
        }
        evidence.add("vendor helper present: " + helper);
        if (machine.vendor().toLowerCase(java.util.Locale.ROOT).contains(VENDOR)) {
            evidence.add("terminal is a " + machine.describe() + ", which carries a drawer port");
        }
        if (!context.active()) {
            return PlatformFinding.proposed(ROLE, DRIVER,
                    "helper installed; run the active probe to prove the port answers", evidence);
        }
        return exercise(context, helper, evidence);
    }

    /**
     * Runs the helper and watches it survive, which is the proof the I2C extender
     * answered. Nothing is opened: the drawer stays shut throughout.
     *
     * @param context  what may be read
     * @param helper   the vendor helper
     * @param evidence the evidence collected so far, appended to
     * @return the finding, confirmed when the helper came up
     */
    private PlatformFinding exercise(PlatformContext context, Path helper, List<String> evidence) {
        Path pipe = context.root().resolve(PortIoDrawer.TO_DAEMON);
        Process process = null;
        try {
            process = new ProcessBuilder(List.of(helper.toString(), "-b"))
                    .redirectErrorStream(true)
                    .redirectOutput(ProcessBuilder.Redirect.DISCARD)
                    .start();
            context.log().accept("platform     started " + helper + " -b for the active probe");
            Thread.sleep(STARTUP_GRACE_MS);
        } catch (IOException e) {
            evidence.add("helper could not be started: " + e.getMessage());
            return PlatformFinding.absent(ROLE, DRIVER, "the vendor helper refused to start", evidence);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            evidence.add("active probe interrupted");
            return PlatformFinding.proposed(ROLE, DRIVER, "active probe interrupted", evidence);
        } finally {
            if (process != null) {
                process.destroy();
            }
        }
        if (!Files.exists(pipe)) {
            evidence.add("helper started but created no pipe: it found no I2C drawer interface");
            return PlatformFinding.absent(ROLE, DRIVER,
                    "this terminal has the vendor stack but no drawer port", evidence);
        }
        evidence.add("helper came up and opened " + pipe);
        return PlatformFinding.confirmed(ROLE, DRIVER,
                "drawer port present; opened by writing '1' on the helper's pipe", evidence);
    }
}

package com.intermarche.hw.serve;

import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

/**
 * A print body, split into what the printer must be asked to do.
 *
 * <p>The POS formats receipts as plain text and knows nothing of ESC/POS -- that is the
 * whole point of the hardware boundary. But a receipt is not only text: it carries a
 * logo at the top and a barcode of its number at the bottom. Rather than open the
 * contract to binary and let the POS build printer commands, the body stays text and a
 * line of its own may carry a directive:
 * <pre>
 * [[BARCODE POS01-00000042]]
 * [[IMAGE 384 96 iVBORw0K...]]        width, height, base64 of the packed rows
 * </pre>
 * Everything else is text and prints as text. A directive that cannot be read is left
 * alone and prints as the text it is, which is how a malformed one shows up on the
 * receipt instead of vanishing.
 */
public final class ReceiptBody {

    /** What a segment of a print body asks for. */
    public enum Kind {

        /** Text, printed as it is. */
        TEXT,

        /** A barcode of the segment's value. */
        BARCODE,

        /** An image, carried by the segment's own fields. */
        IMAGE
    }

    /**
     * One piece of a print body.
     *
     * @param kind   what to do with it
     * @param text   the text to print, or the value to encode; empty for an image
     * @param width  image width in pixels, 0 unless this is an image
     * @param height image height in pixels, 0 unless this is an image
     * @param bits   the packed image rows, empty unless this is an image
     */
    public record Segment(Kind kind, String text, int width, int height, byte[] bits) {
    }

    /** Opening of a directive line. */
    private static final String OPEN = "[[";

    /** Closing of a directive line. */
    private static final String CLOSE = "]]";

    /** Directive asking for a barcode. */
    private static final String BARCODE = "BARCODE ";

    /** Directive asking for an image. */
    private static final String IMAGE = "IMAGE ";

    /** Fields an image directive carries: width, height and the packed rows. */
    private static final int IMAGE_FIELDS = 3;

    /** Not instantiable: this class only splits bodies. */
    private ReceiptBody() {
    }

    /**
     * Splits a print body into its segments, in order.
     *
     * <p>Consecutive text lines are gathered into one segment, so a receipt with no
     * directive at all is printed by a single call, exactly as before directives
     * existed.
     *
     * @param body the print body
     * @return the segments, in the order they must be printed
     */
    public static List<Segment> split(String body) {
        List<Segment> segments = new ArrayList<>();
        StringBuilder text = new StringBuilder();
        for (String line : body.split("\n", -1)) {
            Segment directive = directive(line.trim());
            if (directive == null) {
                text.append(line).append('\n');
                continue;
            }
            flush(segments, text);
            segments.add(directive);
        }
        flush(segments, text);
        return segments;
    }

    /**
     * Reads a line as a directive.
     *
     * @param line the trimmed line
     * @return the segment it asks for, or {@code null} when it is not a directive
     */
    private static Segment directive(String line) {
        if (!line.startsWith(OPEN) || !line.endsWith(CLOSE)) {
            return null;
        }
        String inside = line.substring(OPEN.length(), line.length() - CLOSE.length()).trim();
        if (inside.startsWith(BARCODE)) {
            String value = inside.substring(BARCODE.length()).trim();
            return value.isEmpty() ? null : new Segment(Kind.BARCODE, value, 0, 0, new byte[0]);
        }
        if (inside.startsWith(IMAGE)) {
            return image(inside.substring(IMAGE.length()).trim());
        }
        return null;
    }

    /**
     * Reads the three fields of an image directive.
     *
     * @param fields the directive's arguments
     * @return the segment, or {@code null} when the fields cannot be read -- a number
     *         that is not one and a base64 payload that is not one both raise
     *         {@link IllegalArgumentException}, so one catch covers both
     */
    private static Segment image(String fields) {
        String[] parts = fields.split("\\s+", IMAGE_FIELDS);
        if (parts.length != IMAGE_FIELDS) {
            return null;
        }
        try {
            int width = Integer.parseInt(parts[0]);
            int height = Integer.parseInt(parts[1]);
            byte[] bits = Base64.getDecoder().decode(parts[2]);
            if (width <= 0 || height <= 0) {
                return null;
            }
            return new Segment(Kind.IMAGE, "", width, height, bits);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    /**
     * Turns the text gathered so far into a segment, if there is any.
     *
     * @param segments the segments being built
     * @param text     the text gathered since the last directive
     */
    private static void flush(List<Segment> segments, StringBuilder text) {
        if (text.length() > 0) {
            segments.add(new Segment(Kind.TEXT, text.toString(), 0, 0, new byte[0]));
            text.setLength(0);
        }
    }
}

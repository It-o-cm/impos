package com.intermarche.hw.discovery;

import java.util.ArrayList;
import java.util.List;

/**
 * The second channel of discovery: hardware no bus declares.
 *
 * <p>{@link SysfsInventory} walks the buses and finds what is plugged in.
 * This walks a list of {@link PlatformProbe}s and finds what is built in. Adding
 * a device to the second channel is adding a probe to {@link #PROBES} — no other
 * file changes, which is the point of the split.
 */
public final class PlatformInventory {

    /**
     * The probes, in report order. One entry per kind of built-in hardware the
     * project knows how to recognise.
     */
    private static final List<PlatformProbe> PROBES = List.of(new DrawerPortProbe());

    /**
     * Not instantiable: this is the entry point of a scan, not a thing.
     */
    private PlatformInventory() {
    }

    /**
     * Runs every probe.
     *
     * @param context what may be read, and whether the hardware may be exercised
     * @return one finding per probe, in report order
     */
    public static List<PlatformFinding> scan(PlatformContext context) {
        List<PlatformFinding> findings = new ArrayList<>();
        for (PlatformProbe probe : PROBES) {
            findings.add(probe.probe(context));
        }
        return findings;
    }

    /**
     * The probes this build knows, for a report that wants to name them.
     *
     * @return the probes, in report order
     */
    public static List<PlatformProbe> probes() {
        return PROBES;
    }
}

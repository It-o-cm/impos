package com.intermarche.hw.driver;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.function.Consumer;

/**
 * The cash drawer of a Diebold Nixdorf BEETLE, on the terminal's own mini-DIN port.
 *
 * <p>The port is not reachable from user space directly: it hangs on an I2C GPIO
 * extender, and the vendor ships a small setuid helper, {@code dn-portio}, as the only
 * supported way in. Started with {@code -b} it becomes a daemon and takes single-letter
 * orders on a named pipe — {@code '1'} opens drawer 1, {@code '2'} drawer 2, {@code 's'}
 * asks for the state, {@code 'e'} stops it. That pipe is what this class writes to, which
 * is exactly what the vendor's own JavaPOS service does underneath.
 *
 * <p>Two consequences of the helper's design shape this code. Its watchdog kills the
 * daemon as soon as the process that launched it disappears, so the daemon must be
 * started BY the long-lived process that will use it — never by a shell that exits.
 * And a write to a pipe nobody reads blocks forever, so every exchange runs under a
 * timeout rather than trusting the daemon to be alive.
 */
public final class PortIoDrawer implements CashDrawer {

    /** The vendor helper, the only supported access to the mini-DIN port. */
    public static final Path DEFAULT_BINARY = Path.of("/opt/dn/javapos/bin/dn-portio");

    /** Pipe carrying the orders to the daemon, at the helper's own default location. */
    public static final Path DEFAULT_TO_DAEMON = Path.of("/var/opt/wn/fifos/fifo_to_portiod");

    /** Pipe carrying the daemon's answers. */
    public static final Path DEFAULT_FROM_DAEMON = Path.of("/var/opt/wn/fifos/fifo_from_portiod");

    /** Order opening drawer 1. */
    private static final byte OPEN_DRAWER_1 = '1';

    /** Order asking for the state of both drawer ports. */
    private static final byte ASK_STATUS = 's';

    /** Delay left to the reader to be in place before the order is sent. */
    private static final Duration READER_GRACE = Duration.ofMillis(200);

    /** How long the daemon is given to come up before the first order. */
    private static final Duration STARTUP_GRACE = Duration.ofMillis(1200);

    /** The helper binary. */
    private final Path binary;

    /** The order pipe. */
    private final Path toDaemon;

    /** The answer pipe. */
    private final Path fromDaemon;

    /** Maximum wait for one exchange with the daemon. */
    private final Duration timeout;

    /** Where the driver narrates what it did. */
    private final Consumer<String> log;

    /**
     * Runs the blocking pipe access, so a dead daemon times out instead of hanging.
     * Two threads, because a status exchange needs the reader in place BEFORE the
     * order is written — a pipe drops what nobody is reading.
     */
    private final ExecutorService io = Executors.newFixedThreadPool(2, r -> {
        Thread t = new Thread(r, "portio-drawer");
        t.setDaemon(true);
        return t;
    });

    /** The daemon this instance started, or {@code null} when it was already running. */
    private Process daemon;

    /**
     * Builds a drawer on the vendor helper's default locations.
     *
     * @param timeout maximum wait for one exchange with the daemon
     * @param log     destination of the driver's log lines
     */
    public PortIoDrawer(Duration timeout, Consumer<String> log) {
        this(DEFAULT_BINARY, DEFAULT_TO_DAEMON, DEFAULT_FROM_DAEMON, timeout, log);
    }

    /**
     * Builds a drawer on explicit locations.
     *
     * @param binary     the vendor helper
     * @param toDaemon   the order pipe
     * @param fromDaemon the answer pipe
     * @param timeout    maximum wait for one exchange with the daemon
     * @param log        destination of the driver's log lines
     */
    public PortIoDrawer(Path binary, Path toDaemon, Path fromDaemon, Duration timeout,
            Consumer<String> log) {
        this.binary = binary;
        this.toDaemon = toDaemon;
        this.fromDaemon = fromDaemon;
        this.timeout = timeout;
        this.log = log;
    }

    /**
     * Tells whether this till carries the vendor helper at all.
     *
     * @return true when the helper is present and executable
     */
    public boolean isPresent() {
        return Files.isExecutable(binary);
    }

    /** {@inheritDoc} */
    @Override
    public void open() throws IOException {
        ensureDaemon();
        send(OPEN_DRAWER_1);
    }

    /**
     * {@inheritDoc}
     *
     * <p>Still {@code null} on purpose, but no longer blind: the raw answer is read and
     * logged at every call. The daemon answers {@code 's'} with a byte covering BOTH
     * drawer ports, and which bit carries port 1 has not been measured on a real drawer.
     * A guessed mapping would trap the POS behind its drawer guard, so the value is
     * reported and not interpreted. Once the byte is known open and closed, this method
     * is the only one to change.
     */
    @Override
    public Boolean isOpen() {
        try {
            String raw = rawStatus();
            log.accept("drawer       status answer " + raw + " (mapping to port 1 not measured yet)");
        } catch (IOException e) {
            log.accept("drawer       status unreadable: " + e.getMessage());
        }
        return null;
    }

    /**
     * Asks the daemon for the state of both drawer ports and returns its answer
     * verbatim, e.g. {@code 0x80}.
     *
     * <p>The reader is put in place before the order is written: the answer travels on
     * a second pipe, and a pipe nobody reads drops what is written to it.
     *
     * @return the daemon's answer, trimmed
     * @throws IOException if the daemon does not answer within the timeout
     */
    public String rawStatus() throws IOException {
        ensureDaemon();
        Future<String> answer = io.submit(this::readAnswer);
        sleep(READER_GRACE);
        send(ASK_STATUS);
        try {
            String raw = answer.get(timeout.toMillis(), TimeUnit.MILLISECONDS);
            return raw == null ? "" : raw.trim();
        } catch (TimeoutException e) {
            answer.cancel(true);
            throw new IOException("no answer on " + fromDaemon);
        } catch (InterruptedException e) {
            answer.cancel(true);
            Thread.currentThread().interrupt();
            throw new IOException("interrupted while reading the drawer status");
        } catch (java.util.concurrent.ExecutionException e) {
            throw new IOException("drawer status failed: " + e.getCause(), e.getCause());
        }
    }

    /**
     * Reads one answer from the daemon's pipe.
     *
     * @return what the daemon wrote
     * @throws IOException if the pipe cannot be read
     */
    private String readAnswer() throws IOException {
        try (java.io.InputStream in = Files.newInputStream(fromDaemon)) {
            byte[] buffer = new byte[64];
            int read = in.read(buffer);
            return read <= 0 ? "" : new String(buffer, 0, read, java.nio.charset.StandardCharsets.US_ASCII);
        }
    }

    /** {@inheritDoc} */
    @Override
    public void close() {
        io.shutdownNow();
        if (daemon != null) {
            daemon.destroy();
            daemon = null;
        }
    }

    /**
     * Starts the helper in daemon mode unless its order pipe is already there.
     *
     * <p>The daemon is started as a CHILD of this process on purpose: its watchdog polls
     * the parent and exits with it, which is what keeps a stray daemon from surviving the
     * bridge.
     *
     * @throws IOException if the helper cannot be started
     */
    private void ensureDaemon() throws IOException {
        if (Files.exists(toDaemon)) {
            return;
        }
        if (!isPresent()) {
            throw new IOException("vendor helper not found: " + binary);
        }
        daemon = new ProcessBuilder(List.of(binary.toString(), "-b"))
                .redirectErrorStream(true)
                .redirectOutput(ProcessBuilder.Redirect.DISCARD)
                .start();
        log.accept("drawer       started " + binary + " -b");
        sleep(STARTUP_GRACE);
        if (!Files.exists(toDaemon)) {
            throw new IOException("daemon did not create " + toDaemon);
        }
    }

    /**
     * Writes one order on the pipe, under a timeout.
     *
     * @param order the single-letter order
     * @throws IOException if the pipe cannot be written, or nobody is reading it
     */
    private void send(byte order) throws IOException {
        Future<?> task = io.submit(() -> {
            try (OutputStream out = Files.newOutputStream(toDaemon)) {
                out.write(order);
                out.flush();
            }
            return null;
        });
        try {
            task.get(timeout.toMillis(), TimeUnit.MILLISECONDS);
        } catch (TimeoutException e) {
            task.cancel(true);
            throw new IOException("no reader on " + toDaemon + ": the daemon is gone");
        } catch (InterruptedException e) {
            task.cancel(true);
            Thread.currentThread().interrupt();
            throw new IOException("interrupted while commanding the drawer");
        } catch (java.util.concurrent.ExecutionException e) {
            throw new IOException("drawer order failed: " + e.getCause(), e.getCause());
        }
    }

    /**
     * Sleeps, turning an interruption into an early return.
     *
     * @param d how long to sleep
     */
    private static void sleep(Duration d) {
        try {
            Thread.sleep(d.toMillis());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}

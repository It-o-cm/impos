package com.intermarche.pos.ui.hardware.scanner;

import org.jboss.logging.Logger;

import java.util.function.Consumer;

/**
 * Assembles barcode strings from the raw HID input reports of a scanner in
 * IBM HAND-HELD USB mode — the counterpart of {@link KeyboardScancodeDecoder}
 * for the non-keyboard channel.
 * <p>
 * That mode is what the Symbol/Zebra units of the target tills run: two HID
 * interfaces on the IBM vendor usage page (0xff45), no keyboard emulation (so
 * nothing leaks to whatever holds the focus) and no HID-POS usage page. The
 * scanner emits on its own trigger, with no host activation command.
 * <p>
 * Frame layout, observed on the reference unit (64-byte reports):
 * <pre>
 *   [0] 0x12   frame identifier
 *   [1] len    number of bytes that follow (0x10 = 16 for an EAN-13)
 *   [2] sym    symbology (0x03 = EAN-13)
 *   [3] flags  (0x00 observed)
 *   [4..]      the code, ONE CHARACTER PER BYTE
 *   [.]  0x16  terminator
 *   ...        zero padding to the report size
 * </pre>
 * The character bytes are RAW VALUES, not ASCII: a digit arrives as 0x00–0x09,
 * so {@code 3178530403022} is {@code 03 01 07 08 …}. Bytes in the printable
 * ASCII range are taken verbatim, which is the working hypothesis for the
 * non-numeric symbologies (alphanumeric badge, Code 128, QR) whose encoding
 * this unit has not yet been observed emitting. Anything else makes the frame
 * undecodable: it is logged in hex rather than pushed as a wrong code — a
 * scan the register misreads is worse than a scan it refuses.
 * <p>
 * ONE FORMAT, BUT NO SILENT UNKNOWN. Another scanner model, or another mode,
 * may frame its reports differently — this decoder cannot translate a format
 * it has never seen, and must never pretend to. What it does guarantee is
 * that such a frame is VISIBLE: a report that is not this format is dumped in
 * hex (the first {@link #MAX_UNKNOWN_TRACES} of them per device, so an
 * unexpected talker cannot flood the log), which is exactly what is needed to
 * add its format here. Idle all-zero reports are the one thing dropped in
 * silence — they carry nothing and every unit sends them.
 */
public class HidBarcodeDecoder {

    /** The class logger. */
    private static final Logger LOG = Logger.getLogger(HidBarcodeDecoder.class);

    /** First byte of a data frame. */
    static final int FRAME_ID = 0x12;

    /** Last byte of the announced payload. */
    static final int TERMINATOR = 0x16;

    /** Bytes before the announced payload: the identifier and the length. */
    private static final int HEADER_SIZE = 2;

    /** Payload bytes that are not code characters: symbology, flags, terminator. */
    private static final int PAYLOAD_OVERHEAD = 3;

    /** How many unrecognized reports are dumped per device before going quiet. */
    static final int MAX_UNKNOWN_TRACES = 5;

    /** Unrecognized reports seen on this device, whether traced or not. */
    private int unknownFrames;

    /** The receiver of each completed code. */
    private final Consumer<String> onCode;

    /**
     * Creates a decoder delivering completed codes to the given receiver.
     *
     * @param onCode the receiver of each completed, non-empty code
     */
    public HidBarcodeDecoder(Consumer<String> onCode) {
        this.onCode = onCode;
    }

    /**
     * Consumes one HID input report and emits the code it carries, when it
     * carries one. A frame is self-contained: one report, one code. Anything
     * that is not a well-formed data frame is dropped — silently for a report
     * that is not ours (the second interface of the scanner, and the zero
     * reports some units send), with a hex trace when the frame IS ours but
     * its payload cannot be decoded.
     *
     * @param report the report bytes
     * @param length the number of valid bytes in the report
     */
    public void feed(byte[] report, int length) {
        if (length < HEADER_SIZE || isIdle(report, length)) {
            return;
        }
        if ((report[0] & 0xFF) != FRAME_ID) {
            traceUnknown(report, length);
            return;
        }
        int payloadLength = report[1] & 0xFF;
        if (payloadLength < PAYLOAD_OVERHEAD || HEADER_SIZE + payloadLength > length) {
            LOG.warnf("Trame douchette de longueur incoherente (len=%d, recu=%d): %s",
                    payloadLength, length, hex(report, length));
            return;
        }
        int terminatorIndex = HEADER_SIZE + payloadLength - 1;
        if ((report[terminatorIndex] & 0xFF) != TERMINATOR) {
            LOG.warnf("Trame douchette sans terminateur 0x16: %s", hex(report, length));
            return;
        }
        String code = decodeCharacters(report, HEADER_SIZE + 2, terminatorIndex);
        if (code == null) {
            LOG.warnf("Trame douchette non decodable (symbologie 0x%02X): %s",
                    report[HEADER_SIZE] & 0xFF, hex(report, length));
            return;
        }
        if (!code.isEmpty()) {
            onCode.accept(code);
        }
    }

    /**
     * Whether the report is an idle one — every byte zero. Units send these
     * between scans; they carry nothing, so they are the only reports dropped
     * without a trace.
     *
     * @param report the report bytes
     * @param length the number of valid bytes
     * @return true when every byte is zero
     */
    private boolean isIdle(byte[] report, int length) {
        for (int i = 0; i < length; i++) {
            if (report[i] != 0) {
                return false;
            }
        }
        return true;
    }

    /**
     * Records a report this decoder does not recognize, dumping the first few
     * in hex so an unknown frame format can be read and supported instead of
     * vanishing. Past {@link #MAX_UNKNOWN_TRACES} the device is assumed to be
     * a steady talker and only the running count is kept.
     *
     * @param report the report bytes
     * @param length the number of valid bytes
     */
    private void traceUnknown(byte[] report, int length) {
        unknownFrames++;
        if (unknownFrames <= MAX_UNKNOWN_TRACES) {
            LOG.warnf("Trame douchette de format inconnu (#%d): %s",
                    unknownFrames, hex(report, length));
            if (unknownFrames == MAX_UNKNOWN_TRACES) {
                LOG.warn("Trames de format inconnu: trace interrompue (seul le compteur continue).");
            }
        }
    }

    /**
     * The number of unrecognized reports seen on this device — the signal
     * that a scanner is talking a format this decoder cannot translate.
     *
     * @return the count of unrecognized reports
     */
    int unknownFrameCount() {
        return unknownFrames;
    }

    /**
     * Decodes the character bytes of a frame: a raw digit value becomes its
     * digit, a printable ASCII byte is taken verbatim, anything else makes the
     * whole frame undecodable.
     *
     * @param report the report bytes
     * @param from the index of the first character byte, inclusive
     * @param to the index of the terminator, exclusive
     * @return the decoded code, or null when a byte could not be decoded
     */
    private String decodeCharacters(byte[] report, int from, int to) {
        StringBuilder text = new StringBuilder(to - from);
        for (int i = from; i < to; i++) {
            int b = report[i] & 0xFF;
            if (b <= 9) {
                text.append((char) ('0' + b));
            } else if (b >= 0x20 && b <= 0x7E) {
                text.append((char) b);
            } else {
                return null;
            }
        }
        return text.toString();
    }

    /**
     * Renders a report in hex, for the trace of a frame that could not be
     * decoded — the only way to learn an unobserved symbology's encoding.
     *
     * @param report the report bytes
     * @param length the number of valid bytes
     * @return the space-separated hex dump
     */
    private String hex(byte[] report, int length) {
        StringBuilder dump = new StringBuilder(length * 3);
        for (int i = 0; i < length; i++) {
            if (i > 0) {
                dump.append(' ');
            }
            dump.append(String.format("%02X", report[i] & 0xFF));
        }
        return dump.toString();
    }
}

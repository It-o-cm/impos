package com.intermarche.hw.serve;

import java.io.IOException;
import java.nio.file.Path;
import java.time.Duration;
import java.util.function.Consumer;

import com.intermarche.hw.driver.CashDrawer;
import com.intermarche.hw.driver.EscPosPrinter;
import com.intermarche.hw.driver.ReceiptPrinter;
import com.intermarche.hw.driver.WeighingScale;

/**
 * The hardware surface the POS calls, one method per endpoint of its rest client.
 *
 * <p>The contract is not defined here: it belongs to impos, whose
 * {@code @RegisterRestClient} hardware client declares exactly six calls under
 * {@code /api/hardware} — {@code GET /weight}, {@code POST /display},
 * {@code POST /drawer/open}, {@code GET /drawer/status}, {@code POST /printer/print},
 * {@code POST /printer/cut} -- plus the payment pair added when the terminal was wired
 * in, {@code POST /payment} to start one and {@code GET /payment} to follow it. The
 * other endpoints of the POS test double (set-weight, drawer/close, printer/content,
 * printer/status) exist for its simulator page and are never called on a real hardware
 * bridge.
 *
 * <p>Answers on this till, per the bindings proven on 2026-09-04:
 * <ul>
 *   <li><b>printer</b> — real: ESC/POS on the node discovery picked. The node is opened
 *       for the request and released right after, so {@code printer-test} and the other
 *       commands can still open it between two receipts.</li>
 *   <li><b>drawer</b> — NOT on the printer. This till is a Diebold Nixdorf BEETLE: its
 *       drawer sits on the terminal's own mini-DIN port, behind an I2C GPIO extender,
 *       and the printer's kick connector is empty (pin 3 stays high, which is the
 *       signature of nothing plugged in). The order therefore goes through the vendor
 *       helper, {@link com.intermarche.hw.driver.PortIoDrawer}, and so does the state:
 *       bit {@code 0x40} of the helper's status byte, measured on the till.</li>
 *   <li><b>display</b> — the Diebold Nixdorf BA9x is present but its protocol is not
 *       known, so the text is logged and the call answers 501.</li>
 *   <li><b>scale</b> — real: a Checkout-Dialog-06 instrument on a serial port, bound
 *       when it answers its status record at start-up.</li>
 *   <li><b>payment</b> — real: a Verifone P400 owned by the vendor's payment client.
 *       Bound only when the site's two values are given, the acceptance point number and
 *       the island label, because neither can be guessed. The session is opened once at
 *       start-up and reopened by itself when it falls; a payment runs on its own thread
 *       and the POS follows it, so no request is held open for the length of a
 *       transaction.</li>
 * </ul>
 * Any role with no device bound answers 503 {@code NO_DEVICE_BOUND}; a bound device that
 * fails answers 503 with its own code, so an absent peripheral and a broken one are never
 * confused in the POS log.
 */
public final class HardwareEndpoints {

    /** Error code of a role that has no device bound to it. */
    static final String NO_DEVICE_BOUND = "NO_DEVICE_BOUND";

    /** Error code of a bound printer that could not be reached. */
    static final String PRINTER_ERROR = "PRINTER_ERROR";

    /** Error code of a scale that refused or could not be reached. */
    static final String SCALE_ERROR = "SCALE_ERROR";

    /**
     * Unit price sent with a weighing.
     *
     * <p>Zero, because the POS hardware contract has no price on {@code GET /weight}:
     * it asks for a weight, not for an amount. The scale therefore displays no amount
     * of its own. The day the contract carries the price, this is where it arrives.
     */
    private static final long NO_UNIT_PRICE = 0L;

    /** Grams in a kilogram, the unit the POS reads weights in. */
    private static final int GRAMS_PER_KILO = 1000;

    /** Error code of the display, present on the bus but not driven yet. */
    static final String DISPLAY_NOT_IMPLEMENTED = "DISPLAY_NOT_IMPLEMENTED";

    /** Error code of a drawer that could not be commanded. */
    static final String DRAWER_ERROR = "DRAWER_ERROR";

    /** Error code of a payment asked for while one is already running. */
    static final String PAYMENT_BUSY = "PAYMENT_BUSY";

    /** Error code of a payment request whose amount cannot be read. */
    static final String PAYMENT_AMOUNT = "PAYMENT_AMOUNT";

    /** Drawer status the POS reads as "open"; anything else is closed. */
    static final String DRAWER_OPEN = "OPEN";

    /** Drawer status meaning the till may go on selling. */
    static final String DRAWER_CLOSED = "CLOSED";

    /** The printer node chosen by discovery, or {@code null} when none was bound. */
    private final Path printerNode;

    /** The cash drawer, or {@code null} when this till has none bound. */
    private final CashDrawer drawer;

    /** The scale, or {@code null} when this till has none bound. */
    private final WeighingScale scale;

    /** The payment in progress, or {@code null} when this till has no terminal bound. */
    private final PaymentOperation payment;

    /** Reply timeout of the printer dialogue. */
    private final Duration timeout;

    /** Where the daemon narrates what it did, one line per call. */
    private final Consumer<String> log;

    /**
     * Builds the endpoints over the devices the daemon bound at startup.
     *
     * @param printerNode the receipt printer node, or {@code null} when discovery found none
     * @param drawer      the cash drawer, or {@code null} when this till has none
     * @param scale       the scale, or {@code null} when this till has none
     * @param payment     the payment operation, or {@code null} when this till has no
     *                    payment terminal bound
     * @param timeout     reply timeout of the printer dialogue
     * @param log         destination of the per-call log lines
     */
    public HardwareEndpoints(Path printerNode, CashDrawer drawer, WeighingScale scale,
            PaymentOperation payment, Duration timeout, Consumer<String> log) {
        this.printerNode = printerNode;
        this.drawer = drawer;
        this.scale = scale;
        this.payment = payment;
        this.timeout = timeout;
        this.log = log;
    }

    /**
     * Starts a card payment — {@code POST /payment}.
     *
     * <p>Answers as soon as the payment is under way, not when it ends: the outcome is
     * read from {@code GET /payment}. The body is the amount in cents, the unit the
     * specification's own request carries, so nothing is rounded on the way.
     *
     * @param amount the amount to ask for, in cents
     * @return 204 when the payment started, 503 when no terminal is bound, 409 when one
     *         payment is already running, 400 when the amount is not a positive number
     */
    public HttpReply startPayment(String amount) {
        if (payment == null) {
            return HttpReply.error(503, NO_DEVICE_BOUND);
        }
        long cents;
        try {
            cents = Long.parseLong(amount.trim());
        } catch (NumberFormatException e) {
            return HttpReply.error(400, PAYMENT_AMOUNT + ": not a number: " + amount);
        }
        if (cents <= 0) {
            return HttpReply.error(400, PAYMENT_AMOUNT + ": not positive: " + cents);
        }
        if (!payment.start(cents)) {
            return HttpReply.error(409, PAYMENT_BUSY);
        }
        log.accept("tpe          payment started for " + cents + " cents");
        return HttpReply.done();
    }

    /**
     * Reads where the payment stands — {@code GET /payment}.
     *
     * @return 200 with the state, the two display lines and the result once there is
     *         one, 503 when no terminal is bound
     */
    public HttpReply paymentStatus() {
        if (payment == null) {
            return HttpReply.error(503, NO_DEVICE_BOUND);
        }
        return HttpReply.text(payment.report());
    }

    /**
     * Reads the scale — {@code GET /weight}.
     *
     * <p>The weight is returned in kilograms with a French decimal comma, the form the
     * POS parses. A refusal — the commonest being an article that has not moved since
     * the previous weighing, which the instrument refuses by design — answers 503 with
     * its cause rather than a weight: a fabricated 0 would read as "nothing on the
     * plate" and hide it.
     *
     * @return 200 with the weight in kilograms, or 503 when no scale is bound or the
     *         weighing did not happen
     */
    public HttpReply weight() {
        if (scale == null) {
            return HttpReply.error(503, NO_DEVICE_BOUND);
        }
        try {
            WeighingScale.Reading reading = scale.weigh(NO_UNIT_PRICE);
            if (reading.grams() == null) {
                log.accept("scale        answered no weight: " + reading.rawFrames());
                return HttpReply.error(503, SCALE_ERROR + ": no weight in the answer");
            }
            log.accept("scale        " + reading.grams() + " g");
            return HttpReply.text(kilograms(reading.grams()));
        } catch (IOException e) {
            log.accept("scale        weighing failed: " + e.getMessage());
            return HttpReply.error(503, SCALE_ERROR + ": " + e.getMessage());
        }
    }

    /**
     * Formats a weight the way the POS reads it.
     *
     * @param grams the net weight in grams
     * @return the weight in kilograms, with a decimal comma and three decimals
     */
    private static String kilograms(int grams) {
        return grams / GRAMS_PER_KILO + "," + String.format("%03d", Math.abs(grams % GRAMS_PER_KILO));
    }

    /**
     * Shows a text on the customer display — {@code POST /display}.
     *
     * <p>The BA9x is on the bus but its protocol is not known yet, so the text is logged
     * and the call answers "not implemented" rather than pretending to have displayed it.
     *
     * @param text the text the POS wants displayed
     * @return 501 {@code DISPLAY_NOT_IMPLEMENTED}
     */
    public HttpReply display(String text) {
        log.accept("display      (not implemented) " + text);
        return HttpReply.error(501, DISPLAY_NOT_IMPLEMENTED);
    }

    /**
     * Fires the drawer-opening pulse — {@code POST /drawer/open}.
     *
     * <p>The order goes to whatever this till binds its drawer to — the terminal's own
     * port here, the printer's kick connector elsewhere.
     *
     * @return 204 when the order was sent, 503 when no drawer is bound or the order
     *         could not be delivered
     */
    public HttpReply openDrawer() {
        if (drawer == null) {
            log.accept("drawer       open refused: no drawer bound on this till");
            return HttpReply.error(503, NO_DEVICE_BOUND);
        }
        try {
            drawer.open();
            log.accept("drawer       opened");
            return HttpReply.done();
        } catch (IOException e) {
            log.accept("drawer       open failed: " + e.getMessage());
            return HttpReply.error(503, DRAWER_ERROR + ": " + e.getMessage());
        }
    }

    /**
     * Reads the drawer state — {@code GET /drawer/status}.
     *
     * <p>A binding that cannot tell answers CLOSED rather than OPEN: an invented OPEN
     * would keep the POS behind its drawer guard for ever.
     *
     * @return 200 {@code OPEN} or {@code CLOSED}, 503 when no drawer is bound or the
     *         binding failed
     */
    public HttpReply drawerStatus() {
        if (drawer == null) {
            return HttpReply.error(503, NO_DEVICE_BOUND);
        }
        try {
            Boolean open = drawer.isOpen();
            if (open == null) {
                return HttpReply.text(DRAWER_CLOSED);
            }
            return HttpReply.text(open ? DRAWER_OPEN : DRAWER_CLOSED);
        } catch (IOException e) {
            log.accept("drawer       status failed: " + e.getMessage());
            return HttpReply.error(503, DRAWER_ERROR + ": " + e.getMessage());
        }
    }

    /**
     * Prints a receipt — {@code POST /printer/print}.
     *
     * @param content the 42-column text to print, possibly carrying the directives
     *                {@link ReceiptBody} reads
     * @return 204 when printed, 503 when no printer is bound or the printer failed
     */
    public HttpReply printTicket(String content) {
        return onPrinter("print", printer -> {
            for (ReceiptBody.Segment segment : ReceiptBody.split(content)) {
                switch (segment.kind()) {
                    case TEXT -> printer.printText(segment.text());
                    case BARCODE -> printer.printBarcode(segment.text());
                    case IMAGE -> printer.printImage(segment.width(), segment.height(),
                            segment.bits());
                }
            }
        });
    }

    /**
     * Feeds to the cut position and cuts the paper — {@code POST /printer/cut}.
     *
     * @return 204 when cut, 503 when no printer is bound or the printer failed
     */
    public HttpReply cutPaper() {
        return onPrinter("cut", ReceiptPrinter::cut);
    }

    /**
     * Runs one action on the receipt printer, opening the node for the call and
     * releasing it right after.
     *
     * @param what   the action name, for the log line
     * @param action the action to run on the open printer
     * @return 204 on success, 503 when unbound or on an I/O failure
     */
    private HttpReply onPrinter(String what, PrinterAction action) {
        if (printerNode == null) {
            log.accept("printer      " + what + " refused: no printer bound");
            return HttpReply.error(503, NO_DEVICE_BOUND);
        }
        try (ReceiptPrinter printer = new EscPosPrinter(printerNode, timeout)) {
            action.run(printer);
            log.accept("printer      " + what + " on " + printerNode);
            return HttpReply.done();
        } catch (IOException e) {
            log.accept("printer      " + what + " failed: " + e.getMessage());
            return HttpReply.error(503, PRINTER_ERROR + ": " + e.getMessage());
        }
    }

    /**
     * One action performed on an open receipt printer.
     */
    @FunctionalInterface
    private interface PrinterAction {

        /**
         * Runs the action.
         *
         * @param printer the open printer
         * @throws IOException if the device cannot be written
         */
        void run(ReceiptPrinter printer) throws IOException;
    }
}

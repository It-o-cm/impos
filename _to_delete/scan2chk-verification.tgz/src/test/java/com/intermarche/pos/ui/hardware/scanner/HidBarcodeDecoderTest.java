package com.intermarche.pos.ui.hardware.scanner;

import org.junit.jupiter.api.Test;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Unit tests for {@link HidBarcodeDecoder}: the assembly of barcodes from the
 * raw HID reports of a scanner in HID mode, across the three end-of-scan
 * signals the common modes use (CR/LF terminator, empty trailing report,
 * runaway guard).
 */
class HidBarcodeDecoderTest {

    /** Collects the emitted codes. */
    private final List<String> emitted = new ArrayList<>();

    /** The decoder under test. */
    private final HidBarcodeDecoder decoder = new HidBarcodeDecoder(emitted::add);

    /**
     * Builds a report from a string, padded to a fixed length with NULs (as a
     * real HID report is a fixed-size buffer).
     *
     * @param payload the printable payload
     * @param size the total report size
     * @return the report bytes
     */
    private static byte[] report(String payload, int size) {
        byte[] b = new byte[size];
        byte[] p = payload.getBytes(StandardCharsets.US_ASCII);
        System.arraycopy(p, 0, b, 0, p.length);
        return b;
    }

    /**
     * A single report carrying the barcode and a trailing CR emits the code
     * once, the NUL padding ignored (terminator arm).
     */
    @Test
    void singleReportWithCarriageReturn() {
        decoder.feed(report("3300000000001\r", 32), 32);
        assertEquals(List.of("3300000000001"), emitted);
    }

    /**
     * A barcode split across two reports assembles into one code, emitted on
     * the CR of the second (multi-report accumulation).
     */
    @Test
    void barcodeSplitAcrossReports() {
        decoder.feed(report("330000", 8), 8);
        decoder.feed(report("0000001\r", 8), 8);
        assertEquals(List.of("3300000000001"), emitted);
    }

    /**
     * A data report followed by an empty report emits the code (end-of-scan on
     * the empty trailing report — the printable==0 with pending arm).
     */
    @Test
    void dataThenEmptyReportEmits() {
        decoder.feed(report("12345678", 16), 16);
        decoder.feed(new byte[16], 16);
        assertEquals(List.of("12345678"), emitted);
    }

    /**
     * An LF terminator ends a scan as a CR does.
     */
    @Test
    void lineFeedTerminates() {
        decoder.feed(report("ABC123\n", 16), 16);
        assertEquals(List.of("ABC123"), emitted);
    }

    /**
     * Two scans in a row emit separately.
     */
    @Test
    void twoScansEmitSeparately() {
        decoder.feed(report("111\r", 8), 8);
        decoder.feed(report("222\r", 8), 8);
        assertEquals(List.of("111", "222"), emitted);
    }

    /**
     * A stream of printable bytes past {@link HidBarcodeDecoder#MAX_LENGTH}
     * with no terminator resets rather than growing without bound; a following
     * terminated scan still works.
     */
    @Test
    void runawayResetsThenRecovers() {
        byte[] big = new byte[256];
        java.util.Arrays.fill(big, (byte) 'A');
        for (int i = 0; i < (HidBarcodeDecoder.MAX_LENGTH / 256) + 2; i++) {
            decoder.feed(big, big.length);
        }
        decoder.feed(report("77\r", 8), 8);
        assertTrue(emitted.contains("77"));
    }
}

package com.intermarche.pos.ui.hardware.scanner;

import java.util.function.Consumer;

/**
 * Assembles barcode strings from the raw HID input reports of a scanner in
 * HID mode (IBM hand-held / HID-POS / SNAPI over hidraw) — the counterpart of
 * {@link KeyboardScancodeDecoder} for the non-keyboard channel.
 * <p>
 * These reports are not keystrokes: each report carries bytes, and the
 * barcode payload sits inside as a run of printable ASCII. The decoder is
 * model-agnostic by design — rather than hard-coding one vendor's frame
 * layout, it extracts the printable ASCII of every report and emits a code
 * when the scan ends, which the common modes signal in one of three ways:
 * a CR or LF terminator in the data, or an empty (no-printable) report after
 * a code, or a report shorter than the reporting length. A runaway buffer
 * (no terminator past {@link #MAX_LENGTH}) resets rather than growing without
 * bound.
 * <p>
 * This covers the single- and multi-report IBM hand-held / HID-POS cases. A
 * scanner whose framing this heuristic does not fit is read by capturing its
 * report descriptor and adding a model decoder — the {@link ScannerSource}
 * seam makes that a local addition, nothing else changes.
 */
public class HidBarcodeDecoder {

    /** The longest code kept before the buffer is declared runaway. */
    static final int MAX_LENGTH = 4096;

    /** The receiver of each completed code. */
    private final Consumer<String> onCode;

    /** The code under assembly, across reports. */
    private final StringBuilder buffer = new StringBuilder();

    /**
     * Creates a decoder delivering completed codes to the given receiver.
     *
     * @param onCode the receiver of each completed, non-empty code
     */
    public HidBarcodeDecoder(Consumer<String> onCode) {
        this.onCode = onCode;
    }

    /**
     * Consumes one HID input report. Appends the report's printable ASCII to
     * the buffer, and emits the assembled code when a terminator (CR/LF) is
     * seen, or when a report carries no printable byte while a code is pending
     * (end-of-scan on the empty trailing report).
     *
     * @param report the report bytes
     * @param length the number of valid bytes in the report
     */
    public void feed(byte[] report, int length) {
        boolean terminator = false;
        int printable = 0;
        for (int i = 0; i < length; i++) {
            int b = report[i] & 0xFF;
            if (b == '\r' || b == '\n') {
                terminator = true;
                break;
            }
            if (b >= 0x20 && b <= 0x7E) {
                printable++;
                if (buffer.length() < MAX_LENGTH) {
                    buffer.append((char) b);
                }
            }
        }
        if (terminator) {
            emit();
            return;
        }
        if (printable == 0 && buffer.length() > 0) {
            emit();
            return;
        }
        if (buffer.length() >= MAX_LENGTH) {
            buffer.setLength(0);
        }
    }

    /**
     * Emits the assembled code (dropping an empty one) and resets the buffer.
     */
    private void emit() {
        String code = buffer.toString();
        buffer.setLength(0);
        if (!code.isEmpty()) {
            onCode.accept(code);
        }
    }
}

package com.intermarche.hw.driver;

import java.io.IOException;

/**
 * What the POS needs from a receipt printer, whatever dialect the hardware speaks.
 *
 * <p>The cash drawer is part of this contract because, on every receipt printer of
 * the park, it is wired to the printer's drawer-kick connector and has no other
 * electrical existence. Implementations: {@link EscPosPrinter} today, a Star line-mode
 * or JavaPOS delegate tomorrow, all behind this one interface.
 */
public interface ReceiptPrinter extends AutoCloseable {

    /**
     * Asks the printer who it is.
     *
     * @return manufacturer and model as reported by the firmware
     * @throws IOException if the device cannot be reached or does not answer
     */
    PrinterIdentity identify() throws IOException;

    /**
     * Reads the real-time status.
     *
     * @return the status flags
     * @throws IOException if the device cannot be reached or does not answer
     */
    PrinterStatus status() throws IOException;

    /**
     * Prints text; lines are separated by {@code \n}.
     *
     * @param text the text to print
     * @throws IOException if the device cannot be written
     */
    void printText(String text) throws IOException;

    /**
     * Feeds blank lines.
     *
     * @param lines number of lines, 1 to 255
     * @throws IOException if the device cannot be written
     */
    void feed(int lines) throws IOException;

    /**
     * Feeds to the cut position and cuts the paper.
     *
     * @throws IOException if the device cannot be written
     */
    void cut() throws IOException;

    /**
     * Sends the drawer-kick pulse on one of the two connector outputs.
     *
     * @param output  0 for connector pin 2, 1 for connector pin 5
     * @param onTime  pulse high time in units of 2 ms, 1 to 255
     * @param offTime pulse low time in units of 2 ms, 1 to 255
     * @throws IOException if the device cannot be written
     */
    void kickDrawer(int output, int onTime, int offTime) throws IOException;

    /**
     * Releases the device node so another process can open it.
     */
    @Override
    void close();

    /**
     * Manufacturer and model strings returned by the printer firmware.
     *
     * @param manufacturer manufacturer string, e.g. {@code EPSON}
     * @param model        model string, e.g. {@code TM-H6000V}
     */
    record PrinterIdentity(String manufacturer, String model) {
    }

    /**
     * Real-time status flags decoded from the printer.
     *
     * @param online        {@code true} when the printer is online
     * @param coverOpen     {@code true} when the cover is open
     * @param paperNearEnd  {@code true} when the roll is near its end
     * @param paperOut      {@code true} when there is no paper
     * @param error         {@code true} when the printer reports an error condition
     * @param drawerPinHigh level of drawer-kick connector pin 3 (open/closed meaning depends on wiring)
     */
    record PrinterStatus(boolean online, boolean coverOpen, boolean paperNearEnd, boolean paperOut,
            boolean error, boolean drawerPinHigh) {
    }
}

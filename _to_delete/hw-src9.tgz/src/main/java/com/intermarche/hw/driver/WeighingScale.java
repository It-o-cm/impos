package com.intermarche.hw.driver;

import java.io.IOException;

/**
 * What the POS needs from a checkout scale.
 *
 * <p>One method, and it takes a unit price: a checkout scale is not a sensor the till
 * reads at will, it is a legal instrument that weighs an ARTICLE. The price is part of
 * the request because the scale computes and displays the amount itself, on its own
 * certified display, and that display is what the customer is entitled to see.
 */
public interface WeighingScale extends AutoCloseable {

    /**
     * Weighs what is on the platter.
     *
     * @param unitPriceCents the article's unit price in cents, shown by the scale
     * @return the reading
     * @throws IOException if the scale cannot be reached or refuses the dialogue
     */
    Reading weigh(long unitPriceCents) throws IOException;

    /**
     * Releases the port.
     */
    @Override
    void close();

    /**
     * One answer of the scale.
     *
     * @param grams     the net weight in grams, or {@code null} when the scale
     *                  answered something that carries no weight
     * @param rawFrames every frame exchanged, for the log and for the day a model
     *                  answers something this driver does not know yet
     */
    record Reading(Integer grams, java.util.List<String> rawFrames) {
    }
}

package com.intermarche.hw.driver;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.Arrays;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * {@link BarcodeScanner} for a scanner in IBM hand-held / table-top USB mode.
 *
 * <p>In that mode the scanner is a HID device on IBM's vendor usage page 0xFF45 and
 * every read is delivered as one input report on {@code /dev/hidrawN}. The report
 * format observed on a Zebra in this mode (2026-09-04, EAN-13 labels):
 * <pre>
 * 12 10 | 03 00 | 03 01 07 08 05 03 00 04 00 03 00 02 02 | 16 | 00 ...
 * id len  sym fl   one digit per byte, binary 0-9                end  padding
 * </pre>
 * {@code len} counts the bytes that follow it up to and including the {@code 16}
 * terminator. Numeric symbologies carry one binary digit per byte; other symbologies
 * are expected to carry ASCII — the decoder accepts both and reports what it could not
 * read rather than guessing.
 *
 * <p>The node is located by a supplier rather than fixed, because the kernel renumbers
 * {@code hidrawN} at every plug: the supplier resolves the device's stable identity to
 * its current node, and is asked again whenever the read fails.
 */
public final class IbmHidScanner implements BarcodeScanner {

    /** Report id of a label report. */
    static final int REPORT_ID_LABEL = 0x12;
    /** Terminator closing the label data. */
    static final int TERMINATOR = 0x16;
    private static final int REPORT_SIZE = 64;
    private static final int HEADER_SIZE = 2;
    private static final int PAYLOAD_HEADER_SIZE = 2;

    private final Supplier<Optional<Path>> nodeLocator;
    private final Duration retryDelay;
    private final Consumer<String> log;

    /**
     * Creates a scanner.
     *
     * @param nodeLocator resolves the current hidraw node of the scanner, empty when absent
     * @param retryDelay  wait between two attempts to find or reopen the node
     * @param log         receives lifecycle messages (node found, lost, undecodable report)
     */
    public IbmHidScanner(Supplier<Optional<Path>> nodeLocator, Duration retryDelay, Consumer<String> log) {
        this.nodeLocator = nodeLocator;
        this.retryDelay = retryDelay;
        this.log = log;
    }

    /** {@inheritDoc} */
    @Override
    public void run(Consumer<ScanEvent> listener) {
        while (!Thread.currentThread().isInterrupted()) {
            Optional<Path> node = nodeLocator.get();
            if (node.isEmpty()) {
                log.accept("scanner not present, waiting");
                sleep();
                continue;
            }
            log.accept("reading " + node.get());
            try (InputStream in = Files.newInputStream(node.get())) {
                readLoop(in, listener);
            } catch (IOException e) {
                log.accept("scanner lost (" + e.getMessage() + "), waiting for it to come back");
            }
            sleep();
        }
    }

    /**
     * Reads reports until the stream fails; each read returns one complete report.
     *
     * @param in       the open node
     * @param listener receives decoded scans
     * @throws IOException when the node fails, typically on unplug
     */
    private void readLoop(InputStream in, Consumer<ScanEvent> listener) throws IOException {
        byte[] buf = new byte[REPORT_SIZE];
        int n;
        while ((n = in.read(buf)) > 0) {
            byte[] report = Arrays.copyOf(buf, n);
            Optional<ScanEvent> event = decode(report);
            if (event.isPresent()) {
                listener.accept(event.get());
            } else {
                log.accept("undecodable report: " + new ScanEvent("", "", report).rawHex());
            }
        }
        throw new IOException("end of stream");
    }

    /**
     * Decodes one label report.
     *
     * @param report the raw report
     * @return the scan, or empty when the report is not a readable label
     */
    static Optional<ScanEvent> decode(byte[] report) {
        if (report.length < HEADER_SIZE + PAYLOAD_HEADER_SIZE + 1 || (report[0] & 0xFF) != REPORT_ID_LABEL) {
            return Optional.empty();
        }
        int len = report[1] & 0xFF;
        int end = Math.min(HEADER_SIZE + len, report.length);
        if ((report[end - 1] & 0xFF) == TERMINATOR) {
            end--;
        }
        int start = HEADER_SIZE + PAYLOAD_HEADER_SIZE;
        if (end <= start) {
            return Optional.empty();
        }
        byte[] data = Arrays.copyOfRange(report, start, end);
        String symbology = symbologyName(report[2] & 0xFF);
        String code = allBinaryDigits(data) ? digitsToText(data) : asciiOrEmpty(data);
        if (code.isEmpty()) {
            return Optional.empty();
        }
        return Optional.of(new ScanEvent(code, symbology, report));
    }

    /**
     * Names a symbology byte. EAN-13 = 0x03 is observed; the others follow the IBM 4690
     * label-type numbering and are to be confirmed on the scanner.
     *
     * @param type the symbology byte
     * @return a name, or {@code IBM-0xNN} when unknown
     */
    private static String symbologyName(int type) {
        return switch (type) {
            case 0x01 -> "UPC-A";
            case 0x02 -> "UPC-E";
            case 0x03 -> "EAN-13";
            case 0x04 -> "EAN-8";
            default -> String.format("IBM-0x%02x", type);
        };
    }

    /**
     * Tells whether every byte is a binary digit 0-9.
     *
     * @param data the label bytes
     * @return {@code true} for a numeric label encoded one digit per byte
     */
    private static boolean allBinaryDigits(byte[] data) {
        for (byte b : data) {
            if (b < 0 || b > 9) {
                return false;
            }
        }
        return true;
    }

    /**
     * Converts binary digits to their text.
     *
     * @param data one digit per byte
     * @return the digit string
     */
    private static String digitsToText(byte[] data) {
        StringBuilder sb = new StringBuilder(data.length);
        for (byte b : data) {
            sb.append((char) ('0' + b));
        }
        return sb.toString();
    }

    /**
     * Accepts the bytes as text when they are all printable ASCII.
     *
     * @param data the label bytes
     * @return the text, or empty when a byte is not printable ASCII
     */
    private static String asciiOrEmpty(byte[] data) {
        for (byte b : data) {
            if (b < 0x20 || b > 0x7E) {
                return "";
            }
        }
        return new String(data, java.nio.charset.StandardCharsets.US_ASCII);
    }

    /**
     * Waits the retry delay, ending the run loop on interruption.
     */
    private void sleep() {
        try {
            Thread.sleep(retryDelay.toMillis());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}

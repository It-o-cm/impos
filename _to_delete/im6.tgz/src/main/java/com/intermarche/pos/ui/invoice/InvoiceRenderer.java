package com.intermarche.pos.ui.invoice;

import com.intermarche.pos.domain.Address;
import com.intermarche.pos.domain.Store;
import com.intermarche.pos.domain.ticket.Invoice;
import com.intermarche.pos.domain.ticket.Ticket;
import com.intermarche.pos.domain.ticket.TicketLine;
import com.intermarche.pos.domain.ticket.VatBreakdown;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Renders a commercial document as lines of text.
 * <p>
 * ONE ENGINE, TWO DESTINATIONS. What comes out of here is a list of fixed-width
 * lines, and both the screen and the printer consume it. The register therefore
 * SHOWS the document before printing it, and what the operator sees is what will
 * come out, column for column — not a second layout that drifts from the first at
 * the third correction. It is also where the abandon of {@code LC-08-04-14} lives:
 * without a screen in between, "as long as printing has not started" is a window
 * nobody can use.
 * <p>
 * The layout is FROZEN here, in code, and that is a deliberate stage and not an
 * oversight. The administered templates of {@code BO-03-03} and {@code BO-03-05}
 * are lot 8 of the back-office plan, which closes its sequence; the receipt itself
 * has its header frozen in the same way and the questionnaire still rates it
 * covered. What matters is that the freeze is in ONE place, and this is it.
 * <p>
 * Pure by construction: everything it needs is passed in, nothing is injected,
 * nothing is read from a database. That is what lets the whole layout be tested
 * without booting anything.
 */
public final class InvoiceRenderer {

    /** French amount format, as on the receipt. */
    private static final DecimalFormat DF =
            new DecimalFormat("0.00", DecimalFormatSymbols.getInstance(Locale.FRENCH));

    /** How dates are printed on a document. */
    private static final DateTimeFormatter DATE =
            DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    /** Standard 80 mm width, in characters — the receipt's own. */
    public static final int WIDTH = 42;

    /** The separator between zones. */
    private static final String RULE = "-".repeat(WIDTH);

    /**
     * How many decimals a tax-excluded amount is printed with.
     * <p>
     * Two, for now. {@code BO-10-02-19} wants this administered — two or three
     * decimals on the unit price, the line total and the VAT lines — and that
     * parameter belongs to lots 3 and 3C of the back-office plan. Named here so the
     * day it becomes a setting there is one place to change.
     */
    private static final int EXCLUDING_TAX_SCALE = 2;

    /**
     * Not instantiable: rendering is a function, not an object.
     */
    private InvoiceRenderer() {
    }

    /**
     * Renders a document.
     *
     * @param invoice   the document to render, carrying its number and its addressee
     * @param ticket    the closed ticket it states
     * @param showEan   whether the article codes are printed ({@code BO-03-03-03})
     * @return the document, one entry per line, without trailing newlines
     */
    public static List<String> render(Invoice invoice, Ticket ticket, boolean showEan) {
        List<String> out = new ArrayList<>();
        seller(out, ticket.store);
        out.add(RULE);
        out.add(center(invoice.documentType.getTitle()));
        if (invoice.isDuplicate()) {
            out.add(center("*** DUPLICATA N°" + invoice.printCount + " ***"));
        }
        out.add(RULE);
        identity(out, invoice);
        out.add(RULE);
        addressee(out, invoice);
        out.add(RULE);
        articles(out, ticket, showEan);
        out.add(RULE);
        vat(out, ticket);
        out.add(RULE);
        totals(out, invoice);
        return out;
    }

    /**
     * Writes the seller's block: who issues the document.
     *
     * @param out   the lines being built
     * @param store the store that sold
     */
    private static void seller(List<String> out, Store store) {
        out.add(center("INTERMARCHE"));
        out.add(center(store.name));
        addressLines(out, store.address, InvoiceRenderer::center);
        if (isFilled(store.siret)) {
            out.add(center("SIRET " + store.siret));
        }
        if (isFilled(store.vatNumber)) {
            out.add(center("TVA " + store.vatNumber));
        }
    }

    /**
     * Writes the document's own identity: its type, its number, its date and the
     * ticket it states.
     *
     * @param out     the lines being built
     * @param invoice the document
     */
    private static void identity(List<String> out, Invoice invoice) {
        out.add(pair("N° " + invoice.documentType.getTitle(), invoice.documentNumber));
        out.add(pair("Date", invoice.issueDate.format(DATE)));
        out.add(pair("Ticket", invoice.ticketNumber));
    }

    /**
     * Writes the addressee's block, as it was at the moment of issue.
     *
     * @param out     the lines being built
     * @param invoice the document
     */
    private static void addressee(List<String> out, Invoice invoice) {
        out.add("CLIENT");
        if (isFilled(invoice.customerAccountNumber)) {
            out.add("  N° compte : " + invoice.customerAccountNumber);
        }
        out.add("  " + invoice.customerName);
        addressLines(out, invoice.customerAddress, text -> "  " + text);
        if (isFilled(invoice.customerSiret)) {
            out.add("  SIRET " + invoice.customerSiret);
        }
        if (isFilled(invoice.customerVatNumber)) {
            out.add("  TVA " + invoice.customerVatNumber);
        }
    }

    /**
     * Writes the article lines, tax EXCLUDED — which is what separates an invoice
     * from a receipt ({@code BO-03-03-03} asks for the unit price and the line total
     * excluding tax, and the rate).
     *
     * <p>The per-line tax-excluded amounts are derived by the same rule the receipt's
     * VAT table uses, rate by rate. Their sum can still differ from the document
     * total by a cent, because each is rounded on its own: THE TOTAL IS NOT THEIR
     * SUM, it comes from the per-rate ventilation, exactly as on the receipt. This is
     * how the two documents are guaranteed to agree, which {@code BO-03-03-04}
     * requires in so many words.
     *
     * @param out     the lines being built
     * @param ticket  the closed ticket
     * @param showEan whether the article codes are printed
     */
    private static void articles(List<String> out, Ticket ticket, boolean showEan) {
        out.add(pair("Article / Qte x PU HT", amountAndRate("Total HT", "TVA")));
        for (TicketLine line : ticket.lines) {
            // A cancelled article is outside the sale: excluded from the document
            // exactly as it is from the totals and from the VAT ventilation.
            if (line.cancelled) {
                continue;
            }
            out.add(truncate(line.productLabel));
            if (showEan && isFilled(line.ean)) {
                out.add("  " + line.ean);
            }
            BigDecimal rate = line.vatRate == null ? BigDecimal.ZERO : line.vatRate;
            out.add(pair("  " + quantity(line) + " x " + DF.format(excludingTax(line.unitPrice, rate)),
                    amountAndRate(DF.format(excludingTax(line.totalPrice, rate)), percent(rate))));
        }
    }

    /**
     * Writes the per-rate VAT table.
     *
     * @param out    the lines being built
     * @param ticket the closed ticket
     */
    private static void vat(List<String> out, Ticket ticket) {
        out.add(pair("TVA", threeAmounts("Base HT", "TVA", "TTC")));
        for (VatBreakdown.Bucket bucket : breakdownOf(ticket).getBuckets()) {
            out.add(pair("  " + bucket.getRateFormatted(),
                    threeAmounts(DF.format(bucket.totalExcludingTax),
                            DF.format(bucket.vatAmount),
                            DF.format(bucket.totalIncludingTax))));
        }
    }

    /**
     * Lays out the right-hand block of an article line: an amount then a rate, in
     * fixed columns so the figures sit under their heading instead of drifting with
     * the length of the article's label.
     *
     * @param amount the tax-excluded line total, or its heading
     * @param rate   the VAT rate, or its heading
     * @return the right-hand block, always the same width
     */
    private static String amountAndRate(String amount, String rate) {
        return String.format("%8s  %6s", amount, rate);
    }

    /**
     * Lays out the right-hand block of a VAT line: three amounts in fixed columns,
     * for the same reason.
     *
     * @param first  the tax-excluded base, or its heading
     * @param second the VAT, or its heading
     * @param third  the tax-included total, or its heading
     * @return the right-hand block, always the same width
     */
    private static String threeAmounts(String first, String second, String third) {
        return String.format("%8s  %8s  %8s", first, second, third);
    }

    /**
     * Writes the totals, as they were frozen on the document.
     *
     * @param out     the lines being built
     * @param invoice the document
     */
    private static void totals(List<String> out, Invoice invoice) {
        out.add(pair("TOTAL HT", DF.format(invoice.totalExcludingTax) + " E"));
        out.add(pair("TOTAL TVA", DF.format(invoice.totalVat) + " E"));
        out.add(pair("TOTAL TTC", DF.format(invoice.totalIncludingTax) + " E"));
    }

    /**
     * Ventilates a ticket's uncancelled lines by VAT rate.
     *
     * @param ticket the closed ticket
     * @return the ventilation
     */
    public static VatBreakdown breakdownOf(Ticket ticket) {
        VatBreakdown breakdown = new VatBreakdown();
        for (TicketLine line : ticket.lines) {
            if (line.cancelled) {
                continue;
            }
            breakdown.add(line.vatRate, line.totalPrice);
        }
        return breakdown;
    }

    /**
     * Removes the tax from a tax-included amount.
     *
     * @param includingTax the tax-included amount, null treated as zero
     * @param rate         the VAT rate as a fraction, e.g. 0.20
     * @return the tax-excluded amount
     */
    private static BigDecimal excludingTax(BigDecimal includingTax, BigDecimal rate) {
        BigDecimal amount = includingTax == null ? BigDecimal.ZERO : includingTax;
        return amount.divide(BigDecimal.ONE.add(rate), EXCLUDING_TAX_SCALE, RoundingMode.HALF_UP);
    }

    /**
     * Formats a VAT rate as a percentage.
     *
     * @param rate the rate as a fraction
     * @return the rate as a percentage, French decimal
     */
    private static String percent(BigDecimal rate) {
        return String.format("%.1f%%", rate.multiply(BigDecimal.valueOf(100))).replace(".", ",");
    }

    /**
     * Formats a line's quantity: three decimals for a weighed article, a plain
     * count otherwise.
     *
     * @param line the ticket line
     * @return the formatted quantity
     */
    private static String quantity(TicketLine line) {
        BigDecimal value = line.quantity == null ? BigDecimal.ZERO : line.quantity;
        if (isFilled(line.plu)) {
            return String.format("%.3f", value).replace(".", ",");
        }
        if (value.stripTrailingZeros().scale() <= 0) {
            return value.stripTrailingZeros().toPlainString();
        }
        return String.format("%.2f", value).replace(".", ",");
    }

    /**
     * Writes the non-blank parts of an address, each through the given layout.
     *
     * @param out     the lines being built
     * @param address the address, possibly null
     * @param layout  how each part is placed on its line
     */
    private static void addressLines(List<String> out, Address address,
            java.util.function.UnaryOperator<String> layout) {
        if (address == null) {
            return;
        }
        if (isFilled(address.streetLine1)) {
            out.add(layout.apply(address.streetLine1));
        }
        if (isFilled(address.streetLine2)) {
            out.add(layout.apply(address.streetLine2));
        }
        String town = join(address.postalCode, address.city);
        if (!town.isEmpty()) {
            out.add(layout.apply(town));
        }
    }

    /**
     * Joins a postal code and a town, ignoring the blank ones.
     *
     * @param postalCode the postal code, possibly blank
     * @param city       the town, possibly blank
     * @return the joined line, empty when both are blank
     */
    private static String join(String postalCode, String city) {
        String code = isFilled(postalCode) ? postalCode.trim() : "";
        String town = isFilled(city) ? city.trim() : "";
        if (code.isEmpty()) {
            return town;
        }
        if (town.isEmpty()) {
            return code;
        }
        return code + " " + town;
    }

    /**
     * Centres a text on the document's width.
     *
     * @param text the text to centre
     * @return the padded line, the text itself when it fills the width
     */
    private static String center(String text) {
        String value = truncate(text);
        if (value.length() >= WIDTH) {
            return value;
        }
        return " ".repeat((WIDTH - value.length()) / 2) + value;
    }

    /**
     * Places a label on the left and a value on the right of one line.
     *
     * @param left  the label
     * @param right the value
     * @return the formatted line
     */
    private static String pair(String left, String right) {
        String label = left == null ? "" : left;
        String value = right == null ? "" : right;
        int space = WIDTH - label.length() - value.length();
        return label + " ".repeat(Math.max(space, 1)) + value;
    }

    /**
     * Cuts a text to the document's width.
     *
     * @param text the text, possibly null
     * @return the text, never longer than the width and never null
     */
    private static String truncate(String text) {
        if (text == null) {
            return "";
        }
        return text.length() <= WIDTH ? text : text.substring(0, WIDTH);
    }

    /**
     * Tells whether a text carries something.
     *
     * @param text the text to check
     * @return true when it is neither null nor blank
     */
    private static boolean isFilled(String text) {
        return text != null && !text.isBlank();
    }
}

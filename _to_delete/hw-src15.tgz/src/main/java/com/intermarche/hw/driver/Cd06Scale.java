package com.intermarche.hw.driver;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * A checkout scale speaking Checkout-Dialog-06 over RS232.
 *
 * <p>The dialogue was read off the vendor's own JavaPOS service and proven on the till
 * on 2026-09-07. A request is {@code EOT STX} + a two-digit record number + fields
 * separated by {@code ESC} + {@code ETX}; an answer is {@code STX} + record + fields +
 * {@code ETX}, or a bare {@code ACK} / {@code NAK}. Record 01 asks for a weighing with
 * a unit price, record 08 asks for the status.
 *
 * <p>The part that cannot be guessed is the CONFORMITY CHALLENGE. A weighing request is
 * not answered with a weight but with record 11, carrying two hexadecimal counters. The
 * scale expects record 10 in return, holding two 16-bit constants — {@code 0x3C8B}
 * rotated LEFT by the first counter, {@code 0x79F7} rotated RIGHT by the second — as
 * four upper-case hex digits each. A scale is a legal instrument: it weighs only for
 * software that proves it knows the protocol, and the challenge changes at every
 * request. {@link #answerChallenge(int, int)} is that computation.
 *
 * <p>No serial library is used, this project having no dependency: the line is set up
 * by the system's own {@code stty} and the port is then read and written as a file,
 * which is all a raw 7O1 link needs on Linux.
 */
public final class Cd06Scale implements WeighingScale {

    /** Start of a request. */
    private static final byte EOT = 0x04;

    /** Start of a record. */
    private static final byte STX = 0x02;

    /** Field separator. */
    private static final byte ESC = 0x1B;

    /** End of a record. */
    private static final byte ETX = 0x03;

    /** The scale accepted the record. */
    private static final byte ACK = 0x06;

    /** The scale rejected the record. */
    private static final byte NAK = 0x15;

    /**
     * Asks for the weighing data.
     *
     * <p>{@code EOT ENQ} is a bare two-byte request, outside the record framing, and it
     * is the missing half of a weighing: record 01 only SENDS THE UNIT PRICE and is
     * acknowledged, then this asks the scale for what it measured. The vendor service
     * calls it "Gewichtsdaten anfordern", and the answer is record 02.
     */
    private static final byte[] ASK_WEIGHT_DATA = {EOT, 0x05};

    /** Record asking for a weighing, carrying the unit price. */
    private static final String RECORD_WEIGH = "01";

    /** Record answering the conformity challenge. */
    private static final String RECORD_CHALLENGE_ANSWER = "10";

    /** Record the scale challenges with. */
    private static final String RECORD_CHALLENGE = "11";

    /** Record asking for the scale status. */
    private static final String RECORD_STATUS = "08";

    /** Constant rotated LEFT to answer a challenge. */
    private static final int LEFT_SEED = 15499;

    /** Constant rotated RIGHT to answer a challenge. */
    private static final int RIGHT_SEED = 31223;

    /** Width of the values the two seeds are rotated in. */
    private static final int WORD = 0xFFFF;

    /** Most significant bit of that width. */
    private static final int WORD_MSB = 0x8000;

    /** Digits of the unit price field of a weighing request. */
    private static final int PRICE_DIGITS = 6;

    /**
     * Fields of the weighing record, as the scale sends them: the record number, an
     * indicator, the net weight in grams, the unit price echoed back, and the amount
     * the scale computed and displayed. Proven on the till on 2026-09-07 with
     * {@code 02 ESC 3 ESC 00232 ESC 000001 ESC 000000}.
     */
    private static final int FIELD_STATUS = 1;

    /** Position of the net weight, in grams. */
    private static final int FIELD_WEIGHT = 2;

    /** Position of the amount the scale computed. */
    private static final int FIELD_CALCULATED_PRICE = 4;

    /**
     * Line settings of the Checkout-Dialog-06 link: 9600 bauds, 7 bits, odd parity,
     * one stop bit.
     *
     * <p>{@code min 0 time 1} comes last and is not decoration: {@code raw} sets the
     * line to {@code min 1 time 0}, where a read BLOCKS until a byte arrives and no
     * timeout of ours can ever apply. With {@code min 0} a read returns what is there,
     * which is what makes the reading loop able to give up.
     */
    private static final List<String> LINE_SETTINGS = List.of("9600", "cs7", "parenb",
            "parodd", "-cstopb", "raw", "-echo", "-ixon", "min", "0", "time", "1");

    /** Longest frame this driver expects to read. */
    private static final int MAX_FRAME = 64;

    /**
     * How many answers one weighing may take before the driver gives up.
     *
     * <p>A weighing is not one question and one answer: the scale acknowledges the
     * request, may interpose a conformity challenge, and only then sends the weight.
     * The bound exists so a scale that keeps challenging cannot loop for ever.
     */
    private static final int MAX_STEPS = 6;

    /** Pause between two read attempts while a frame is still coming. */
    private static final Duration POLL = Duration.ofMillis(20);

    /** The serial port the scale is on. */
    private final Path port;

    /** Maximum wait for one answer. */
    private final Duration timeout;

    /** Where the driver narrates the dialogue. */
    private final Consumer<String> log;

    /** The open port, or {@code null} before the first exchange. */
    private FileChannel channel;

    /**
     * Bytes read from the port but not yet consumed.
     *
     * <p>One read can bring back more than one frame — an acknowledgement and the record
     * that follows it, typically. Without this queue the surplus was dropped and the
     * next frame started in the middle of a record, which is how a challenge came back
     * four characters long.
     */
    private final java.util.ArrayDeque<Byte> pending = new java.util.ArrayDeque<>();

    /**
     * Builds a scale on a serial port.
     *
     * @param port    the serial port, e.g. {@code /dev/ttyS4}
     * @param timeout maximum wait for one answer
     * @param log     destination of the dialogue log lines
     */
    public Cd06Scale(Path port, Duration timeout, Consumer<String> log) {
        this.port = port;
        this.timeout = timeout;
        this.log = log;
    }

    /**
     * Answers the conformity challenge.
     *
     * <p>Package-private rather than private so the computation can be exercised on its
     * own: it is the one part of this driver that cannot be checked by looking at it.
     *
     * @param leftRotations  how far to rotate the left seed, the first counter
     * @param rightRotations how far to rotate the right seed, the second counter
     * @return the two four-digit hexadecimal values, concatenated
     */
    static String answerChallenge(int leftRotations, int rightRotations) {
        return hex4(rotateLeft(LEFT_SEED, leftRotations)) + hex4(rotateRight(RIGHT_SEED, rightRotations));
    }

    /**
     * Rotates a 16-bit value left.
     *
     * @param value the value
     * @param times how many bits
     * @return the rotated value
     */
    private static int rotateLeft(int value, int times) {
        int v = value & WORD;
        for (int i = 0; i < times; i++) {
            boolean carry = (v & WORD_MSB) != 0;
            v = (v << 1) & WORD;
            if (carry) {
                v |= 1;
            }
        }
        return v;
    }

    /**
     * Rotates a 16-bit value right.
     *
     * @param value the value
     * @param times how many bits
     * @return the rotated value
     */
    private static int rotateRight(int value, int times) {
        int v = value & WORD;
        for (int i = 0; i < times; i++) {
            boolean carry = (v & 1) != 0;
            v = (v >> 1) & WORD;
            if (carry) {
                v |= WORD_MSB;
            }
        }
        return v;
    }

    /**
     * Formats a value as four upper-case hexadecimal digits.
     *
     * @param value the value
     * @return the four digits
     */
    private static String hex4(int value) {
        String hex = Integer.toHexString(value & WORD).toUpperCase(java.util.Locale.ROOT);
        return ("0000" + hex).substring(hex.length());
    }

    /**
     * {@inheritDoc}
     *
     * <p>The dialogue is a small state machine rather than a single round trip: the
     * scale answers the request with an acknowledgement, sometimes interposes its
     * conformity challenge, and sends the weight in a LATER frame. Each step is driven
     * by what came back, until a record carrying a weight arrives.
     */
    @Override
    public Cd06Scale.Reading weigh(long unitPriceCents) throws IOException {
        List<String> frames = new ArrayList<>();
        String answer = request(RECORD_WEIGH + (char) ESC + priceField(unitPriceCents) + (char) ESC, frames);
        for (int step = 0; step < MAX_STEPS; step++) {
            if (isControl(answer, ACK)) {
                answer = requestBytes(ASK_WEIGHT_DATA, frames);
                continue;
            }
            if (isControl(answer, NAK)) {
                throw new WeighingScale.ExchangeFailed(
                        "the scale rejected the request, status " + statusAfterRefusal(frames), frames);
            }
            if (recordOf(answer).equals(RECORD_CHALLENGE)) {
                String reply = challengeAnswer(answer, frames);
                log.accept("scale        challenge " + printable(answer) + " -> " + reply);

                answer = request(RECORD_CHALLENGE_ANSWER + (char) ESC + reply, frames);
                continue;
            }
            String[] fields = fieldsOf(answer);
            return new Reading(intField(fields, FIELD_WEIGHT), field(fields, FIELD_STATUS),
                    field(fields, FIELD_CALCULATED_PRICE), frames);
        }
        throw new WeighingScale.ExchangeFailed(
                "the scale never sent a weight after " + MAX_STEPS + " answers", frames);
    }

    /**
     * Reads a challenge record and computes its answer, turning a malformed one into a
     * failure that carries the frames rather than an index error.
     *
     * @param challenge the challenge record, framing stripped
     * @param frames    the exchange log, reported with a failure
     * @return the two four-digit hexadecimal values, concatenated
     * @throws IOException if the record is not a usable challenge
     */
    private static String challengeAnswer(String challenge, List<String> frames) throws IOException {
        try {
            return answerChallenge(counter(challenge, 5), counter(challenge, 6));
        } catch (IllegalArgumentException e) {
            throw new WeighingScale.ExchangeFailed(
                    "unusable conformity challenge: " + e.getMessage(), frames);
        }
    }

    /**
     * Tells whether an answer is one given control byte.
     *
     * @param answer  the answer as read
     * @param control the control byte to test
     * @return true when the answer is exactly that byte
     */
    private static boolean isControl(String answer, byte control) {
        return answer.length() == 1 && answer.charAt(0) == (char) control;
    }

    /**
     * Asks the scale why it refused, so a refusal names its cause instead of being a
     * bare NAK.
     *
     * <p>A refusal is rarely a fault: the commonest is an article that has not moved
     * since the previous weighing, which the scale refuses on purpose — a legal
     * instrument does not weigh the same item twice without seeing it leave the platter.
     *
     * @param frames the exchange log, appended to
     * @return the status record, or a note when even that could not be read
     */
    private String statusAfterRefusal(List<String> frames) {
        try {
            return printable(request(RECORD_STATUS, frames));
        } catch (IOException e) {
            return "(unreadable: " + e.getMessage() + ")";
        }
    }

    /**
     * Asks the scale for its status, the one request that carries no field.
     *
     * @return the raw answer, printable
     * @throws IOException if the scale does not answer
     */
    public String status() throws IOException {
        List<String> frames = new ArrayList<>();
        return printable(request(RECORD_STATUS, frames));
    }

    /** {@inheritDoc} */
    @Override
    public void close() {
        FileChannel c = channel;
        channel = null;
        if (c != null) {
            try {
                c.close();
            } catch (IOException ignored) {
                // Nothing useful can be done with a failed close on a character device.
            }
        }
    }

    /**
     * Sends one record and reads what comes back.
     *
     * @param body   the record number and its fields, without the framing bytes
     * @param frames the exchange log this call appends to
     * @return the answer, framing bytes stripped for a record, or the single control byte
     * @throws IOException if the port cannot be used or nothing comes back in time
     */
    private String request(String body, List<String> frames) throws IOException {
        byte[] out = frame(body);
        frames.add("> " + printable(new String(out, StandardCharsets.US_ASCII)));
        channel().write(ByteBuffer.wrap(out));
        return readFrame(frames);
    }

    /**
     * Writes bytes as they are and reads what comes back, for the requests that live
     * outside the record framing.
     *
     * @param out    the bytes to write
     * @param frames the exchange log this call appends to
     * @return the answer
     * @throws IOException if the port cannot be used or nothing comes back in time
     */
    private String requestBytes(byte[] out, List<String> frames) throws IOException {
        frames.add("> " + printable(new String(out, StandardCharsets.US_ASCII)));
        channel().write(ByteBuffer.wrap(out));
        return readFrame(frames);
    }

    /**
     * Wraps a record body in its framing bytes.
     *
     * @param body the record number and its fields
     * @return the bytes to write
     */
    private static byte[] frame(String body) {
        byte[] payload = body.getBytes(StandardCharsets.US_ASCII);
        byte[] out = new byte[payload.length + 3];
        out[0] = EOT;
        out[1] = STX;
        System.arraycopy(payload, 0, out, 2, payload.length);
        out[out.length - 1] = ETX;
        return out;
    }

    /**
     * Reads one answer: a record up to its {@code ETX}, or a single control byte.
     *
     * @param frames the exchange log this call appends to
     * @return the answer as read, framing bytes included except the leading STX
     * @throws IOException if nothing comes back within the timeout
     */
    private String readFrame(List<String> frames) throws IOException {
        Instant deadline = Instant.now().plus(timeout);
        StringBuilder answer = new StringBuilder();
        while (true) {
            Byte next = nextByte(deadline);
            if (next == null) {
                throw new WeighingScale.ExchangeFailed(
                        "no answer from the scale on " + port + " within " + timeout, frames);
            }
            byte b = next;
            if (b == ACK || b == NAK) {
                frames.add("< " + (b == ACK ? "ACK" : "NAK"));
                return String.valueOf((char) b);
            }
            if (b == STX) {
                answer.setLength(0);
                continue;
            }
            if (b == ETX) {
                frames.add("< " + printable(answer.toString()));
                return answer.toString();
            }
            answer.append((char) b);
        }
    }

    /**
     * The next byte of the stream, refilling from the port when the queue runs dry.
     *
     * @param deadline when to give up
     * @return the byte, or {@code null} when the deadline passed with nothing to read
     * @throws IOException if the port cannot be read
     */
    private Byte nextByte(Instant deadline) throws IOException {
        while (pending.isEmpty()) {
            if (!Instant.now().isBefore(deadline)) {
                return null;
            }
            ByteBuffer buffer = ByteBuffer.allocate(MAX_FRAME);
            int read = channel().read(buffer);
            for (int i = 0; i < read; i++) {
                pending.addLast(buffer.get(i));
            }
            if (read <= 0) {
                sleep();
            }
        }
        return pending.pollFirst();
    }

    /**
     * The record number an answer carries.
     *
     * @param answer the answer, framing stripped
     * @return the two-digit record number, empty when the answer is a control byte
     */
    private static String recordOf(String answer) {
        return answer.length() >= 2 ? answer.substring(0, 2) : "";
    }

    /**
     * One hexadecimal counter of a challenge, by its position in the answer.
     *
     * <p>The positions are those of the vendor service, counted on the frame INCLUDING
     * its leading STX, which is why one is subtracted here.
     *
     * @param answer the challenge record, framing stripped
     * @param index  the position in the framed record
     * @return the counter
     */
    private static int counter(String answer, int index) {
        if (answer.length() < index) {
            throw new IllegalArgumentException("challenge too short: " + printable(answer));
        }
        return Integer.parseInt(String.valueOf(answer.charAt(index - 1)), 16);
    }

    /**
     * Splits an answer into its fields.
     *
     * @param answer the answer, framing stripped
     * @return the fields, the record number first
     */
    private static String[] fieldsOf(String answer) {
        return answer.split(String.valueOf((char) ESC));
    }

    /**
     * One field of an answer, by position.
     *
     * @param fields the fields
     * @param index  the position
     * @return the field, trimmed, or an empty string when the record is shorter
     */
    private static String field(String[] fields, int index) {
        return index < fields.length ? fields[index].trim() : "";
    }

    /**
     * One numeric field of an answer, by position.
     *
     * @param fields the fields
     * @param index  the position
     * @return the value, or {@code null} when the field is absent or not a number
     */
    private static Integer intField(String[] fields, int index) {
        String raw = field(fields, index);
        if (raw.isEmpty()) {
            return null;
        }
        try {
            return Integer.valueOf(raw);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /**
     * The unit price field: the price in the scale's own unit, on six digits.
     *
     * @param unitPriceCents the unit price in cents
     * @return the six-digit field
     */
    private static String priceField(long unitPriceCents) {
        String digits = String.valueOf(Math.max(0, unitPriceCents / 100));
        return ("000000" + digits).substring(digits.length(), digits.length() + PRICE_DIGITS);
    }

    /**
     * Renders a frame with its control bytes named, for the log.
     *
     * @param raw the frame as read or written
     * @return the printable form
     */
    private static String printable(String raw) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < raw.length(); i++) {
            char c = raw.charAt(i);
            sb.append(switch (c) {
                case (char) EOT -> "<EOT>";
                case (char) STX -> "<STX>";
                case (char) ESC -> "<ESC>";
                case (char) ETX -> "<ETX>";
                case (char) ACK -> "<ACK>";
                case (char) NAK -> "<NAK>";
                case (char) 0x05 -> "<ENQ>";
                default -> String.valueOf(c);
            });
        }
        return sb.toString();
    }

    /**
     * Opens the port, setting the line up first.
     *
     * @return the open channel
     * @throws IOException if the port cannot be configured or opened
     */
    private FileChannel channel() throws IOException {
        if (channel == null) {
            configureLine();
            channel = FileChannel.open(port, StandardOpenOption.READ, StandardOpenOption.WRITE);
        }
        return channel;
    }

    /**
     * Sets the line up with the system's own tool, this project carrying no serial
     * library.
     *
     * @throws IOException if the settings could not be applied
     */
    private void configureLine() throws IOException {
        List<String> command = new ArrayList<>(List.of("stty", "-F", port.toString()));
        command.addAll(LINE_SETTINGS);
        try {
            Process stty = new ProcessBuilder(command).redirectErrorStream(true)
                    .redirectOutput(ProcessBuilder.Redirect.DISCARD).start();
            if (!stty.waitFor(timeout.toMillis(), java.util.concurrent.TimeUnit.MILLISECONDS)) {
                stty.destroy();
                throw new IOException("stty did not finish on " + port);
            }
            if (stty.exitValue() != 0) {
                throw new IOException("stty refused the line settings on " + port);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException("interrupted while setting up " + port);
        }
    }

    /**
     * Waits between two read attempts.
     */
    private static void sleep() {
        try {
            Thread.sleep(POLL.toMillis());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}

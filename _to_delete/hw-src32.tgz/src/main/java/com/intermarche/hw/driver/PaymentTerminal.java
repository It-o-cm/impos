package com.intermarche.hw.driver;

import java.io.IOException;

/**
 * What the POS needs from a payment terminal, whichever client actually owns the reader.
 *
 * <p>The till never drives the card reader itself: a certified client process owns it
 * and the bank dialogue, and everything goes through that process. So this interface is
 * deliberately small and says nothing about tags, services or shared memory -- those
 * belong to the binding, not to the POS.
 *
 * <p>A session is stateful in a way the other peripherals are not. The client must be
 * logged in before it takes the reader, the login is slow -- it can update the reader's
 * firmware and takes minutes when it does -- and it is done once, at start-up. A
 * payment is then a short exchange inside that session. Closing ends the session and
 * stops the client.
 */
public interface PaymentTerminal {

    /** Result code of an accepted operation. */
    String RESULT_OK = "01";

    /**
     * The outcome of one exchange with the payment client.
     *
     * @param code   the result code, empty when nothing came back
     * @param answer the whole answer, kept as it arrived so a refusal can be diagnosed
     */
    record Result(String code, String answer) {

        /**
         * Whether the operation was accepted.
         *
         * @return true when the result code is the accepted one
         */
        public boolean approved() {
            return RESULT_OK.equals(code);
        }
    }

    /**
     * Opens the payment session.
     *
     * @return the outcome
     * @throws IOException if the client could not be reached
     */
    Result login() throws IOException;

    /**
     * Asks for a card payment of the given amount.
     *
     * @param amountCents the amount in cents
     * @return the outcome
     * @throws IOException if the client could not be reached
     */
    Result debit(long amountCents) throws IOException;

    /**
     * Ends the session and releases whatever the binding holds.
     */
    void close();
}

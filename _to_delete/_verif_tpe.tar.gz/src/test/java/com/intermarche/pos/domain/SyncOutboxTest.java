package com.intermarche.pos.domain;

import com.intermarche.pos.domain.SyncOutbox.EntityType;
import java.time.LocalDateTime;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

/**
 * Unit tests for {@link SyncOutbox}, targeting 100% branch coverage.
 * <p>
 * {@code SyncOutbox} is a pure Panache data entity: it declares five public
 * columns and no behaviour, hence carries no branches. Its nested
 * {@link SyncOutbox.EntityType} enum is likewise plain, exposing only the
 * compiler-synthesized {@code values()} and {@code valueOf(String)} members.
 * The tests exercise the default constructor, confirm each field is an
 * independently writable plain reference, and pin the enum constants whose
 * ordinal drives the drain order. Each test is fully isolated and asserts
 * absolute expected values.
 */
class SyncOutboxTest {

    /**
     * A fresh SyncOutbox carries null reference defaults and a zeroed attempts
     * counter, no field being pre-set.
     */
    @Test
    void fieldDefaultsAreUnset() {
        SyncOutbox outbox = new SyncOutbox();
        Assertions.assertNull(outbox.entityType);
        Assertions.assertNull(outbox.entityId);
        Assertions.assertNull(outbox.createdAt);
        Assertions.assertEquals(0, outbox.attempts);
        Assertions.assertNull(outbox.lastError);
    }

    /**
     * The five columns are independently writable and read back verbatim.
     */
    @Test
    void fieldsAreWritableAndReadBack() {
        LocalDateTime createdAt = LocalDateTime.of(2026, 8, 3, 10, 15, 30);
        SyncOutbox outbox = new SyncOutbox();
        outbox.entityType = EntityType.TICKET;
        outbox.entityId = 42L;
        outbox.createdAt = createdAt;
        outbox.attempts = 3;
        outbox.lastError = "connection refused";
        Assertions.assertEquals(EntityType.TICKET, outbox.entityType);
        Assertions.assertEquals(42L, outbox.entityId);
        Assertions.assertEquals(createdAt, outbox.createdAt);
        Assertions.assertEquals(3, outbox.attempts);
        Assertions.assertEquals("connection refused", outbox.lastError);
    }

    /**
     * The nullable lastError column accepts an explicit null after being set.
     */
    @Test
    void lastErrorAcceptsNull() {
        SyncOutbox outbox = new SyncOutbox();
        outbox.lastError = "boom";
        outbox.lastError = null;
        Assertions.assertNull(outbox.lastError);
    }

    /**
     * values exposes exactly the four declared constants in declaration order,
     * the ordinal being the documented drain order.
     */
    @Test
    void entityTypeValuesHoldsFourConstantsInOrder() {
        EntityType[] values = EntityType.values();
        Assertions.assertEquals(4, values.length);
        Assertions.assertEquals(EntityType.SESSION, values[0]);
        Assertions.assertEquals(EntityType.TICKET, values[1]);
        Assertions.assertEquals(EntityType.REFUND, values[2]);
        Assertions.assertEquals(EntityType.EVENT, values[3]);
    }

    /**
     * Each constant reports its declared ordinal, pinning the drain order.
     */
    @Test
    void entityTypeOrdinalsAreStable() {
        Assertions.assertEquals(0, EntityType.SESSION.ordinal());
        Assertions.assertEquals(1, EntityType.TICKET.ordinal());
        Assertions.assertEquals(2, EntityType.REFUND.ordinal());
        Assertions.assertEquals(3, EntityType.EVENT.ordinal());
    }

    /**
     * Each constant reports its declared name.
     */
    @Test
    void entityTypeNamesMatchConstants() {
        Assertions.assertEquals("SESSION", EntityType.SESSION.name());
        Assertions.assertEquals("TICKET", EntityType.TICKET.name());
        Assertions.assertEquals("REFUND", EntityType.REFUND.name());
        Assertions.assertEquals("EVENT", EntityType.EVENT.name());
    }

    /**
     * valueOf round-trips each declared name back to its constant.
     */
    @Test
    void entityTypeValueOfResolvesEachConstant() {
        Assertions.assertSame(EntityType.SESSION, EntityType.valueOf("SESSION"));
        Assertions.assertSame(EntityType.TICKET, EntityType.valueOf("TICKET"));
        Assertions.assertSame(EntityType.REFUND, EntityType.valueOf("REFUND"));
        Assertions.assertSame(EntityType.EVENT, EntityType.valueOf("EVENT"));
    }

    /**
     * valueOf rejects an unknown name with IllegalArgumentException.
     */
    @Test
    void entityTypeValueOfRejectsUnknownName() {
        Assertions.assertThrows(IllegalArgumentException.class,
                () -> EntityType.valueOf("PRODUCT"));
    }

    /**
     * valueOf rejects a null name with NullPointerException.
     */
    @Test
    void entityTypeValueOfRejectsNullName() {
        Assertions.assertThrows(NullPointerException.class,
                () -> EntityType.valueOf(null));
    }
}

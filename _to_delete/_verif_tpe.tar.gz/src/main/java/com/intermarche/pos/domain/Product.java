package com.intermarche.pos.domain;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Objects;

/**
 * Entity representing a Product in a supermarket POS system.
 * <p>
 * This class focuses strictly on the product's identity and intrinsic attributes.
 * It does NOT contain references to categories, as categorization depends on the Store.
 * <p>
 * Semantic contract:
 * <ul>
 *   <li>{@code active} and {@code forbiddenToSale} are different axes:
 *       inactive means "gone from the referential" (hidden from search,
 *       deactivated — never deleted — by the referential pull, because
 *       ticket lines hold product foreign keys); forbidden means "present
 *       but blocked", refused at scan time with a cashier error.</li>
 *   <li>{@code ean} is the portable identity everywhere: catalog upserts,
 *       sync payloads, search-to-cart addition. {@code plu} (unique,
 *       nullable) is the weighed-sale identity: 2x scale labels and the
 *       fruits screen resolve through it, and a typed PLU behaves like a
 *       quantity-1 sale.</li>
 * </ul>
 * <p>
 * This class extends {@link BaseEntity} to inherit ID, versioning,
 * and audit fields.
 * <p>
 * Fields are public to comply with Quarkus/Panache conventions.
 */
@Entity
@Table(name = "products",
        indexes = @Index(name = "idx_product_name", columnList = "name")
)
@Cacheable
public class Product extends BaseEntity {

    // --------------------------------------------------
    // Identification
    // --------------------------------------------------

    /**
     * The EAN (European Article Number) code, commonly known as barcode.
     * This is the primary identifier used for lookups at the register.
     * Unique constraint implies a database index.
     */
    @Column(name = "ean", unique = true, nullable = false, length = 13)
    @NotBlank(message = "EAN is mandatory")
    public String ean;

    @Column(name = "plu", unique = true, nullable = true, length = 4)
    public String plu;

    // --------------------------------------------------
    // Product Details
    // --------------------------------------------------

    @Column(nullable = false)
    @NotBlank(message = "Product name is mandatory")
    public String name;

    @Column(length = 255)
    public String description;

    @Column(length = 10)
    public String icon;

    /**
     * The brand of the product.
     * Optional field to specify the manufacturer or brand name.
     */
    @Column(name = "brand", length = 100)
    public String brand;

    // --------------------------------------------------
    // Dimensions & Weight
    // --------------------------------------------------

    /**
     * Reference weight for the product.
     * <p>
     * This optional field can be used for inventory (pallet weight),
     * or as a default weight for products sold by unit (e.g., average weight of a melon).
     * Stored in Kilograms (kg) with 3 decimal places (gram precision).
     * Null if not applicable.
     */
    @Column(name = "reference_weight", precision = 10, scale = 3)
    public BigDecimal referenceWeight;

    /**
     * Reference volume for the product.
     * <p>
     * This optional field can be used for inventory (bottle size, tank capacity),
     * or as a default volume for products sold by unit (e.g., standard drink size).
     * Stored in Liters (L) with 3 decimal places (milliliter precision).
     * Null if not applicable.
     */
    @Column(name = "reference_volume", precision = 10, scale = 3)
    public BigDecimal referenceVolume;

    /**
     * Defines how the product is sold (Unit vs Weight).
     * Intrinsic to the product definition.
     */
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    @NotNull(message = "Product type is mandatory")
    public ProductType productType;

    /**
     * Display unit for the product (e.g., "kg", "pcs", "L").
     */
    @Column(name = "unit_name", length = 20)
    public String unitName;

    // --------------------------------------------------
    // Status
    // --------------------------------------------------

    /**
     * Flag to indicate if the product definition is globally active.
     * Note: A product can be active globally but not present in a specific store's categories.
     */
    @Column(name = "is_active", nullable = false)
    public boolean active = true;

    /**
     * Flag to indicate that the product is forbidden to sell at the register.
     * <p>
     * When true, scanning or keying this product must be refused: no ticket line is
     * created and an error is shown to the cashier.
     */
    @Column(name = "forbidden_to_sale", nullable = false)
    public boolean forbiddenToSale = false;

    /**
     * Minimum customer age required to sell this product (e.g. 18 for
     * alcohol), or null when the product is unrestricted. A restricted scan
     * suspends the sale until the cashier confirms the ID check or refuses
     * the sale — both journalized (phase: age control).
     */
    @jakarta.persistence.Column(name = "age_restriction")
    public Integer ageRestriction;

    /**
     * When set, this product IS a gift card of that denomination: selling it
     * issues, at the fiscal moment of the sale, an ACTIVE registry
     * instrument of this amount (phase: credit notes & gift cards). Gift
     * cards sell at VAT 0 — multi-purpose vouchers are out of VAT scope at
     * issuance under French rules.
     */
    @jakarta.persistence.Column(name = "gift_card_amount", precision = 10, scale = 2)
    public java.math.BigDecimal giftCardAmount;

    // --------------------------------------------------
    // Panache Active Record Queries
    // --------------------------------------------------

    /**
     * Converts a given quantity into standard units based on the product type.
     * <p>
     * For UNIT products, the quantity is returned as-is.
     * For WEIGHT or VOLUME products, the quantity (in kg or L) is divided by the reference weight or volume.
     *
     * @param quantity The quantity to convert (can be integer or decimal).
     * @return The quantity expressed in standard units.
     */
    public BigDecimal standardQuantity(double quantity) {
        if (this.productType == ProductType.UNIT) {
            return BigDecimal.valueOf(quantity);
        }
        else {
            if (this.referenceWeight == null || this.referenceWeight.compareTo(BigDecimal.ZERO) == 0) {
                return BigDecimal.ZERO;
            }
            BigDecimal quantityKg = BigDecimal.valueOf(quantity);
            return quantityKg.divide(this.referenceWeight, 6, RoundingMode.HALF_UP);
        }
    }

    /**
     * Finds a product by its unique EAN code.
     * This is the most frequently used method at checkout.
     *
     * @param ean The scanned EAN code
     * @return The Product or null
     */
    public static Product findByEan(String ean) {
        return find("ean", ean).firstResult();
    }

    /**
     * Finds a product by its unique PLU (Price Look-Up) code.
     *
     * @param plu The PLU code used to identify the product.
     * @return The Product with the specified PLU code, or null if no such product exists.
     */
    public static Product findByPlu(String plu) {
        return find("plu", plu).firstResult();
    }

    /**
     * Finds a product by EAN code, ensuring it is globally active.
     *
     * @param ean The scanned EAN code
     * @return The active Product or null
     */
    public static Product findActiveByEan(String ean) {
        return find("ean = ?1 and active = true", ean).firstResult();
    }

    /**
     * Finds an active Product by its PLU (Price Look-Up) code.
     *
     * @param plu The PLU (Price Look-Up) code used to identify the product.
     * @return The active Product with the given PLU code, or null if none exists.
     */
    public static Product findActiveByPlu(String plu) {
        return find("plu = ?1 and active = true", plu).firstResult();
    }

    /**
     * Calculates a checksum based on the product's key attributes.
     * @return Checksum integer value
     */
    @Override
    public int getChecksum() {
        return Objects.hash(ean, plu==null? "":plu ,name, description, brand, referenceWeight, referenceVolume, productType, unitName, active, forbiddenToSale);
    }
}

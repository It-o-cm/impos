package com.intermarche.pos.service;

import com.intermarche.pos.domain.SyncOutbox;
import com.intermarche.pos.domain.ticket.TechnicalEvent;
import com.intermarche.pos.service.sync.SyncOutboxService;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;

import java.time.LocalDateTime;

/**
 * Appends entries to the technical event journal, stamped with this register's
 * identifier. Joins the caller's transaction when one is active, so an event
 * and the state change it documents commit or roll back together.
 * <p>
 * The event uid (sync idempotency key) is minted HERE, at creation — the
 * journal has no natural business number, and the uid must exist before the
 * outbox row referencing the event is written in the same transaction. A
 * rolled-back business change therefore leaves neither the event nor its
 * outbox row: the journal never documents something that did not happen.
 */
@ApplicationScoped
public class TechnicalEventService {

    @Inject
    TicketNumberService ticketNumberService;

    @Inject
    SyncOutboxService syncOutboxService;

    /**
     * Records a technical event in the journal.
     *
     * @param type the event type
     * @param detail a short human-readable detail (ticket number, count...)
     */
    @Transactional
    public void log(TechnicalEvent.EventType type, String detail) {
        TechnicalEvent event = new TechnicalEvent();
        event.eventType = type;
        event.terminalId = ticketNumberService.getTerminalId();
        event.eventDate = LocalDateTime.now();
        event.detail = detail;
        event.eventUid = java.util.UUID.randomUUID().toString();
        event.persist();
        syncOutboxService.enqueue(SyncOutbox.EntityType.EVENT, event.id);
    }
}

# impos-hw — handoff for lot 4 (POS-facing HTTP daemon)

## What exists (lots 1-3, all proven on the physical POS on 2026-09-04)
- Pure Java 21, no dependency, single jar: `mvn package` -> `target/impos-hw-0.1.0-SNAPSHOT.jar`.
- `discover`: sysfs inventory + 3-level catalog resolution (VID_PID / VID / PRODUCT_KEYWORD) + passive bus evidence.
- `printer-test`, `drawer-test`: ESC/POS on `/dev/usb/lp0` (`driver/ReceiptPrinter`, `EscPosPrinter`, `DrawerProbe`).
- `scan-watch`, `scan-bridge`: IBM hand-held HID scanner (`driver/BarcodeScanner`, `IbmHidScanner`) -> `PosScanPublisher`
  -> `POST /api/pos/scan` (text/plain body = code).

## Facts about the POS (openSUSE Leap 15.6, offline, root@10.63.31.152, work dir /root/Henri)
- Printer: Epson TM-H6000V, 04b8:0202, serial 583547460027320000, node /dev/usb/lp0 (usblp on a vendor-class interface).
  Answers GS I 66/67 and DLE EOT 1/2/4. Code page 858 validated.
- Cash drawer: present, but NOT on the printer. This terminal is a Diebold Nixdorf BEETLE: the drawer is on its own
  mini-DIN port, behind an I2C GPIO extender (W83601R), and the printer's DK connector is empty (pin 3 stays high, and
  neither ESC p nor the real-time DLE DC4 on either output opens anything). The only supported access is the vendor
  helper /opt/dn/javapos/bin/dn-portio: started with `-b` it daemonizes and takes one letter on
  /var/opt/wn/fifos/fifo_to_portiod -- '1' opens drawer 1 (PROVEN on the till 2026-09-07), '2' drawer 2, 's' status,
  'e' exit. Its watchdog kills the daemon when the process that launched it exits, so the bridge must start it itself.
  MEASURED 2026-09-07: 's' answers 0x40 with the drawer out and 0x00 with it closed -> bit 0x40 is drawer port 1 (the
  helper's own default command mask; port 2 uses 0x80). EVERY order is answered, the opening one included, so each order
  must be followed by the read of its answer or the next reading returns a stale one.
- Scanner: Zebra/Symbol 05e0:0890, serial 19257010552664, IBM hand-held USB mode (two HID interfaces, usage page 0xff45).
  hidraw number changes at every plug -> always locate by identity 05e0:0890:19257010552664 (see Main.locateScannerNode).
  Report: 12 | len | symbology (03 = EAN-13) | flags | one binary digit per byte | 16.
- Customer display: Diebold Nixdorf BA9x, 2f7c:6003, hidraw, usage page 0x80 — protocol not known yet, NOT in scope.
- TPE: Verifone P400, 11ca:0300, /dev/ttyACM0 — protocol depends on the payment application, NOT in scope.
- Scale: Checkout-Dialog-06 on /dev/ttyS4 (NOT ttyS0; the JavaPOS template says ttyS1, the real one is ttyS4), 9600 7O1.
  Protocol read off com.dn.retail.jpos.scale.legacy.DNScale and proven on the till 2026-09-07. Request = EOT STX + two
  ASCII digits of record + ESC-separated fields + ETX; answer = STX + record + fields + ETX, or a bare ACK/NAK.
  Record 08 = status (no field) -> 09 ESC <code>: 00 ready, 11 unit price dropped, 20/21 article has not moved since the
  last weighing, 31 negative, 32 overweight, 33 platter not back to zero for 2 min. Record 01 ESC <unit price on 6
  digits> ESC = SEND THE UNIT PRICE, answered ACK. Then EOT ENQ (bare, no framing) asks for the weighing data ->
  02 ESC <indicator> ESC <grams on 5 digits> ESC <unit price echoed> ESC <amount computed>.
  CONFORMITY CHALLENGE: the scale may answer 11 ESC 2<h1><h2> instead; the answer is record 10 ESC <A><B> where A is
  0x3C8B rotated LEFT h1 times and B is 0x79F7 rotated RIGHT h2 times, 16-bit, four upper-case hex digits each. It
  changes at every request. Without the right answer the scale never weighs.
  IMPORTANT: `stty raw` sets min 1 time 0, where a read blocks for ever -- the line MUST end with `min 0 time 1`.
- 6 native UARTs ttyS0-5; ttyS4 carries the scale, the others unknown.

## Lot 4 — what to build
1. A `serve` command: one process that
   - runs the scan bridge in a background thread (existing `IbmHidScanner` + `PosScanPublisher`),
   - listens on HTTP (jdk.httpserver, still no dependency; port and POS URL configurable),
   - implements EXACTLY the surface impos' hardware rest-client calls today. The contract lives in impos:
     `ui/hardware/RealHardwareResource` (current in-process stub), the `@RegisterRestClient` hardware client it wraps,
     and `src/mock/.../MockHardwareResource` (the test double of the same surface, incl. POST /drawer/close and
     GET /printer/content). Read those three before writing any endpoint.
   - printing goes through `driver/ReceiptPrinter` on the node chosen by discovery (`Main.printerNode`);
     drawer endpoints answer CLOSED / no-op; display endpoints answer 501 or log-only; anything unbound answers
     503 NO_DEVICE_BOUND so impos shows its degraded hardware banner.
2. Keep the CLI commands working; `serve` is an addition.
3. Rules of the house: English code and comments, Javadoc on EVERY method (constructors, private, overrides), no
   single-class packages, strict scope, no git operations.

## Not in scope yet (lot 5)
Pull of HARDWARE_PROFILES from the store node (6th referential domain), inventory outbox, persisted bindings.

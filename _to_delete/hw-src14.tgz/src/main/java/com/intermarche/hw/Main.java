package com.intermarche.hw;

import java.io.IOException;
import java.io.PrintStream;
import java.nio.file.Path;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CountDownLatch;

import com.intermarche.hw.catalog.Candidate;
import com.intermarche.hw.catalog.DeviceResolver;
import com.intermarche.hw.catalog.HardwareProfile;
import com.intermarche.hw.catalog.ProfileCatalog;
import com.intermarche.hw.catalog.Resolution;
import com.intermarche.hw.discovery.DeviceNode;
import com.intermarche.hw.discovery.Inventory;
import com.intermarche.hw.discovery.SerialPort;
import com.intermarche.hw.discovery.SysfsInventory;
import com.intermarche.hw.discovery.UsbDevice;
import com.intermarche.hw.discovery.UsbInterface;
import com.intermarche.hw.driver.DrawerProbe;
import com.intermarche.hw.driver.BarcodeScanner;
import com.intermarche.hw.driver.EscPosPrinter;
import com.intermarche.hw.driver.IbmHidScanner;
import com.intermarche.hw.driver.ReceiptPrinter;
import com.intermarche.hw.discovery.DrawerPortProbe;
import com.intermarche.hw.discovery.MachineIdentity;
import com.intermarche.hw.discovery.PlatformContext;
import com.intermarche.hw.discovery.PlatformFinding;
import com.intermarche.hw.discovery.PlatformInventory;
import com.intermarche.hw.driver.CashDrawer;
import com.intermarche.hw.driver.Cd06Scale;
import com.intermarche.hw.driver.WeighingScale;
import com.intermarche.hw.driver.PortIoDrawer;
import com.intermarche.hw.serve.HardwareEndpoints;
import com.intermarche.hw.serve.HardwareHttpServer;

/**
 * Command-line entry point of the hardware daemon.
 *
 * <p>Commands: {@code discover} scans the bus, resolves every device against the catalog
 * and prints a report with the evidence behind each verdict (lot 1); {@code printer-test}
 * identifies the receipt printer, reads its status and prints a test page;
 * {@code drawer-test} runs the drawer presence and polarity probe (lot 2);
 * {@code scan-watch} decodes the scanner on the console and {@code scan-bridge} pushes
 * every scan onto the POS scan bus (lot 3); {@code serve} runs the daemon the POS talks
 * to — the scan bridge in the background plus the HTTP hardware surface (lot 4). A later
 * lot adds the store synchronisation.
 */
public final class Main {

    /**
     * Prevents instantiation; the class only hosts the entry point.
     */
    private Main() {
    }

    /** Port {@code serve} listens on unless {@code --port} says otherwise. */
    private static final int DEFAULT_PORT = 8081;

    private static final String USAGE =
            "usage: impos-hw discover|printer-test|drawer-test|drawer-open|drawer-status"
                    + "|scale-test|scan-watch|scan-bridge|serve"
                    + " [--sysfs DIR] [--dev DIR] [--proc DIR] [--catalog FILE] [--device NODE] [--timeout MS]"
                    + " [--identity VID:PID:SERIAL] [--pos-url URL] [--drawer-output 0|1] [--pulse-on N]"
                    + " [--port N] [--active] [--scale-port DEV] [--unit-price CENTS]";

    /**
     * Runs the daemon command line.
     *
     * <p>The root options exist to replay a copied tree; {@code --catalog} points at the
     * profiles pulled from the store node, merged over the embedded defaults;
     * {@code --device} overrides the printer node that discovery would otherwise pick;
     * {@code --identity} overrides the scanner identity ({@code vid:pid:serial}) and
     * {@code --pos-url} the POS the bridge posts to; {@code --drawer-output} selects the
     * drawer-kick connector output (0 = pin 2, 1 = pin 5) and {@code --pulse-on} the pulse
     * high time in units of 2 ms for {@code drawer-test}; {@code --port} is the port
     * {@code serve} listens on for the POS hardware surface.
     *
     * @param args command and options
     */
    public static void main(String[] args) {
        if (args.length == 0) {
            System.err.println(USAGE);
            System.exit(2);
        }
        String command = args[0];
        Path sys = Path.of("/sys");
        Path dev = Path.of("/dev");
        Path proc = Path.of("/proc");
        Path root = Path.of("/");
        Path catalogFile = null;
        Path device = null;
        String identity = null;
        String posUrl = "http://localhost:8080";
        Duration timeout = Duration.ofSeconds(2);
        int drawerOutput = 0;
        int pulseOn = DrawerProbe.DEFAULT_ON_TIME;
        int port = DEFAULT_PORT;
        boolean active = false;
        Path scalePort = Path.of("/dev/ttyS4");
        long unitPrice = 100L;
        for (int i = 1; i < args.length; i++) {
            String value = i + 1 < args.length ? args[i + 1] : null;
            switch (args[i]) {
                case "--sysfs" -> sys = Path.of(require(value, args[i]));
                case "--root" -> root = Path.of(require(value, args[i]));
                case "--dev" -> dev = Path.of(require(value, args[i]));
                case "--proc" -> proc = Path.of(require(value, args[i]));
                case "--catalog" -> catalogFile = Path.of(require(value, args[i]));
                case "--device" -> device = Path.of(require(value, args[i]));
                case "--timeout" -> timeout = Duration.ofMillis(Long.parseLong(require(value, args[i])));
                case "--identity" -> identity = require(value, args[i]);
                case "--pos-url" -> posUrl = require(value, args[i]);
                case "--drawer-output" -> drawerOutput = Integer.parseInt(require(value, args[i]));
                case "--pulse-on" -> pulseOn = Integer.parseInt(require(value, args[i]));
                case "--port" -> port = Integer.parseInt(require(value, args[i]));
                case "--scale-port" -> scalePort = Path.of(require(value, args[i]));
                case "--unit-price" -> unitPrice = Long.parseLong(require(value, args[i]));
                case "--active" -> {
                    active = true;
                    i--;
                }
                default -> {
                    System.err.println("unknown option " + args[i]);
                    System.exit(2);
                }
            }
            i++;
        }
        ProfileCatalog catalog = ProfileCatalog.load(catalogFile);
        Inventory inventory = new SysfsInventory(sys, dev, proc).scan();
        List<Resolution> resolutions = new DeviceResolver(catalog).resolveAll(inventory);
        try {
            switch (command) {
                case "discover" -> printReport(System.out, catalog, inventory, resolutions,
                        MachineIdentity.read(sys),
                        PlatformInventory.scan(new PlatformContext(root, sys, active, System.out::println)));
                case "printer-test" -> printerTest(System.out, printerNode(device, resolutions), timeout);
                case "drawer-test" -> drawerTest(System.out, printerNode(device, resolutions), timeout,
                        drawerOutput, pulseOn);
                case "scale-test" -> scaleTest(System.out, scalePort, unitPrice, timeout);
                case "drawer-open" -> drawerOpen(System.out, timeout);
                case "drawer-status" -> drawerStatus(System.out, timeout);
                case "scan-watch" -> scanWatch(System.out, scannerIdentity(identity, resolutions), sys, dev, proc);
                case "scan-bridge" -> scanBridge(System.out, scannerIdentity(identity, resolutions), sys, dev, proc,
                        posUrl, timeout);
                case "serve" -> serve(System.out, optionalPrinterNode(device, resolutions),
                        optionalScannerIdentity(identity, resolutions), root, sys, dev, proc, posUrl, timeout,
                        port);
                default -> {
                    System.err.println(USAGE);
                    System.exit(2);
                }
            }
        } catch (IOException e) {
            System.err.println("error: " + e.getClass().getSimpleName() + ": " + e.getMessage());
            System.exit(1);
        }
    }

    /**
     * Runs the POS-facing daemon: the scan bridge in the background and the HTTP hardware
     * surface in front, in one process.
     *
     * <p>Neither peripheral is required to start. A missing printer or scanner is a
     * BINDING state, not a failure: the daemon serves anyway and the endpoints of the
     * unbound role answer 503, which is what lets the POS report degraded hardware
     * instead of losing its bridge entirely. The scan bridge runs on a daemon thread and
     * survives a re-enumerated scanner on its own (the scanner relocates its node by
     * identity), so the main thread only waits for the stop signal.
     *
     * @param out      destination stream
     * @param node     the printer node, or {@code null} when none was bound
     * @param identity the scanner identity, or {@code null} when none was bound
     * @param root     filesystem root, overridable to replay a copied tree
     * @param sys      sysfs root
     * @param dev      dev root
     * @param proc     proc root
     * @param posUrl   base URL of the POS the scan bridge posts to
     * @param timeout  HTTP and printer reply timeout
     * @param port     the port to listen on
     * @throws IOException if the port cannot be bound
     */
    private static void serve(PrintStream out, Path node, String identity, Path root, Path sys, Path dev,
            Path proc, String posUrl, Duration timeout, int port) throws IOException {
        out.println("printer node " + (node == null ? "(none bound - printing answers 503)" : node));
        CashDrawer drawer = bindDrawer(out, root, sys, timeout);
        HardwareEndpoints endpoints = new HardwareEndpoints(node, drawer, timeout, out::println);
        HardwareHttpServer server = new HardwareHttpServer(port, endpoints, out::println);
        server.start();
        out.println("hardware api " + server.baseUrl());
        if (identity == null) {
            out.println("scanner      (none bound - scan bridge not started)");
        } else {
            startScanBridge(out, identity, sys, dev, proc, posUrl, timeout);
        }
        awaitStop(out, server);
    }

    /**
     * Exercises a Checkout-Dialog-06 scale: status, then one weighing.
     *
     * <p>Every frame of the dialogue is printed, sent and received, control bytes
     * named. That is the point of the command: a scale model that answers something
     * this driver does not decode yet must show WHAT it answered, not just fail.
     *
     * @param out       destination stream
     * @param port      the serial port the scale is on
     * @param unitPrice the unit price in cents sent with the weighing request
     * @param timeout   maximum wait for one answer
     * @throws IOException if the scale cannot be reached
     */
    private static void scaleTest(PrintStream out, Path port, long unitPrice, Duration timeout)
            throws IOException {
        out.println("scale port   " + port);
        try (Cd06Scale scale = new Cd06Scale(port, timeout, out::println)) {
            out.println("scale status " + scale.status());
            WeighingScale.Reading reading = scale.weigh(unitPrice);
            printFrames(out, reading.rawFrames());
            out.println("scale weight " + (reading.grams() == null
                    ? "(no weight in the answer - see the frames above)"
                    : reading.grams() + " g  (indicator " + reading.status()
                            + ", amount " + reading.calculatedPrice() + ")"));
        } catch (WeighingScale.ExchangeFailed e) {
            // The frames matter MORE when the dialogue fails than when it works: they
            // are the only description of a model this driver does not know yet.
            printFrames(out, e.frames());
            out.println("scale        failed: " + e.getMessage());
        }
    }

    /**
     * Prints an exchange, one frame per line.
     *
     * @param out    destination stream
     * @param frames the frames, in the order they were sent and received
     */
    private static void printFrames(PrintStream out, java.util.List<String> frames) {
        for (String frame : frames) {
            out.println("scale        " + frame);
        }
    }

    /**
     * Opens the cash drawer bound to the terminal's own port.
     *
     * @param out     destination stream
     * @param timeout maximum wait for one exchange with the vendor helper
     * @throws IOException if the drawer cannot be commanded
     */
    private static void drawerOpen(PrintStream out, Duration timeout) throws IOException {
        PortIoDrawer drawer = new PortIoDrawer(timeout, out::println);
        if (!drawer.isPresent()) {
            out.println("drawer       no terminal drawer port on this machine");
            return;
        }
        try {
            drawer.open();
            out.println("drawer       open order sent");
        } finally {
            drawer.close();
        }
    }

    /**
     * Reads the raw status byte of the terminal's drawer ports.
     *
     * <p>Printed verbatim, not interpreted: the byte covers both ports and the bit
     * carrying port 1 has to be MEASURED, once with the drawer open and once closed.
     * This command is what takes that measurement.
     *
     * @param out     destination stream
     * @param timeout maximum wait for one exchange with the vendor helper
     * @throws IOException if the status cannot be read
     */
    private static void drawerStatus(PrintStream out, Duration timeout) throws IOException {
        PortIoDrawer drawer = new PortIoDrawer(timeout, out::println);
        if (!drawer.isPresent()) {
            out.println("drawer       no terminal drawer port on this machine");
            return;
        }
        try {
            out.println("drawer       status answer: " + drawer.rawStatus());
        } finally {
            drawer.close();
        }
    }

    /**
     * Binds the cash drawer of this till, through the SAME probe the discovery report
     * uses.
     *
     * <p>One decision, one place: what {@code discover} prints and what {@code serve}
     * binds cannot drift apart, and the evidence is repeated in the daemon's log so a
     * binding can be explained without re-running discovery. The probe is run in its
     * passive form — the daemon must not exercise the hardware at start-up.
     *
     * <p>Only one binding exists so far, the terminal's own port behind the vendor
     * helper; a till whose probe says ABSENT has no drawer as far as the daemon is
     * concerned, and its endpoints answer 503 rather than pretending. The printer's
     * kick connector is deliberately NOT a fallback: on this terminal it is empty, and
     * pulsing an empty connector looks like success while nothing opens.
     *
     * @param out     destination stream
     * @param root    filesystem root
     * @param sys     sysfs root
     * @param timeout maximum wait for one exchange with the helper
     * @return the drawer, or {@code null} when this till binds none
     */
    private static CashDrawer bindDrawer(PrintStream out, Path root, Path sys, Duration timeout) {
        PlatformFinding finding = new DrawerPortProbe()
                .probe(new PlatformContext(root, sys, false, out::println));
        for (String evidence : finding.evidence()) {
            out.println("drawer       " + evidence);
        }
        if (finding.verdict() == PlatformFinding.Verdict.ABSENT) {
            out.println("drawer       (none bound - " + finding.detail() + ")");
            return null;
        }
        out.println("drawer node  " + finding.driver() + " on the terminal port");
        return new PortIoDrawer(root, timeout, out::println);
    }

    /**
     * Starts the scan bridge on a background daemon thread.
     *
     * @param out      destination stream
     * @param identity the scanner identity
     * @param sys      sysfs root
     * @param dev      dev root
     * @param proc     proc root
     * @param posUrl   base URL of the POS
     * @param timeout  HTTP timeout
     */
    private static void startScanBridge(PrintStream out, String identity, Path sys, Path dev, Path proc,
            String posUrl, Duration timeout) {
        Thread bridge = new Thread(() -> scanBridge(out, identity, sys, dev, proc, posUrl, timeout), "scan-bridge");
        bridge.setDaemon(true);
        bridge.start();
    }

    /**
     * Blocks until the process is asked to stop, then releases the port.
     *
     * <p>The shutdown hook is what makes {@code Ctrl-C} and {@code systemctl stop} leave
     * a bound port behind them rather than a socket the next start would trip on.
     *
     * @param out    destination stream
     * @param server the running server to stop
     */
    private static void awaitStop(PrintStream out, HardwareHttpServer server) {
        CountDownLatch stop = new CountDownLatch(1);
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            server.stop();
            stop.countDown();
        }, "impos-hw-shutdown"));
        out.println("serve        ready, waiting for the POS (Ctrl-C to stop)");
        try {
            stop.await();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            server.stop();
        }
    }

    /**
     * Chooses the printer node without demanding one, for the daemon.
     *
     * @param explicit    the {@code --device} value, may be {@code null}
     * @param resolutions the resolved devices
     * @return the node path, or {@code null} when no printer is bound
     */
    private static Path optionalPrinterNode(Path explicit, List<Resolution> resolutions) {
        try {
            return printerNode(explicit, resolutions);
        } catch (IOException e) {
            return null;
        }
    }

    /**
     * Chooses the scanner identity without demanding one, for the daemon.
     *
     * @param explicit    the {@code --identity} value, may be {@code null}
     * @param resolutions the resolved devices
     * @return the stable identity, or {@code null} when no scanner is bound
     */
    private static String optionalScannerIdentity(String explicit, List<Resolution> resolutions) {
        try {
            return scannerIdentity(explicit, resolutions);
        } catch (IOException e) {
            return null;
        }
    }

    /**
     * Chooses the printer node: the explicit option, else the first resolved PRINTER that
     * owns a {@code /dev/usb/lpN} node.
     *
     * @param explicit    the {@code --device} value, may be {@code null}
     * @param resolutions the resolved devices
     * @return the node path
     * @throws IOException when no printer node can be found
     */
    private static Path printerNode(Path explicit, List<Resolution> resolutions) throws IOException {
        if (explicit != null) {
            return explicit;
        }
        for (Resolution r : resolutions) {
            Candidate best = r.best();
            if (best == null || best.role() != HardwareProfile.Role.PRINTER) {
                continue;
            }
            for (UsbInterface itf : r.device().interfaces()) {
                for (DeviceNode n : itf.nodes()) {
                    if (n.kind() == DeviceNode.Kind.LP) {
                        return Path.of(n.devPath());
                    }
                }
            }
        }
        throw new IOException("no printer node found by discovery; use --device /dev/usb/lpN");
    }

    /**
     * Chooses the scanner identity: the explicit option, else the first resolved SCANNER.
     *
     * @param explicit    the {@code --identity} value, may be {@code null}
     * @param resolutions the resolved devices
     * @return the stable identity {@code vid:pid[:serial]}
     * @throws IOException when no scanner is found
     */
    private static String scannerIdentity(String explicit, List<Resolution> resolutions) throws IOException {
        if (explicit != null) {
            return explicit;
        }
        for (Resolution r : resolutions) {
            Candidate best = r.best();
            if (best != null && best.role() == HardwareProfile.Role.SCANNER) {
                return r.device().stableIdentity();
            }
        }
        throw new IOException("no scanner found by discovery; use --identity vid:pid:serial");
    }

    /**
     * Resolves a scanner identity to its current first hidraw node by rescanning sysfs,
     * so a re-enumerated device is found under its new number.
     *
     * @param identity the stable identity
     * @param sys      sysfs root
     * @param dev      dev root
     * @param proc     proc root
     * @return the node of the scanner's first HID interface, or empty when absent
     */
    private static Optional<Path> locateScannerNode(String identity, Path sys, Path dev, Path proc) {
        Inventory inventory = new SysfsInventory(sys, dev, proc).scan();
        for (UsbDevice d : inventory.devices()) {
            if (!identity.equalsIgnoreCase(d.stableIdentity())) {
                continue;
            }
            for (UsbInterface itf : d.interfaces()) {
                for (DeviceNode n : itf.nodes()) {
                    if (n.kind() == DeviceNode.Kind.HIDRAW) {
                        return Optional.of(Path.of(n.devPath()));
                    }
                }
            }
        }
        return Optional.empty();
    }

    /**
     * Builds the IBM HID scanner bound to an identity.
     *
     * @param out      log destination
     * @param identity the scanner identity
     * @param sys      sysfs root
     * @param dev      dev root
     * @param proc     proc root
     * @return the scanner
     */
    private static BarcodeScanner scanner(PrintStream out, String identity, Path sys, Path dev, Path proc) {
        out.println("scanner      " + identity + " (IBM HID mode)");
        return new IbmHidScanner(() -> locateScannerNode(identity, sys, dev, proc), Duration.ofSeconds(1),
                m -> out.println("scanner      " + m));
    }

    /**
     * Decodes scans to the console until interrupted.
     *
     * @param out      destination stream
     * @param identity the scanner identity
     * @param sys      sysfs root
     * @param dev      dev root
     * @param proc     proc root
     */
    private static void scanWatch(PrintStream out, String identity, Path sys, Path dev, Path proc) {
        scanner(out, identity, sys, dev, proc).run(e ->
                out.printf("scan         %-8s %s   [%s]%n", e.symbology(), e.code(), e.rawHex()));
    }

    /**
     * Pushes every scan onto the POS scan bus until interrupted.
     *
     * @param out      destination stream
     * @param identity the scanner identity
     * @param sys      sysfs root
     * @param dev      dev root
     * @param proc     proc root
     * @param posUrl   base URL of the POS
     * @param timeout  HTTP timeout
     */
    private static void scanBridge(PrintStream out, String identity, Path sys, Path dev, Path proc, String posUrl,
            Duration timeout) {
        PosScanPublisher publisher = new PosScanPublisher(posUrl, timeout);
        out.println("pos bus      " + publisher.scanUri());
        scanner(out, identity, sys, dev, proc).run(e -> {
            try {
                int status = publisher.publish(e.code());
                out.printf("scan         %-8s %s -> %d%n", e.symbology(), e.code(), status);
            } catch (IOException ex) {
                out.printf("scan         %-8s %s -> POS unreachable: %s%n", e.symbology(), e.code(), ex.getMessage());
            }
        });
    }

    /**
     * Identifies the printer, reads its status and prints a test page.
     *
     * @param out     destination stream
     * @param node    the printer node
     * @param timeout reply timeout
     * @throws IOException if the printer cannot be reached
     */
    private static void printerTest(PrintStream out, Path node, Duration timeout) throws IOException {
        out.println("printer node " + node);
        try (ReceiptPrinter printer = new EscPosPrinter(node, timeout)) {
            ReceiptPrinter.PrinterIdentity id = printer.identify();
            out.println("identity     " + id.manufacturer() + " " + id.model());
            ReceiptPrinter.PrinterStatus st = printer.status();
            out.println("status       " + st);
            String stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));
            printer.printText("IMPOS-HW TEST PAGE\n"
                    + stamp + "\n"
                    + id.manufacturer() + " " + id.model() + "\n"
                    + "node " + node + "\n"
                    + "accents: éèàçù €\n");
            printer.feed(3);
            printer.cut();
            out.println("test page    printed and cut");
        }
    }

    /**
     * Runs the drawer probe and prints its verdict.
     *
     * @param out     destination stream
     * @param node    the printer node the drawer hangs behind
     * @param timeout reply timeout
     * @param output  drawer-kick connector output, 0 or 1
     * @param pulseOn pulse high time in units of 2 ms
     * @throws IOException if the printer cannot be reached
     */
    private static void drawerTest(PrintStream out, Path node, Duration timeout, int output, int pulseOn)
            throws IOException {
        out.println("printer node " + node);
        out.printf("pulse        output %d, %d ms high%n", output, pulseOn * 2);
        try (ReceiptPrinter printer = new EscPosPrinter(node, timeout)) {
            DrawerProbe.Result r = new DrawerProbe(printer, Duration.ofMillis(1500))
                    .run(output, pulseOn, DrawerProbe.DEFAULT_OFF_TIME);
            out.println("pin before   " + (r.pinBefore() ? "high" : "low"));
            if (r.detected()) {
                out.printf("drawer       DETECTED: pin changed to %s after %d ms -> open = %s%n",
                        r.pinAfter() ? "high" : "low", r.elapsed().toMillis(), r.openIsHigh() ? "high" : "low");
            } else {
                out.printf("drawer       NOT DETECTED: pin unchanged for %d ms"
                        + " (no drawer, cable unplugged, or drawer locked)%n", r.elapsed().toMillis());
            }
        }
    }

    /**
     * Ensures an option received its value.
     *
     * @param value  the value following the option, may be {@code null}
     * @param option the option name, for the error message
     * @return the value
     */
    private static String require(String value, String option) {
        if (value == null) {
            System.err.println("missing value for " + option);
            System.exit(2);
        }
        return value;
    }

    /**
     * Prints the discovery report.
     *
     * @param out         destination stream
     * @param catalog     the catalog used
     * @param inventory   the scanned inventory
     * @param resolutions the resolutions, one per device
     */
    static void printReport(PrintStream out, ProfileCatalog catalog, Inventory inventory,
            List<Resolution> resolutions, MachineIdentity machine, List<PlatformFinding> platform) {
        out.printf("impos-hw discovery - %d USB device(s), %d native serial port(s), catalog of %d profile(s)%n",
                inventory.devices().size(), inventory.nativePorts().size(), catalog.size());
        out.printf("terminal     %s%n%n", machine.describe());
        for (Resolution r : resolutions) {
            printDevice(out, r);
        }
        for (SerialPort p : inventory.nativePorts()) {
            out.printf("[NATIVE SERIAL] %s  uart=%s  (role needs a probe)%n", p.devPath(), p.uartType());
        }
        out.println();
        printPlatform(out, platform);
        out.println("Summary:");
        for (Resolution.Verdict v : Resolution.Verdict.values()) {
            long n = resolutions.stream().filter(r -> r.verdict() == v).count();
            if (n > 0) {
                out.printf("  %-10s %d%n", v, n);
            }
        }
    }

    /**
     * Prints the built-in hardware section: what the buses cannot show.
     *
     * <p>The evidence is printed with each finding on purpose. A drawer on an I2C
     * line is not something anybody can see or plug-test, so the report has to
     * justify itself, and the day a finding is wrong the wrong step is visible.
     *
     * @param out      destination stream
     * @param findings what the platform probes concluded
     */
    private static void printPlatform(PrintStream out, List<PlatformFinding> findings) {
        out.println("Built-in hardware (not on any bus):");
        for (PlatformFinding f : findings) {
            out.printf("  [%s] %s  driver=%s  %s%n", f.verdict(), f.role(), f.driver(), f.detail());
            for (String e : f.evidence()) {
                out.printf("      - %s%n", e);
            }
        }
        out.println();
    }

    /**
     * Prints one device block: identity, interfaces and nodes, candidates, verdict.
     *
     * @param out destination stream
     * @param r   the resolution to print
     */
    private static void printDevice(PrintStream out, Resolution r) {
        UsbDevice d = r.device();
        out.printf("[%s] bus %03d dev %03d  %s  %s%n", r.verdict(), d.busNumber(), d.deviceNumber(),
                d.vidPid(), describe(d));
        if (d.serial() != null) {
            out.printf("    serial   %s   identity %s%n", d.serial(), d.stableIdentity());
        }
        for (UsbInterface itf : d.interfaces()) {
            out.printf("    if %d  class %s/%s proto %s  driver %s%n", itf.number(), itf.interfaceClass(),
                    itf.subClass(), itf.protocol(), itf.driver() == null ? "-" : itf.driver());
            for (DeviceNode n : itf.nodes()) {
                out.printf("          %-6s %s%s%s%n", n.kind(), n.devPath(),
                        n.byIdPath() == null ? "" : "  by-id " + n.byIdPath(),
                        n.hidUsagePages().isEmpty() ? "" : "  usage pages " + hex(n.hidUsagePages()));
            }
        }
        if (r.candidates().isEmpty()) {
            out.println("    no candidate - report upward as unknown");
        }
        for (Candidate c : r.candidates()) {
            out.printf("    %-6s %-8s %-13s %s%n", c.confidence(), c.role() == null ? "?" : c.role(),
                    c.driver() == null ? "-" : c.driver(), c.evidence());
        }
        out.println();
    }

    /**
     * Builds the human-readable name of a device from its string descriptors.
     *
     * @param d the device
     * @return {@code manufacturer product} with absent parts omitted
     */
    private static String describe(UsbDevice d) {
        String m = d.manufacturer() == null ? "" : d.manufacturer();
        String p = d.product() == null ? "" : d.product();
        String s = (m + " " + p).strip();
        return s.isEmpty() ? "(no string descriptors)" : s;
    }

    /**
     * Formats usage pages as hex.
     *
     * @param pages the usage pages
     * @return e.g. {@code 0x01 0x8c}
     */
    private static String hex(java.util.Set<Integer> pages) {
        StringBuilder sb = new StringBuilder();
        for (int p : pages) {
            if (!sb.isEmpty()) {
                sb.append(' ');
            }
            sb.append(String.format("0x%02x", p));
        }
        return sb.toString();
    }
}

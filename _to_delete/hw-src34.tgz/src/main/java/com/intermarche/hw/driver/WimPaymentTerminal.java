package com.intermarche.hw.driver;

import java.io.IOException;
import java.nio.file.Path;
import java.time.Duration;
import java.util.function.Consumer;

/**
 * A payment terminal driven through the vendor's payment client.
 *
 * <p>This is where the protocol lives: {@link WimClient} carries bytes, this class knows
 * what to say. Messages are a flat sequence of {@code {TAG}value}; the login is
 * {@code {SV}s0{CD}c2g} and a card debit {@code {SV}s0{CD}c1}, both carrying the island
 * label the payment server identifies the store by.
 *
 * <p>Three values come from the site and none of them has a sensible default: the client
 * directory, the acceptance point number the server knows this till by, and the island
 * label. A wrong acceptance point number is answered with a refusal whose ticket reads
 * "Le numero de poste n'est pas reconnu par le serveur".
 */
public final class WimPaymentTerminal implements PaymentTerminal {

    /** Currency code of the euro, as the specification writes it. */
    private static final String EURO = "978";

    /**
     * Operating mode sent with a debit.
     *
     * <p>Normal, so test cards are refused. The specification makes the tag mandatory
     * but only vending machines act on it; on a till with an operator it is inert.
     */
    private static final String MODE_NORMAL = "0";

    /** Ticket mode: tickets travel in the messages between server and till. */
    private static final String TICKETS_IN_MESSAGES = "1";

    /** Service code of the card service, carried by every request here. */
    private static final String CARD_SERVICE = "s0";

    /** Tag carrying the result code of an answer. */
    private static final String RESULT_TAG = "{RS}";

    /** The client this terminal talks through. */
    private final WimClient client;

    /** The island label the payment server identifies the store by. */
    private final String islandLabel;

    /** How long a login may take, firmware update included. */
    private final Duration loginTimeout;

    /** How long a payment may take, the cardholder's own time included. */
    private final Duration paymentTimeout;

    /** Where the terminal narrates what it does. */
    private final Consumer<String> log;

    /**
     * Starts the payment client and holds the session open.
     *
     * @param clientDirectory the payment client's own directory
     * @param station         the acceptance point number the payment server knows this
     *                        till by
     * @param islandLabel     the island label of the store
     * @param loginTimeout    how long a login may take
     * @param paymentTimeout  how long a payment may take
     * @param log             destination of the dialogue log lines
     * @throws IOException if the client could not be loaded or did not start
     */
    public WimPaymentTerminal(Path clientDirectory, int station, String islandLabel,
            Duration loginTimeout, Duration paymentTimeout, Consumer<String> log) throws IOException {
        this.islandLabel = islandLabel;
        this.loginTimeout = loginTimeout;
        this.paymentTimeout = paymentTimeout;
        this.log = log;
        this.client = new WimClient(clientDirectory, log);
        int started = client.start(station);
        if (started != WimClient.OK) {
            client.close();
            throw new IOException("payment client did not start: " + WimClient.describe(started));
        }
    }

    /** {@inheritDoc} */
    @Override
    public Result login() throws IOException {
        return exchange("{SV}" + CARD_SERVICE + "{CD}c2g{D7V}" + islandLabel, loginTimeout);
    }

    /** {@inheritDoc} */
    @Override
    public Result debit(long amountCents) throws IOException {
        String request = "{SV}" + CARD_SERVICE + "{CD}c1"
                + "{D10}" + amountCents
                + "{D0}" + EURO
                + "{D13}" + MODE_NORMAL
                + "{D7V}" + islandLabel
                + "{TT}" + TICKETS_IN_MESSAGES;
        return exchange(request, paymentTimeout);
    }

    /** {@inheritDoc} */
    @Override
    public void close() {
        client.close();
    }

    /**
     * Sends one request and reads the result code out of the answer.
     *
     * @param request the request
     * @param timeout how long the whole exchange may take
     * @return the outcome
     * @throws IOException if the client could not be reached
     */
    private Result exchange(String request, Duration timeout) throws IOException {
        String answer = client.exchange(CARD_SERVICE, request, timeout.toMillis());
        // No answer at all is not a refusal: a refusal carries a result code. It means the
        // client stopped answering, and the session it held is gone with it. Saying so is
        // what lets the caller open a new one instead of reporting a declined payment.
        if (answer.isEmpty()) {
            throw new IOException("the payment client stopped answering");
        }
        String code = tagValue(answer, RESULT_TAG);
        log.accept("tpe          result " + (code.isEmpty() ? "(none)" : code));
        return new Result(code, answer);
    }

    /**
     * Reads the value of one tag out of a message.
     *
     * <p>Values have no terminator of their own: a value runs to the opening brace of
     * the next tag, or to the end of the message when it is the last one.
     *
     * @param message the message
     * @param tag     the tag, braces included
     * @return the value, empty when the tag is absent
     */
    private static String tagValue(String message, String tag) {
        int start = message.indexOf(tag);
        if (start < 0) {
            return "";
        }
        int from = start + tag.length();
        int next = message.indexOf('{', from);
        return next < 0 ? message.substring(from) : message.substring(from, next);
    }
}

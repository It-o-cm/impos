package com.intermarche.pos.ui.hardware.scanner;

import org.junit.jupiter.api.Test;

import java.io.File;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Unit tests for the pure parts of {@link ScannerDiscovery}: the name
 * matching that keeps the exclusive grab off genuine keyboards, and the
 * stable ordering of candidate nodes. The native name read is not unit
 * tested (it needs a real device).
 */
class ScannerDiscoveryTest {

    /** A discovery over the default retail signatures. */
    private final ScannerDiscovery discovery = new ScannerDiscovery(
            new File("/dev/input"),
            List.of("symbol", "zebra", "honeywell", "datalogic", "scanner"));

    /**
     * A Symbol/Zebra scanner name matches (the case-insensitive substring
     * arm), whatever the surrounding words.
     */
    @Test
    void matchesSymbolScanner() {
        assertTrue(discovery.matches("Symbol Technologies, Inc, 2008 Symbol Bar Code Scanner"));
    }

    /**
     * A brand named in a different case still matches.
     */
    @Test
    void matchesRegardlessOfCase() {
        assertTrue(discovery.matches("HONEYWELL Voyager 1450g"));
    }

    /**
     * A genuine USB keyboard does NOT match, so it is never grabbed — the
     * whole point of matching by name.
     */
    @Test
    void doesNotMatchAKeyboard() {
        assertFalse(discovery.matches("Dell Dell USB Keyboard"));
    }

    /**
     * A null name (unreadable device) does not match.
     */
    @Test
    void doesNotMatchNull() {
        assertFalse(discovery.matches(null));
    }

    /**
     * An absent input directory yields no candidate nodes rather than
     * faulting.
     */
    @Test
    void absentDirectoryYieldsNoCandidates() {
        ScannerDiscovery missing = new ScannerDiscovery(
                new File("/nonexistent-input-dir"), List.of("scanner"));
        assertTrue(missing.candidateNodes().isEmpty());
    }

    /**
     * Candidate nodes are the {@code eventN} files, in stable name order,
     * ignoring the other input nodes.
     *
     * @param tmp a temporary directory provided by JUnit
     * @throws Exception on file-creation failure
     */
    @Test
    void candidateNodesAreEventFilesInOrder(@org.junit.jupiter.api.io.TempDir File tmp) throws Exception {
        new File(tmp, "event2").createNewFile();
        new File(tmp, "event0").createNewFile();
        new File(tmp, "event10").createNewFile();
        new File(tmp, "mouse0").createNewFile();
        new File(tmp, "by-id").mkdir();
        ScannerDiscovery local = new ScannerDiscovery(tmp, List.of("scanner"));
        List<File> nodes = local.candidateNodes();
        assertEquals(List.of("event0", "event10", "event2"),
                nodes.stream().map(File::getName).toList());
    }
}

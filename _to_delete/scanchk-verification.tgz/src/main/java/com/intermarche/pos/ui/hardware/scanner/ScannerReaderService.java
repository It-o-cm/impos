package com.intermarche.pos.ui.hardware.scanner;

import io.quarkus.arc.profile.IfBuildProfile;
import io.quarkus.runtime.StartupEvent;
import jakarta.annotation.PreDestroy;
import jakarta.enterprise.event.Observes;
import jakarta.inject.Singleton;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.jboss.logging.Logger;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * The REAL barcode-scanner reader of a production till (prod build only):
 * discovers the attached scanners by identity, takes the exclusive grab of
 * each, decodes their keystrokes into codes and pushes every code into the
 * register's scan chain — the same chain the simulator and a keyboard wedge
 * feed, through {@code POST /api/pos/scan}.
 * <p>
 * Why grab and loopback rather than a browser keyboard wedge:
 * <ul>
 *   <li>The exclusive grab ({@code EVIOCGRAB}) means a scan reaches the
 *       register whatever holds the screen focus, and is never ALSO typed
 *       into a field — the kiosk browser, an admin form, anything.</li>
 *   <li>Pushing to the loopback scan endpoint reuses the exact request and
 *       transaction scope of every other scan path, so nothing downstream
 *       knows or cares that the code came from a physical device.</li>
 * </ul>
 * One daemon thread per grabbed device blocks on {@code read(2)}; a
 * {@link #stop()} on shutdown ungrabs and closes every device and lets the
 * threads end — the maison @PreDestroy pattern, so a redeploy leaves no
 * device grabbed.
 */
@Singleton
@IfBuildProfile("prod")
public class ScannerReaderService {

    /** The class logger. */
    private static final Logger LOG = Logger.getLogger(ScannerReaderService.class);

    /** Whether the reader runs at all (a till with no scanner turns it off). */
    @ConfigProperty(name = "pos.scanner.enabled", defaultValue = "true")
    boolean enabled;

    /**
     * The scanner name signatures, matched case-insensitively against each
     * input device's advertised name. Default = the common retail brands;
     * override per till for an unusual model — no rebuild.
     */
    @ConfigProperty(name = "pos.scanner.name-patterns",
            defaultValue = "symbol,zebra,honeywell,datalogic,newland,opticon,scanner,barcode")
    List<String> namePatterns;

    /**
     * The loopback endpoint the decoded codes are pushed to — the register's
     * own scan intake. Points at the app itself by default, like the
     * hardware client.
     */
    @ConfigProperty(name = "pos.scanner.sink-url",
            defaultValue = "http://127.0.0.1:8080/api/pos/scan")
    String sinkUrl;

    /** The HTTP client pushing codes to the scan intake. */
    private final HttpClient httpClient = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(2))
            .build();

    /** The reader threads, one per grabbed device. */
    private final List<Thread> readers = new ArrayList<>();

    /** The grabbed file descriptors, closed on shutdown to release the grab. */
    private final List<Integer> grabbedFds = new ArrayList<>();

    /** Cleared on shutdown so the reader loops end. */
    private volatile boolean running = true;

    /**
     * Discovers the scanners and starts one reader thread per device at boot.
     *
     * @param event the application startup event
     */
    void onStart(@Observes StartupEvent event) {
        if (!enabled) {
            LOG.info("Lecteur douchette desactive (pos.scanner.enabled=false).");
            return;
        }
        List<java.io.File> devices = new ScannerDiscovery(namePatterns).discover();
        for (java.io.File device : devices) {
            startReader(device.getAbsolutePath());
        }
    }

    /**
     * Opens and grabs one device, then starts its blocking reader thread. A
     * device that cannot be opened or grabbed (missing udev rights, already
     * grabbed) is logged and skipped — one unreadable scanner never stops the
     * others or the register.
     *
     * @param path the device node path
     */
    private void startReader(String path) {
        int fd = LinuxInput.C.open(path, LinuxInput.O_RDONLY);
        if (fd < 0) {
            LOG.errorf("Ouverture douchette impossible: %s (droits udev sur /dev/input ?)", path);
            return;
        }
        if (LinuxInput.C.ioctl(fd, LinuxInput.EVIOCGRAB, 1) != 0) {
            LOG.errorf("Prise exclusive (grab) impossible sur %s", path);
            LinuxInput.C.close(fd);
            return;
        }
        grabbedFds.add(fd);
        KeyboardScancodeDecoder decoder = new KeyboardScancodeDecoder(this::pushCode);
        Thread reader = new Thread(() -> readLoop(fd, path, decoder), "scanner-reader-" + path);
        reader.setDaemon(true);
        readers.add(reader);
        reader.start();
        LOG.infof("Lecture douchette active sur %s", path);
    }

    /**
     * The per-device read loop: blocks on {@code read(2)}, splits the buffer
     * into 24-byte records, and feeds each key press to the decoder. Ends
     * when {@link #running} clears or the device reports end/failure.
     *
     * @param fd the grabbed file descriptor
     * @param path the device path, for logging
     * @param decoder the code assembler fed by this device
     */
    private void readLoop(int fd, String path, KeyboardScancodeDecoder decoder) {
        byte[] buffer = new byte[LinuxInput.INPUT_EVENT_SIZE * 32];
        while (running) {
            int read = LinuxInput.C.read(fd, buffer, buffer.length);
            if (read <= 0) {
                if (running) {
                    LOG.warnf("Fin de lecture douchette %s (read=%d)", path, read);
                }
                return;
            }
            int records = read / LinuxInput.INPUT_EVENT_SIZE;
            for (int i = 0; i < records; i++) {
                InputEvent event = InputEvent.parse(buffer, i * LinuxInput.INPUT_EVENT_SIZE);
                if (event.isKeyPress()) {
                    decoder.onKeyPress(event.code());
                }
            }
        }
    }

    /**
     * Pushes one completed code to the loopback scan intake. A push failure
     * is logged and dropped — a network blip on the loopback must never
     * throw on the reader thread and kill it.
     *
     * @param code the decoded barcode
     */
    void pushCode(String code) {
        try {
            HttpRequest request = HttpRequest.newBuilder(URI.create(sinkUrl))
                    .header("Content-Type", "text/plain")
                    .POST(HttpRequest.BodyPublishers.ofString(code))
                    .timeout(Duration.ofSeconds(2))
                    .build();
            httpClient.send(request, HttpResponse.BodyHandlers.discarding());
        } catch (Exception e) {
            LOG.errorf("Envoi du code douchette '%s' echoue: %s", code, e.getMessage());
            if (e instanceof InterruptedException) {
                Thread.currentThread().interrupt();
            }
        }
    }

    /**
     * Ungrabs and closes every device on shutdown so a redeploy leaves no
     * scanner grabbed (the JVM would otherwise keep the exclusive hold until
     * the OS reclaims the fd).
     */
    @PreDestroy
    void stop() {
        running = false;
        for (int fd : grabbedFds) {
            LinuxInput.C.ioctl(fd, LinuxInput.EVIOCGRAB, 0);
            LinuxInput.C.close(fd);
        }
        grabbedFds.clear();
        readers.clear();
    }
}

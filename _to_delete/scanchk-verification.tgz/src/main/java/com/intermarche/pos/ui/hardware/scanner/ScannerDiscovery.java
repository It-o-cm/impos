package com.intermarche.pos.ui.hardware.scanner;

import org.jboss.logging.Logger;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/**
 * Autodiscovery of barcode scanners on the Linux input layer.
 * <p>
 * The register cannot assume a fixed {@code /dev/input/eventN} — the numbers
 * shuffle at every reconnection — so the reader discovers by IDENTITY, not by
 * node: it reads each event device's advertised name ({@code EVIOCGNAME}) and
 * keeps only the ones whose name matches a known scanner signature
 * (configurable, defaulting to the common retail brands — Symbol/Zebra,
 * Honeywell, Datalogic, Newland...). Matching by name, never by "has keys",
 * is what makes the exclusive grab safe: a genuine USB keyboard plugged in
 * beside the scanner does not match, so it is never grabbed.
 */
public class ScannerDiscovery {

    /** The class logger. */
    private static final Logger LOG = Logger.getLogger(ScannerDiscovery.class);

    /** The input-layer directory holding the event device nodes. */
    private final File inputDir;

    /** The lower-cased name fragments that identify a scanner. */
    private final List<String> patterns;

    /**
     * Builds a discovery over the standard input directory.
     *
     * @param patterns the scanner name fragments (case-insensitive)
     */
    public ScannerDiscovery(List<String> patterns) {
        this(new File("/dev/input"), patterns);
    }

    /**
     * Builds a discovery over an explicit directory (test seam).
     *
     * @param inputDir the directory holding the {@code eventN} nodes
     * @param patterns the scanner name fragments (case-insensitive)
     */
    ScannerDiscovery(File inputDir, List<String> patterns) {
        this.inputDir = inputDir;
        this.patterns = patterns.stream().map(p -> p.toLowerCase(Locale.ROOT)).toList();
    }

    /**
     * Whether a device name matches any configured scanner signature.
     *
     * @param deviceName the device's advertised name, or null
     * @return true when the name contains a configured fragment
     */
    boolean matches(String deviceName) {
        if (deviceName == null) {
            return false;
        }
        String lower = deviceName.toLowerCase(Locale.ROOT);
        return patterns.stream().anyMatch(lower::contains);
    }

    /**
     * Lists the {@code eventN} nodes of the input directory, in name order so
     * the result is stable across runs.
     *
     * @return the candidate device files, empty when the directory is absent
     */
    List<File> candidateNodes() {
        File[] nodes = inputDir.listFiles((dir, name) -> name.startsWith("event"));
        if (nodes == null) {
            return List.of();
        }
        List<File> sorted = new ArrayList<>(Arrays.asList(nodes));
        sorted.sort((a, b) -> a.getName().compareTo(b.getName()));
        return sorted;
    }

    /**
     * Reads one device's advertised name through {@code EVIOCGNAME}, opening
     * and closing the node. Returns null when the node cannot be opened or
     * named (a device the register has no rights on, or one that vanished).
     *
     * @param node the event device node
     * @return the device name, trimmed at the first NUL, or null
     */
    String readName(File node) {
        int fd = LinuxInput.C.open(node.getAbsolutePath(), LinuxInput.O_RDONLY);
        if (fd < 0) {
            return null;
        }
        try {
            byte[] buffer = new byte[256];
            int written = LinuxInput.C.ioctl(fd, LinuxInput.eviocgname(buffer.length), buffer);
            if (written <= 0) {
                return null;
            }
            int end = 0;
            while (end < buffer.length && buffer[end] != 0) {
                end++;
            }
            return new String(buffer, 0, end, StandardCharsets.UTF_8);
        } finally {
            LinuxInput.C.close(fd);
        }
    }

    /**
     * Discovers the scanner device nodes present now: every candidate whose
     * advertised name matches a scanner signature.
     *
     * @return the matched device files, in stable node order
     */
    public List<File> discover() {
        List<File> found = new ArrayList<>();
        for (File node : candidateNodes()) {
            String name = readName(node);
            if (matches(name)) {
                LOG.infof("Douchette detectee: %s (%s)", name, node.getAbsolutePath());
                found.add(node);
            }
        }
        if (found.isEmpty()) {
            LOG.warn("Aucune douchette detectee a l'autodecouverte du materiel.");
        }
        return found;
    }
}

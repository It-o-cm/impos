package com.intermarche.hw.driver;

import java.io.IOException;
import java.lang.foreign.Arena;
import java.lang.foreign.FunctionDescriptor;
import java.lang.foreign.Linker;
import java.lang.foreign.MemorySegment;
import java.lang.foreign.SymbolLookup;
import java.lang.foreign.ValueLayout;
import java.lang.invoke.MethodHandle;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.function.Consumer;

/**
 * The payment client of the till, reached through the vendor's own shared library.
 *
 * <p>The payment terminal is not driven by the POS: a certified client process
 * ({@code mcl_71.lux}) owns the reader and the bank dialogue, and the POS talks to that
 * process. The channel is {@code libWCL_DLL.so}, whose C++ symbols carry their own
 * prototypes:
 * <ul>
 *   <li>{@code WimDiaOpen()} — attach to the client;</li>
 *   <li>{@code WimDiaWrite(char*)} — send it a tagged message;</li>
 *   <li>{@code WimDiaRead(char*, int, long)} — read one, with a timeout;</li>
 *   <li>{@code WimDiaClose()} — detach.</li>
 * </ul>
 *
 * <p>The higher-level {@code SWimApiOpen} is deliberately NOT used: its own code shows
 * it only wipes {@code ./WSEM}, sets a log path and then runs
 * {@code system("./start_mcl.lux ...")} — it starts the client. Since the daemon starts
 * and supervises that process itself, going through the lower layer keeps one owner for
 * the client's lifecycle instead of two. For the same reason {@code SWimApiClose} is
 * avoided: it runs {@code ./stop_mcl.lux}, which would kill a client this process does
 * not own.
 *
 * <p>Two constraints come from the library, not from us. The client's files are all
 * RELATIVE ({@code ./WSEM}, {@code ./WLOG}, {@code ./WSHAREMEM}), so the JVM must run
 * with its working directory set to the client's own directory. And
 * {@code java.lang.foreign} is a preview API in Java 21, so a build using this class
 * needs {@code --enable-preview} at compile and run time; nothing else in this project
 * does.
 */
public final class WimClient implements AutoCloseable {

    /** The vendor library, relative to the client directory. */
    public static final String LIBRARY = "libWCL_DLL.so";

    /** Mangled name of {@code WimDiaOpen()}. */
    private static final String SYMBOL_OPEN = "_Z10WimDiaOpenv";

    /** Mangled name of {@code WimDiaWrite(char*)}. */
    private static final String SYMBOL_WRITE = "_Z11WimDiaWritePc";

    /** Mangled name of {@code WimDiaRead(char*, int, long)}. */
    private static final String SYMBOL_READ = "_Z10WimDiaReadPcil";

    /** Mangled name of {@code WimDiaClose()}. */
    private static final String SYMBOL_CLOSE = "_Z11WimDiaClosev";

    /** Size of the read buffer, the value the vendor's own API allocates. */
    private static final int READ_BUFFER = 0x2800;

    /** The arena owning the library handle and the buffers. */
    private final Arena arena = Arena.ofConfined();

    /** Where the client narrates the dialogue. */
    private final Consumer<String> log;

    /** {@code WimDiaOpen()}. */
    private final MethodHandle open;

    /** {@code WimDiaWrite(char*)}. */
    private final MethodHandle write;

    /** {@code WimDiaRead(char*, int, long)}. */
    private final MethodHandle read;

    /** {@code WimDiaClose()}. */
    private final MethodHandle closeHandle;

    /**
     * Loads the vendor library from a client directory.
     *
     * @param clientDirectory the client's own directory, holding the library and its
     *                        {@code W*} folders
     * @param log             destination of the dialogue log lines
     * @throws IOException if the library is not there or does not carry the expected
     *                     symbols
     */
    public WimClient(Path clientDirectory, Consumer<String> log) throws IOException {
        this.log = log;
        Path library = clientDirectory.resolve(LIBRARY);
        if (!Files.isReadable(library)) {
            throw new IOException("vendor library not found: " + library);
        }
        SymbolLookup lookup = SymbolLookup.libraryLookup(library, arena);
        Linker linker = Linker.nativeLinker();
        this.open = bind(linker, lookup, SYMBOL_OPEN,
                FunctionDescriptor.of(ValueLayout.JAVA_INT));
        this.write = bind(linker, lookup, SYMBOL_WRITE,
                FunctionDescriptor.of(ValueLayout.JAVA_INT, ValueLayout.ADDRESS));
        this.read = bind(linker, lookup, SYMBOL_READ,
                FunctionDescriptor.of(ValueLayout.JAVA_INT, ValueLayout.ADDRESS,
                        ValueLayout.JAVA_INT, ValueLayout.JAVA_LONG));
        this.closeHandle = bind(linker, lookup, SYMBOL_CLOSE,
                FunctionDescriptor.ofVoid());
    }

    /**
     * Binds one native function, naming the missing symbol rather than failing blankly.
     *
     * @param linker     the native linker
     * @param lookup     the loaded library
     * @param symbol     the mangled symbol name
     * @param descriptor its signature
     * @return the handle
     * @throws IOException if the library does not carry that symbol
     */
    private static MethodHandle bind(Linker linker, SymbolLookup lookup, String symbol,
            FunctionDescriptor descriptor) throws IOException {
        MemorySegment address = lookup.find(symbol)
                .orElseThrow(() -> new IOException("symbol not found in " + LIBRARY + ": " + symbol));
        return linker.downcallHandle(address, descriptor);
    }

    /**
     * Attaches to the running payment client.
     *
     * @return the library's own return code, 0 on success
     * @throws IOException if the call itself failed
     */
    public int attach() throws IOException {
        int code = call(open);
        log.accept("tpe          WimDiaOpen -> " + code);
        return code;
    }

    /**
     * Sends one message to the payment client.
     *
     * <p>Messages are tagged text: the library's own request builder inserts the
     * mandatory {@code {PS}} tag when it is missing, which is the shape of the grammar.
     *
     * @param message the message to send
     * @return the library's own return code
     * @throws IOException if the call itself failed
     */
    public int send(String message) throws IOException {
        MemorySegment buffer = arena.allocateFrom(message, StandardCharsets.ISO_8859_1);
        log.accept("tpe          > " + message);
        try {
            int code = (int) write.invokeExact(buffer);
            log.accept("tpe          WimDiaWrite -> " + code);
            return code;
        } catch (Throwable t) {
            throw new IOException("WimDiaWrite failed: " + t, t);
        }
    }

    /**
     * Reads one message from the payment client.
     *
     * @param timeoutMillis how long the library may wait
     * @return what was read, empty when nothing came
     * @throws IOException if the call itself failed
     */
    public String receive(long timeoutMillis) throws IOException {
        MemorySegment buffer = arena.allocate(READ_BUFFER);
        try {
            int code = (int) read.invokeExact(buffer, READ_BUFFER, timeoutMillis);
            String message = buffer.getString(0, StandardCharsets.ISO_8859_1);
            log.accept("tpe          WimDiaRead -> " + code
                    + (message.isEmpty() ? " (nothing)" : " : " + message));
            return message;
        } catch (Throwable t) {
            throw new IOException("WimDiaRead failed: " + t, t);
        }
    }

    /** {@inheritDoc} */
    @Override
    public void close() {
        try {
            closeHandle.invokeExact();
        } catch (Throwable t) {
            log.accept("tpe          WimDiaClose failed: " + t);
        }
        arena.close();
    }

    /**
     * Calls one no-argument function returning an int.
     *
     * @param handle the bound function
     * @return its return code
     * @throws IOException if the call failed
     */
    private static int call(MethodHandle handle) throws IOException {
        try {
            return (int) handle.invokeExact();
        } catch (Throwable t) {
            throw new IOException("native call failed: " + t, t);
        }
    }
}

package com.intermarche.pos.ui.hardware.scanner;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Unit tests for {@link HidBarcodeDecoder}: the decoding of the IBM
 * hand-held USB frames emitted by the Symbol/Zebra units, built from the
 * frames captured on the reference till.
 */
class HidBarcodeDecoderTest {

    /** Collects the emitted codes. */
    private final List<String> emitted = new ArrayList<>();

    /** The decoder under test. */
    private final HidBarcodeDecoder decoder = new HidBarcodeDecoder(emitted::add);

    /**
     * Builds a 64-byte report carrying one data frame: identifier, announced
     * length, symbology, flags, the character bytes, the terminator, then zero
     * padding.
     *
     * @param symbology the symbology byte
     * @param chars the character bytes of the code
     * @return the 64-byte report
     */
    private static byte[] frame(int symbology, int... chars) {
        byte[] r = new byte[64];
        r[0] = (byte) HidBarcodeDecoder.FRAME_ID;
        r[1] = (byte) (chars.length + 3);
        r[2] = (byte) symbology;
        r[3] = 0x00;
        for (int i = 0; i < chars.length; i++) {
            r[4 + i] = (byte) chars[i];
        }
        r[4 + chars.length] = (byte) HidBarcodeDecoder.TERMINATOR;
        return r;
    }

    /**
     * The raw digit bytes of a numeric code — one digit per byte, binary.
     *
     * @param digits the digit string
     * @return the raw bytes
     */
    private static int[] digits(String digits) {
        int[] out = new int[digits.length()];
        for (int i = 0; i < digits.length(); i++) {
            out[i] = digits.charAt(i) - '0';
        }
        return out;
    }

    /**
     * The first EAN-13 captured on the reference till decodes to its digits,
     * the zero padding after the terminator ignored.
     */
    @Test
    void decodesCapturedEan13() {
        decoder.feed(frame(0x03, digits("3178530403022")), 64);
        assertEquals(List.of("3178530403022"), emitted);
    }

    /**
     * The second captured EAN-13 decodes the same way.
     */
    @Test
    void decodesSecondCapturedEan13() {
        decoder.feed(frame(0x03, digits("3250393026256")), 64);
        assertEquals(List.of("3250393026256"), emitted);
    }

    /**
     * Two scans in a row emit separately — a frame is self-contained, no
     * state carries between reports.
     */
    @Test
    void twoFramesEmitSeparately() {
        decoder.feed(frame(0x03, digits("3178530403022")), 64);
        decoder.feed(frame(0x03, digits("3250393026256")), 64);
        assertEquals(List.of("3178530403022", "3250393026256"), emitted);
    }

    /**
     * A payload of printable ASCII is taken verbatim — the working hypothesis
     * for the non-numeric symbologies (printable-range arm).
     */
    @Test
    void decodesPrintableAsciiPayload() {
        decoder.feed(frame(0x0F, 'A', 'B', '-', '1'), 64);
        assertEquals(List.of("AB-1"), emitted);
    }

    /**
     * A report that is not a data frame (wrong identifier — the other
     * interface, or a zero report) is dropped silently.
     */
    @Test
    void nonDataFrameIsIgnored() {
        byte[] r = new byte[64];
        r[0] = 0x02;
        decoder.feed(r, 64);
        decoder.feed(new byte[64], 64);
        assertTrue(emitted.isEmpty());
    }

    /**
     * A report shorter than the header is dropped (length guard).
     */
    @Test
    void tooShortReportIsIgnored() {
        decoder.feed(new byte[]{(byte) HidBarcodeDecoder.FRAME_ID}, 1);
        assertTrue(emitted.isEmpty());
    }

    /**
     * An announced length that overruns the report is refused rather than
     * read out of bounds (incoherent-length arm).
     */
    @Test
    void announcedLengthBeyondReportIsRefused() {
        byte[] r = frame(0x03, digits("3178530403022"));
        r[1] = (byte) 0x7F;
        decoder.feed(r, 64);
        assertTrue(emitted.isEmpty());
    }

    /**
     * An announced length below the payload overhead is refused (the other
     * leg of the length guard).
     */
    @Test
    void announcedLengthBelowOverheadIsRefused() {
        byte[] r = frame(0x03, digits("3178530403022"));
        r[1] = 0x02;
        decoder.feed(r, 64);
        assertTrue(emitted.isEmpty());
    }

    /**
     * A frame whose announced payload does not end on the terminator is
     * refused — the frame is not the one this decoder understands.
     */
    @Test
    void missingTerminatorIsRefused() {
        byte[] r = frame(0x03, digits("3178530403022"));
        r[4 + 13] = 0x00;
        decoder.feed(r, 64);
        assertTrue(emitted.isEmpty());
    }

    /**
     * A character byte in neither the raw-digit nor the printable range makes
     * the whole frame undecodable: nothing is emitted, so the register never
     * receives a half-read code.
     */
    @Test
    void undecodableByteEmitsNothing() {
        decoder.feed(frame(0x0F, 0x41, 0xAB, 0x42), 64);
        assertTrue(emitted.isEmpty());
    }

    /**
     * A frame announcing only its overhead carries an empty code, which is
     * dropped rather than pushed as an empty scan.
     */
    @Test
    void emptyPayloadEmitsNothing() {
        decoder.feed(frame(0x03), 64);
        assertTrue(emitted.isEmpty());
    }
}

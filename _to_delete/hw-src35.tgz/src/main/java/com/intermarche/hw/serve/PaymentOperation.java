package com.intermarche.hw.serve;

import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;

import com.intermarche.hw.driver.PaymentSession;
import com.intermarche.hw.driver.PaymentTerminal;

/**
 * The card payment in progress, and what the POS may read about it.
 *
 * <p>A payment is not a request-and-answer: it lasts as long as the cardholder takes,
 * plus whatever maintenance the client decides to run in the middle, and it has
 * something to say throughout -- PRESENTEZ CARTE, PATIENTEZ, a progress bar. Holding an
 * HTTP request open for all that would tie a thread, force the POS to raise its client
 * timeout past the point where it can still detect a dead daemon, and throw away every
 * message the terminal sends on the way. So the payment runs here, on its own thread,
 * and the POS starts it and then reads its state.
 *
 * <p>One payment at a time, deliberately: a till has one reader, and a second request
 * arriving while one runs is a bug in the caller, not a queue to serve.
 */
public final class PaymentOperation {

    /** Where a payment stands. */
    public enum State {

        /** No payment has been asked for since the daemon started. */
        IDLE,

        /** A payment is running; the display lines say what the terminal shows. */
        RUNNING,

        /** The last payment is over; the result says how it ended. */
        DONE
    }

    /**
     * How the binding to a payment terminal is built.
     *
     * <p>It takes the display target rather than being given one: the operation is what
     * remembers the lines, so it hands itself to the terminal it creates. Building the
     * terminal is also what starts the payment client, which is why it can fail and why
     * it is redone on every new session.
     */
    @FunctionalInterface
    public interface TerminalFactory {

        /**
         * Builds a terminal reporting its display lines to the given target.
         *
         * @param display where the terminal reports what it shows
         * @return the terminal
         * @throws IOException if the payment client could not be started
         */
        PaymentTerminal open(Consumer<PaymentTerminal.Display> display) throws IOException;
    }

    /** Number of lines the terminal's display has. */
    private static final int DISPLAY_LINES = 2;

    /** The session the payments run in. */
    private final PaymentSession session;

    /** Where the operation narrates what it does. */
    private final Consumer<String> log;

    /** Runs the payment away from the request thread. */
    private final ExecutorService worker = Executors.newSingleThreadExecutor(runnable -> {
        Thread thread = new Thread(runnable, "payment");
        thread.setDaemon(true);
        return thread;
    });

    /** What the terminal shows, one entry per display line. */
    private final String[] lines = new String[DISPLAY_LINES];

    /** Where the payment stands. */
    private State state = State.IDLE;

    /** Result code of the last payment, empty until one ended. */
    private String resultCode = "";

    /** Whole answer of the last payment, empty until one ended. */
    private String answer = "";

    /** Whether the last payment was accepted. */
    private boolean approved;

    /** Why the last payment could not be run at all, empty when it ran. */
    private String failure = "";

    /**
     * Builds an operation over a way of binding a terminal, with nothing running yet and
     * no session opened: {@link #logIn()} does that.
     *
     * @param factory how a terminal is bound
     * @param log     destination of the log lines
     */
    public PaymentOperation(TerminalFactory factory, Consumer<String> log) {
        this.log = log;
        java.util.Arrays.fill(lines, "");
        this.session = new PaymentSession(() -> factory.open(this::show), log);
    }

    /**
     * Opens the payment session, so the first sale does not pay for it.
     *
     * <p>Called at start-up and expected to be slow: the login checks, and sometimes
     * updates, the reader's firmware. A failure is logged and nothing else: the daemon
     * serves its other peripherals regardless, and the session opens again by itself at
     * the first payment.
     */
    public void logIn() {
        try {
            session.login();
        } catch (IOException e) {
            log.accept("tpe          login failed: " + e.getMessage());
        }
    }

    /**
     * Starts a payment.
     *
     * @param amountCents the amount to ask for, in cents
     * @return true when the payment was started, false when one is already running
     */
    public synchronized boolean start(long amountCents) {
        if (state == State.RUNNING) {
            return false;
        }
        state = State.RUNNING;
        resultCode = "";
        answer = "";
        approved = false;
        failure = "";
        java.util.Arrays.fill(lines, "");
        worker.execute(() -> run(amountCents));
        return true;
    }

    /**
     * Records what the terminal asks to show.
     *
     * @param display the line to show
     */
    public synchronized void show(PaymentTerminal.Display display) {
        if (display.line() >= 0 && display.line() < DISPLAY_LINES) {
            lines[display.line()] = display.text();
        }
    }

    /**
     * What the POS reads about the payment, one {@code key=value} per line.
     *
     * <p>Plain text rather than JSON, because every other endpoint of this surface
     * answers plain text and the POS parses it with no library.
     *
     * @return the state, the two display lines, and the result once there is one
     */
    public synchronized String report() {
        StringBuilder text = new StringBuilder();
        text.append("state=").append(state).append('\n');
        for (int line = 0; line < DISPLAY_LINES; line++) {
            text.append("line").append(line + 1).append('=').append(lines[line]).append('\n');
        }
        text.append("result=").append(resultCode).append('\n');
        text.append("approved=").append(approved).append('\n');
        text.append("failure=").append(failure).append('\n');
        text.append("answer=").append(answer);
        return text.toString();
    }

    /**
     * Releases the session and the worker thread.
     */
    public void close() {
        worker.shutdownNow();
        session.close();
    }

    /**
     * Runs one payment and records how it ended.
     *
     * @param amountCents the amount asked for, in cents
     */
    private void run(long amountCents) {
        try {
            PaymentTerminal.Result result = session.debit(amountCents);
            finish(result.code(), result.answer(), result.approved(), "");
            log.accept("tpe          payment " + amountCents + " cents -> "
                    + (result.approved() ? "accepted" : "refused") + " (" + result.code() + ")");
        } catch (IOException e) {
            finish("", "", false, e.getMessage());
            log.accept("tpe          payment " + amountCents + " cents failed: " + e.getMessage());
        }
    }

    /**
     * Records the outcome of a payment.
     *
     * @param code      the result code, empty when the payment could not run
     * @param message   the whole answer, empty when the payment could not run
     * @param accepted  whether the payment was accepted
     * @param cause     why the payment could not run, empty when it ran
     */
    private synchronized void finish(String code, String message, boolean accepted, String cause) {
        resultCode = code;
        answer = message;
        approved = accepted;
        failure = cause;
        state = State.DONE;
    }
}

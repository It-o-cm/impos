package com.intermarche.pos.ui.invoice;

import com.intermarche.pos.domain.AccountCustomer;
import com.intermarche.pos.domain.Address;
import com.intermarche.pos.domain.Store;
import com.intermarche.pos.domain.ticket.DocumentType;
import com.intermarche.pos.domain.ticket.Invoice;
import com.intermarche.pos.domain.ticket.Ticket;
import com.intermarche.pos.domain.ticket.TicketLine;
import com.intermarche.pos.service.PosSettingsService;
import com.intermarche.pos.service.TicketNumberService;
import com.intermarche.pos.ui.PosState;
import com.intermarche.pos.ui.hardware.HardwareService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Unit tests of {@link InvoiceService}, the invoice flow.
 * <p>
 * No database and no CDI: every collaborator is a hand-written stand-in, which is what
 * the {@link InvoiceRepository} seam exists for — a service calling Panache statics
 * could not be unit-tested at all. The state is the real {@link PosState}, since the
 * flow is judged by what it leaves there.
 * <p>
 * Every guard is exercised on both arms and every leg of the compound ones: the two
 * legs of the blank-name refusal, the two of a missing ticket or customer, the three
 * shapes of a contact's name, the duplicate-versus-original fork of the issue, and
 * the training refusal.
 */
class InvoiceServiceTest {

    /** A repository that answers from lists set by each test, and records the writes. */
    private static class FakeRepository extends InvoiceRepository {

        /** The closed tickets it knows, by number. */
        private final List<Ticket> tickets = new ArrayList<>();

        /** The customers it knows. */
        private final List<AccountCustomer> customers = new ArrayList<>();

        /** The document already issued on a ticket, or null. */
        private Invoice existing;

        /** The customers it was asked to write. */
        private final List<AccountCustomer> savedCustomers = new ArrayList<>();

        /** The documents it was asked to write. */
        private final List<Invoice> savedInvoices = new ArrayList<>();

        /** The fragment of the last customer search. */
        private String lastSearch;

        /** How many times a ticket was re-read by its id. */
        private int ticketReads;

        /** How many times a customer was re-read by its id. */
        private int customerReads;

        /** {@inheritDoc} */
        @Override
        public Ticket findClosedTicket(String ticketNumber) {
            return tickets.stream()
                    .filter(ticket -> ticket.ticketNumber.equals(ticketNumber))
                    .findFirst().orElse(null);
        }

        /** {@inheritDoc} */
        @Override
        public List<Ticket> recentClosedTickets(int limit) {
            return new ArrayList<>(tickets);
        }

        /** {@inheritDoc} */
        @Override
        public List<AccountCustomer> searchCustomers(String fragment, int limit) {
            lastSearch = fragment;
            return new ArrayList<>(customers);
        }

        /** {@inheritDoc} */
        @Override
        public AccountCustomer findCustomer(Long customerId) {
            customerReads++;
            return customers.stream()
                    .filter(customer -> customerId != null && customerId.equals(customer.id))
                    .findFirst().orElse(null);
        }

        /** {@inheritDoc} */
        @Override
        public Ticket findTicket(Long ticketId) {
            ticketReads++;
            return tickets.stream()
                    .filter(ticket -> ticketId != null && ticketId.equals(ticket.id))
                    .findFirst().orElse(null);
        }

        /** {@inheritDoc} */
        @Override
        public Invoice findInvoiceOfTicket(String ticketNumber) {
            return existing;
        }

        /** {@inheritDoc} */
        @Override
        public Invoice findInvoice(Long invoiceId) {
            return existing;
        }

        /** {@inheritDoc} */
        @Override
        public void save(AccountCustomer customer) {
            savedCustomers.add(customer);
        }

        /** {@inheritDoc} */
        @Override
        public void save(Invoice invoice) {
            savedInvoices.add(invoice);
        }
    }

    /** A number service that hands out predictable numbers and counts the draws. */
    private static class FakeNumbers extends TicketNumberService {

        /** How many document numbers were drawn. */
        private int documentDraws;

        /** How many customer numbers were drawn. */
        private int customerDraws;

        /** {@inheritDoc} */
        @Override
        public String nextDocumentNumber(DocumentType type) {
            documentDraws++;
            return "C04-" + type.getPrefix() + "000001";
        }

        /** {@inheritDoc} */
        @Override
        public String nextCustomerNumber() {
            customerDraws++;
            return "C04-CLI000001";
        }

        /** {@inheritDoc} */
        @Override
        public String getTerminalId() {
            return "C04";
        }
    }

    /** Settings that always print the article code. */
    private static class FakeSettings extends PosSettingsService {

        /** {@inheritDoc} */
        @Override
        public boolean showEan() {
            return true;
        }
    }

    /** A printer that records what it was given instead of talking to a bridge. */
    private static class FakePrinter extends HardwareService {

        /** What it was asked to print. */
        private final List<String> printed = new ArrayList<>();

        /** How many times the paper was cut. */
        private int cuts;

        /** {@inheritDoc} */
        @Override
        public void printReceipt(String content) {
            printed.add(content);
        }

        /** {@inheritDoc} */
        @Override
        public void cutPaper() {
            cuts++;
        }
    }

    /** The service under test. */
    private InvoiceService service;

    /** The real register state the flow writes into. */
    private PosState state;

    /** The stand-in repository. */
    private FakeRepository repository;

    /** The stand-in number service. */
    private FakeNumbers numbers;

    /** The stand-in printer. */
    private FakePrinter printer;

    /**
     * Wires a fresh service to fresh stand-ins before each test.
     */
    @BeforeEach
    void setUp() {
        service = new InvoiceService();
        state = new PosState();
        repository = new FakeRepository();
        numbers = new FakeNumbers();
        printer = new FakePrinter();
        service.state = state;
        service.repository = repository;
        service.ticketNumberService = numbers;
        service.posSettingsService = new FakeSettings();
        service.hardwareService = printer;
    }

    /**
     * Builds a closed ticket carrying one article and a store.
     *
     * @param id     its database id
     * @param number its ticket number
     * @return the ticket
     */
    private Ticket ticket(long id, String number) {
        Store store = new Store();
        store.name = "MAGASIN";
        store.address = new Address();
        store.address.city = "LILLE";
        Ticket ticket = new Ticket();
        ticket.id = id;
        ticket.ticketNumber = number;
        ticket.store = store;
        ticket.creationDate = LocalDateTime.of(2026, 9, 9, 16, 12);
        TicketLine line = new TicketLine();
        line.productLabel = "ARTICLE";
        line.quantity = BigDecimal.ONE;
        line.unitPrice = new BigDecimal("12.00");
        line.totalPrice = new BigDecimal("12.00");
        line.vatRate = new BigDecimal("0.20");
        ticket.lines.add(line);
        return ticket;
    }

    /**
     * Builds an account customer.
     *
     * @param id   its database id
     * @param name its business name
     * @return the customer
     */
    private AccountCustomer customer(long id, String name) {
        AccountCustomer customer = new AccountCustomer();
        customer.id = id;
        customer.accountNumber = "C04-CLI000042";
        customer.companyName = name;
        customer.address = new Address();
        return customer;
    }

    /**
     * Puts the flow on its review step with a ticket and a customer.
     *
     * @return the ticket being billed
     */
    private Ticket onPreviewStep() {
        Ticket ticket = ticket(1L, "C04-00000417");
        AccountCustomer customer = customer(2L, "BOULANGERIE");
        repository.tickets.add(ticket);
        repository.customers.add(customer);
        service.chooseTicket("C04-00000417");
        service.chooseCustomer(2L);
        return ticket;
    }

    /**
     * Opening with closed tickets pre-fills the mask with the most recent one — the
     * true arm of the pre-fill guard.
     */
    @Test
    void openPreFillsTheMaskWithTheLastTicket() {
        repository.tickets.add(ticket(1L, "C04-00000417"));
        service.open();
        assertEquals("C04-00000417", state.invoice.ticketNumber);
        assertEquals(1, state.invoice.tickets.size());
        assertTrue(state.invoice.isOnTicketStep());
    }

    /**
     * Opening on a register with no closed ticket pre-fills nothing — the false arm.
     */
    @Test
    void openLeavesTheMaskEmptyWhenNothingIsClosed() {
        service.open();
        assertEquals("", state.invoice.ticketNumber);
        assertTrue(state.invoice.tickets.isEmpty());
    }

    /**
     * A ticket number that matches no closed ticket is refused, and the flow stays on
     * its first step.
     */
    @Test
    void chooseTicketRefusesAnUnknownNumber() {
        service.chooseTicket("C04-99999999");
        assertTrue(state.invoice.error.contains("TICKET INTROUVABLE"));
        assertNull(state.invoice.ticket);
        assertTrue(state.invoice.isOnTicketStep());
    }

    /**
     * A null number is read as an empty one rather than exploding — the null leg of
     * the trim guard.
     */
    @Test
    void chooseTicketReadsANullNumberAsEmpty() {
        service.chooseTicket(null);
        assertEquals("", state.invoice.ticketNumber);
        assertTrue(state.invoice.error.contains("TICKET INTROUVABLE"));
    }

    /**
     * A known closed ticket moves the flow to the customer step.
     */
    @Test
    void chooseTicketAcceptsAClosedTicket() {
        Ticket ticket = ticket(1L, "C04-00000417");
        repository.tickets.add(ticket);
        service.chooseTicket("  C04-00000417  ");
        assertEquals("", state.invoice.error);
        assertSame(ticket, state.invoice.ticket);
        assertTrue(state.invoice.isOnCustomerStep());
    }

    /**
     * A null search returns nothing without asking the repository — the null leg.
     */
    @Test
    void searchCustomersWithNullReturnsNothing() {
        service.searchCustomers(null);
        assertEquals("", state.invoice.customerSearch);
        assertTrue(state.invoice.customers.isEmpty());
        assertNull(repository.lastSearch);
    }

    /**
     * A blank search returns nothing without asking either — the blank leg.
     */
    @Test
    void searchCustomersWithBlankReturnsNothing() {
        service.searchCustomers("   ");
        assertTrue(state.invoice.customers.isEmpty());
        assertNull(repository.lastSearch);
    }

    /**
     * A real search is passed down lower-cased, and its matches are kept.
     */
    @Test
    void searchCustomersPassesTheFragmentDown() {
        repository.customers.add(customer(2L, "BOULANGERIE"));
        service.searchCustomers(" BouLan ");
        assertEquals("boulan", repository.lastSearch);
        assertEquals(1, state.invoice.customers.size());
    }

    /**
     * A customer id that matches nothing is refused and the flow stays put.
     */
    @Test
    void chooseCustomerRefusesAnUnknownId() {
        service.chooseCustomer(99L);
        assertEquals("CLIENT INTROUVABLE", state.invoice.error);
        assertNull(state.invoice.customer);
        assertFalse(state.invoice.isOnPreviewStep());
    }

    /**
     * A known customer moves the flow to the review step.
     */
    @Test
    void chooseCustomerAcceptsAKnownId() {
        AccountCustomer customer = customer(2L, "BOULANGERIE");
        repository.customers.add(customer);
        service.chooseCustomer(2L);
        assertSame(customer, state.invoice.customer);
        assertTrue(state.invoice.isOnPreviewStep());
        assertFalse(state.invoice.creatingCustomer);
    }

    /**
     * A creation with no business name at all is refused — the null leg of the guard.
     */
    @Test
    void createCustomerRefusesANullName() {
        service.createCustomer(null, "", "", "", "", "", "", "", "");
        assertEquals("RAISON SOCIALE OBLIGATOIRE", state.invoice.error);
        assertTrue(repository.savedCustomers.isEmpty());
    }

    /**
     * A creation with a blank business name is refused too — the blank leg.
     */
    @Test
    void createCustomerRefusesABlankName() {
        service.createCustomer("   ", "", "", "", "", "", "", "", "");
        assertEquals("RAISON SOCIALE OBLIGATOIRE", state.invoice.error);
        assertTrue(repository.savedCustomers.isEmpty());
    }

    /**
     * A full creation writes the customer, draws its account number and moves the flow
     * on; a two-word contact splits into a first and a last name.
     */
    @Test
    void createCustomerWritesAFullCustomer() {
        service.createCustomer("BOULANGERIE", "Marc VIDAL", "3 place", "92420", "VAUCRESSON",
                "SIRET", "FR1", "0102", "a@b.c");
        assertEquals(1, repository.savedCustomers.size());
        AccountCustomer created = repository.savedCustomers.get(0);
        assertEquals("C04-CLI000001", created.accountNumber);
        assertEquals(1, numbers.customerDraws);
        assertEquals(0, numbers.documentDraws);
        assertEquals("BOULANGERIE", created.companyName);
        assertEquals("Marc", created.firstName);
        assertEquals("VIDAL", created.lastName);
        assertEquals("3 place", created.address.streetLine1);
        assertEquals("92420", created.address.postalCode);
        assertEquals("VAUCRESSON", created.address.city);
        assertEquals("SIRET", created.siret);
        assertEquals("FR1", created.vatNumber);
        assertTrue(state.invoice.isOnPreviewStep());
    }

    /**
     * A one-word contact becomes the last name alone, and every blank optional field
     * is stored as missing rather than as an empty string.
     */
    @Test
    void createCustomerHandlesAOneWordContactAndBlankOptionals() {
        service.createCustomer("BOULANGERIE", "VIDAL", "", "  ", "", null, "", "", "");
        AccountCustomer created = repository.savedCustomers.get(0);
        assertEquals("", created.firstName);
        assertEquals("VIDAL", created.lastName);
        assertNull(created.address.streetLine1);
        assertNull(created.address.postalCode);
        assertNull(created.siret);
        assertNull(created.vatNumber);
        assertNull(created.phone);
        assertNull(created.email);
    }

    /**
     * A creation with no contact at all leaves both name parts empty.
     */
    @Test
    void createCustomerHandlesAMissingContact() {
        service.createCustomer("BOULANGERIE", null, "", "", "", "", "", "", "");
        AccountCustomer created = repository.savedCustomers.get(0);
        assertEquals("", created.firstName);
        assertEquals("", created.lastName);
    }

    /**
     * There is nothing to preview before a ticket is named.
     */
    @Test
    void previewIsEmptyWithoutATicket() {
        assertNull(service.preview());
    }

    /**
     * There is nothing to preview before a customer is named either — the second leg
     * of that guard.
     */
    @Test
    void previewIsEmptyWithoutACustomer() {
        repository.tickets.add(ticket(1L, "C04-00000417"));
        service.chooseTicket("C04-00000417");
        assertNull(service.preview());
    }

    /**
     * The preview lays the document out WITHOUT drawing a number or writing anything —
     * which is what makes the abandon free.
     */
    @Test
    void previewDrawsNoNumberAndWritesNothing() {
        onPreviewStep();
        InvoiceDocument document = service.preview();
        assertEquals("", document.number);
        assertEquals("FACTURE", document.title);
        assertEquals("C04-00000417", document.ticketNumber);
        assertEquals(0, numbers.documentDraws);
        assertTrue(repository.savedInvoices.isEmpty());
        assertTrue(printer.printed.isEmpty());
    }

    /**
     * The preview RE-READS the ticket and the customer instead of using the instances
     * the screen has been carrying since the earlier steps.
     * <p>
     * Those instances were loaded by a previous request and their Hibernate session is
     * closed, so reading the ticket's lines off them fails. This test does not prove
     * the detachment — a stand-in repository hands back the same objects — it proves
     * the RE-READ, which is the thing that must not be removed by a later
     * simplification.
     */
    @Test
    void previewRereadsTheTicketAndTheCustomer() {
        onPreviewStep();
        int ticketReadsBefore = repository.ticketReads;
        int customerReadsBefore = repository.customerReads;
        service.preview();
        assertEquals(ticketReadsBefore + 1, repository.ticketReads);
        assertEquals(customerReadsBefore + 1, repository.customerReads);
    }

    /**
     * A preview whose ticket has vanished between two steps lays out nothing rather
     * than failing — the ticket leg of the re-read guard.
     */
    @Test
    void previewIsEmptyWhenTheTicketVanished() {
        onPreviewStep();
        repository.tickets.clear();
        assertNull(service.preview());
    }

    /**
     * A preview whose customer has vanished lays out nothing either — the customer leg.
     */
    @Test
    void previewIsEmptyWhenTheCustomerVanished() {
        onPreviewStep();
        repository.customers.clear();
        assertNull(service.preview());
    }

    /**
     * Issuing without a ticket is refused and draws no number.
     */
    @Test
    void issueRefusesWithoutATicket() {
        assertNull(service.issue());
        assertEquals("TICKET OU CLIENT MANQUANT", state.invoice.error);
        assertEquals(0, numbers.documentDraws);
    }

    /**
     * Issuing without a customer is refused too — the second leg of that guard.
     */
    @Test
    void issueRefusesWithoutACustomer() {
        repository.tickets.add(ticket(1L, "C04-00000417"));
        service.chooseTicket("C04-00000417");
        assertNull(service.issue());
        assertEquals("TICKET OU CLIENT MANQUANT", state.invoice.error);
    }

    /**
     * Training mode issues nothing: a document is a real fiscal object and a training
     * gesture must neither produce one nor consume a number.
     */
    @Test
    void issueIsRefusedInTraining() {
        onPreviewStep();
        state.trainingMode = true;
        assertNull(service.issue());
        assertEquals("FACTURE INDISPONIBLE EN FORMATION", state.invoice.error);
        assertEquals(0, numbers.documentDraws);
        assertTrue(repository.savedInvoices.isEmpty());
    }

    /**
     * The first issue draws a number, writes the document, prints it as an original
     * and cuts the paper.
     */
    @Test
    void issueWritesAndPrintsTheOriginal() {
        onPreviewStep();
        service.issue();
        assertEquals(1, numbers.documentDraws);
        assertEquals(1, repository.savedInvoices.size());
        Invoice document = repository.savedInvoices.get(0);
        assertEquals("C04-F000001", document.documentNumber);
        assertEquals("C04", document.terminalId);
        assertEquals("C04-00000417", document.ticketNumber);
        assertEquals("BOULANGERIE", document.customerName);
        assertEquals(1, document.printCount);
        assertEquals(0, new BigDecimal("12.00").compareTo(document.totalIncludingTax));
        assertEquals(0, new BigDecimal("10.00").compareTo(document.totalExcludingTax));
        assertEquals(1, printer.printed.size());
        assertEquals(1, printer.cuts);
        assertFalse(printer.printed.get(0).contains("DUPLICATA"));
        assertEquals(document.id, state.invoice.issuedInvoiceId);
    }

    /**
     * A second issue on the same ticket produces a DUPLICATE, never a second original:
     * no new number is drawn and the print carries the duplicate mark.
     */
    @Test
    void issueOnAnAlreadyBilledTicketPrintsADuplicate() {
        Ticket ticket = onPreviewStep();
        Invoice already = new Invoice();
        already.documentNumber = "C04-F000001";
        already.documentType = DocumentType.FACTURE;
        already.terminalId = "C04";
        already.issueDate = LocalDateTime.of(2026, 9, 9, 16, 42);
        already.ticketNumber = ticket.ticketNumber;
        already.addressTo(customer(2L, "BOULANGERIE"));
        already.totalExcludingTax = new BigDecimal("10.00");
        already.totalVat = new BigDecimal("2.00");
        already.totalIncludingTax = new BigDecimal("12.00");
        already.printCount = 1;
        repository.existing = already;

        service.issue();

        assertEquals(0, numbers.documentDraws);
        assertEquals(2, already.printCount);
        assertSame(already, repository.savedInvoices.get(0));
        assertTrue(printer.printed.get(0).contains("DUPLICATA N°1"));
    }

    /**
     * An issued document can be laid out again from its id.
     */
    @Test
    void issuedLaysOutAnAlreadyIssuedDocument() {
        Ticket ticket = ticket(1L, "C04-00000417");
        repository.tickets.add(ticket);
        Invoice already = new Invoice();
        already.documentNumber = "C04-F000001";
        already.documentType = DocumentType.FACTURE;
        already.terminalId = "C04";
        already.issueDate = LocalDateTime.of(2026, 9, 9, 16, 42);
        already.ticketNumber = ticket.ticketNumber;
        already.addressTo(customer(2L, "BOULANGERIE"));
        already.totalExcludingTax = new BigDecimal("10.00");
        already.totalVat = new BigDecimal("2.00");
        already.totalIncludingTax = new BigDecimal("12.00");
        repository.existing = already;

        InvoiceDocument document = service.issued(7L);
        assertEquals("C04-F000001", document.number);
        assertEquals("BOULANGERIE", document.customer.name());
    }

    /**
     * An id that matches no document lays out nothing.
     */
    @Test
    void issuedIsEmptyForAnUnknownDocument() {
        assertNull(service.issued(7L));
    }

    /**
     * A document whose ticket has vanished lays out nothing either — the second leg
     * of that guard.
     */
    @Test
    void issuedIsEmptyWhenTheTicketIsGone() {
        Invoice already = new Invoice();
        already.ticketNumber = "C04-00000417";
        repository.existing = already;
        assertNull(service.issued(7L));
    }

    /**
     * Giving up leaves nothing of the document behind, and nothing to undo: nothing
     * was ever written.
     */
    @Test
    void abandonClearsEverything() {
        onPreviewStep();
        service.abandon();
        assertTrue(state.invoice.isOnTicketStep());
        assertNull(state.invoice.ticket);
        assertNull(state.invoice.customer);
        assertTrue(repository.savedInvoices.isEmpty());
        assertEquals(0, numbers.documentDraws);
    }
}

package com.intermarche.pos.service.sync;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.intermarche.pos.domain.CashMovement;
import com.intermarche.pos.domain.CashSession;
import com.intermarche.pos.domain.SyncOutbox;
import com.intermarche.pos.domain.ticket.CashPayment;
import com.intermarche.pos.domain.ticket.Refund;
import com.intermarche.pos.domain.ticket.RefundLine;
import com.intermarche.pos.domain.ticket.TechnicalEvent;
import com.intermarche.pos.domain.ticket.Ticket;
import com.intermarche.pos.domain.ticket.TicketLine;
import com.intermarche.pos.domain.ticket.TicketPayment;
import com.intermarche.pos.domain.ticket.VoucherPayment;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.jboss.logging.Logger;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

/**
 * Transactional half of the store synchronization: enqueues outbox rows in
 * the caller's transaction, prepares the JSON payload of an outbox item
 * (loading the entity graph inside a transaction) and records each push
 * outcome. The HTTP half lives in {@link SyncPushService}.
 * <p>
 * Two patterns worth naming. Enqueueing joins the CALLER'S transaction: the
 * outbox row commits or rolls back with the business event itself, which is
 * the whole no-loss guarantee — there is no window where a ticket exists
 * without its outbox row. And {@code prepare} serializes the entity graph
 * to JSON INSIDE a transaction precisely so the push loop never touches a
 * lazy entity outside one: a transaction is never held across network I/O,
 * the HTTP push works on a detached string.
 */
@ApplicationScoped
public class SyncOutboxService {

    private static final Logger LOG = Logger.getLogger(SyncOutboxService.class);

    /** URL of the store node; absent = synchronization disabled. */
    @ConfigProperty(name = "pos.sync.store-url")
    Optional<String> storeUrl;

    @Inject
    ObjectMapper objectMapper;

    /**
     * A payload ready to push: the target path suffix and the JSON body.
     */
    public static class PreparedItem {
        /** The store-node path suffix (e.g. "ticket"). */
        public final String pathSuffix;
        /** The serialized JSON body. */
        public final String json;

        /**
         * Creates a prepared item.
         *
         * @param pathSuffix the store-node path suffix
         * @param json the serialized JSON body
         */
        public PreparedItem(String pathSuffix, String json) {
            this.pathSuffix = pathSuffix;
            this.json = json;
        }
    }

    /**
     * Indicates whether the synchronization is enabled on this node.
     *
     * @return true when a store URL is configured
     */
    public boolean isEnabled() {
        return storeUrl.isPresent() && !storeUrl.get().isBlank();
    }

    /**
     * Returns the configured store node URL without a trailing slash.
     *
     * @return the store URL, or an empty string when disabled
     */
    public String getStoreUrl() {
        if (!isEnabled()) return "";
        String url = storeUrl.get().trim();
        return url.endsWith("/") ? url.substring(0, url.length() - 1) : url;
    }

    /**
     * Enqueues an entity for synchronization, joining the caller's
     * transaction; no-op when the synchronization is disabled.
     *
     * @param type the entity kind
     * @param entityId the local database id of the entity
     */
    @Transactional
    public void enqueue(SyncOutbox.EntityType type, Long entityId) {
        if (!isEnabled() || entityId == null) return;
        SyncOutbox row = new SyncOutbox();
        row.entityType = type;
        row.entityId = entityId;
        row.createdAt = LocalDateTime.now();
        row.persist();
    }

    /**
     * Returns the next batch of outbox rows in drain order (sessions, then
     * tickets, then refunds; oldest first within a kind).
     *
     * @param batchSize the maximum number of rows
     * @return the ids of the rows to process
     */
    @Transactional
    public List<Long> nextBatchIds(int batchSize) {
        return SyncOutbox.<SyncOutbox>find("order by entityType, id")
                .page(0, batchSize)
                .list()
                .stream().map(row -> row.id).toList();
    }

    /**
     * Prepares the payload of an outbox row, loading the entity graph inside
     * the transaction.
     *
     * @param outboxId the outbox row id
     * @return the prepared item, or null when the row or its entity vanished
     */
    @Transactional
    public PreparedItem prepare(Long outboxId) {
        SyncOutbox row = SyncOutbox.findById(outboxId);
        if (row == null) return null;
        try {
            return switch (row.entityType) {
                case SESSION -> {
                    CashSession session = CashSession.findById(row.entityId);
                    yield session == null ? null
                            : new PreparedItem("session", objectMapper.writeValueAsString(toDto(session)));
                }
                case MOVEMENT -> {
                    CashMovement movement = CashMovement.findById(row.entityId);
                    yield movement == null ? null
                            : new PreparedItem("movement", objectMapper.writeValueAsString(toDto(movement)));
                }
                case TICKET -> {
                    Ticket ticket = Ticket.findById(row.entityId);
                    yield ticket == null ? null
                            : new PreparedItem("ticket", objectMapper.writeValueAsString(toDto(ticket)));
                }
                case REFUND -> {
                    Refund refund = Refund.findById(row.entityId);
                    yield refund == null ? null
                            : new PreparedItem("refund", objectMapper.writeValueAsString(toDto(refund)));
                }
                case EVENT -> {
                    TechnicalEvent event = TechnicalEvent.findById(row.entityId);
                    yield event == null ? null
                            : new PreparedItem("event", objectMapper.writeValueAsString(toDto(event)));
                }
            };
        } catch (Exception e) {
            LOG.errorf("Préparation sync impossible (outbox %d): %s", outboxId, e.getMessage());
            return null;
        }
    }

    /**
     * Deletes an acknowledged outbox row.
     *
     * @param outboxId the outbox row id
     */
    @Transactional
    public void markSuccess(Long outboxId) {
        SyncOutbox.deleteById(outboxId);
    }

    /**
     * Records a failed push attempt on an outbox row.
     *
     * @param outboxId the outbox row id
     * @param error a short error description
     */
    @Transactional
    public void markFailure(Long outboxId, String error) {
        SyncOutbox row = SyncOutbox.findById(outboxId);
        if (row == null) return;
        row.attempts++;
        row.lastError = error != null && error.length() > 255 ? error.substring(0, 255) : error;
        row.persist();
    }

    /**
     * Deletes an outbox row whose entity vanished (nothing left to push).
     *
     * @param outboxId the outbox row id
     */
    @Transactional
    public void markGone(Long outboxId) {
        SyncOutbox.deleteById(outboxId);
    }

    // --------------------------------------------------
    // Entity to DTO mapping (natural keys only)
    // --------------------------------------------------

    /**
     * Maps a cash session to its payload.
     *
     * @param session the session entity
     * @return the payload
     */
    private SyncPayloads.SessionDto toDto(CashSession session) {
        SyncPayloads.SessionDto dto = new SyncPayloads.SessionDto();
        dto.sessionNumber = session.sessionNumber;
        dto.terminalId = session.terminalId;
        dto.status = session.status.name();
        dto.openingDate = iso(session.openingDate);
        dto.closingDate = iso(session.closingDate);
        dto.openingCashierLogin = session.openingCashier != null ? session.openingCashier.loginName : null;
        dto.closingCashierLogin = session.closingCashier != null ? session.closingCashier.loginName : null;
        dto.openingFloat = session.openingFloat;
        dto.countedAmount = session.countedAmount;
        dto.theoreticalAmount = session.theoreticalAmount;
        dto.variance = session.variance;
        dto.withdrawnAmount = session.withdrawnAmount;
        dto.countDetail = session.countDetail;
        return dto;
    }

    /**
     * Maps a cash movement to its payload; session and cashier are referenced
     * by natural key.
     *
     * @param movement the movement entity
     * @return the payload
     */
    private SyncPayloads.MovementDto toDto(CashMovement movement) {
        SyncPayloads.MovementDto dto = new SyncPayloads.MovementDto();
        dto.movementUid = movement.movementUid;
        dto.terminalId = movement.terminalId;
        dto.sessionNumber = movement.session != null ? movement.session.sessionNumber : null;
        dto.cashierLogin = movement.cashier != null ? movement.cashier.loginName : null;
        dto.type = movement.type.name();
        dto.amount = movement.amount;
        dto.reason = movement.reason;
        dto.movementDate = iso(movement.movementDate);
        dto.endorsedBy = movement.endorsedBy;
        return dto;
    }

    /**
     * Maps a ticket and its graph to its payload.
     *
     * @param ticket the ticket entity
     * @return the payload
     */
    private SyncPayloads.TicketDto toDto(Ticket ticket) {
        SyncPayloads.TicketDto dto = new SyncPayloads.TicketDto();
        dto.ticketNumber = ticket.ticketNumber;
        dto.terminalId = ticket.terminalId;
        dto.status = ticket.status.name();
        dto.creationDate = iso(ticket.creationDate);
        dto.closingDate = iso(ticket.closingDate);
        dto.storeCode = ticket.store != null ? ticket.store.code : null;
        dto.cashierLogin = ticket.cashier != null ? ticket.cashier.loginName : null;
        dto.sessionNumber = ticket.session != null ? ticket.session.sessionNumber : null;
        dto.fidelityCard = ticket.fidelityCard;
        dto.digitalKey = ticket.digitalKey;
        dto.customerEmail = ticket.customerEmail;
        dto.itemCount = ticket.itemCount;
        dto.totalExcludingTax = ticket.totalExcludingTax;
        dto.totalIncludingTax = ticket.totalIncludingTax;
        dto.totalVat = ticket.totalVat;
        dto.signature = ticket.signature;
        dto.previousSignature = ticket.previousSignature;
        dto.grandTotal = ticket.grandTotal;
        dto.valuationStatus = ticket.valuationStatus.name();
        for (TicketLine line : ticket.lines) {
            SyncPayloads.LineDto lineDto = new SyncPayloads.LineDto();
            lineDto.lineNumber = line.lineNumber;
            lineDto.lineUid = line.lineUid;
            lineDto.ean = line.ean;
            lineDto.plu = line.plu;
            lineDto.productLabel = line.productLabel;
            lineDto.quantity = line.quantity;
            lineDto.unitPrice = line.unitPrice;
            lineDto.vatRate = line.vatRate;
            lineDto.modifierLabel = line.modifierLabel;
            lineDto.modifierType = line.modifierType;
            lineDto.modifierValue = line.modifierValue;
            lineDto.originalUnitPrice = line.originalUnitPrice;
            lineDto.totalPrice = line.totalPrice;
            lineDto.deposit = line.deposit;
            lineDto.familyCode = line.familyCode;
            lineDto.familyLabel = line.familyLabel;
            // Article-cancellation witness (lot C4, BO-04-01-16): a cancelled
            // line IS carried to the consolidated node, marked, so the journal
            // can search for tickets bearing an annulation article.
            lineDto.cancelled = line.cancelled;
            lineDto.cancellationDate = iso(line.cancellationDate);
            lineDto.cancelledBy = line.cancelledBy;
            dto.lines.add(lineDto);
        }
        for (TicketPayment payment : ticket.payments) {
            SyncPayloads.PaymentDto paymentDto = new SyncPayloads.PaymentDto();
            paymentDto.paymentIndex = payment.paymentIndex;
            paymentDto.methodKey = payment.getMethodKey();
            paymentDto.amount = payment.amount;
            if (payment instanceof CashPayment cash) {
                paymentDto.tenderedAmount = cash.tenderedAmount;
            }
            if (payment instanceof VoucherPayment voucher) {
                paymentDto.voucherLabel = voucher.voucherLabel;
                paymentDto.voucherNumber = voucher.voucherNumber;
            }
            if (payment instanceof com.intermarche.pos.domain.ticket.CardPayment card) {
                paymentDto.authorizationNumber = card.authorizationNumber;
                paymentDto.degradedMode = card.degradedMode;
            }
            dto.payments.add(paymentDto);
        }
        return dto;
    }

    /**
     * Maps a refund and its lines to its payload; original lines are
     * referenced by their stable uid.
     *
     * @param refund the refund entity
     * @return the payload
     */
    private SyncPayloads.RefundDto toDto(Refund refund) {
        SyncPayloads.RefundDto dto = new SyncPayloads.RefundDto();
        dto.refundNumber = refund.refundNumber;
        dto.terminalId = refund.terminalId;
        dto.status = refund.status.name();
        dto.refundMethod = refund.refundMethod != null ? refund.refundMethod.name() : null;
        Ticket original = Ticket.findById(refund.originalTicketId);
        dto.originalTicketNumber = original != null ? original.ticketNumber : null;
        dto.sessionNumber = refund.session != null ? refund.session.sessionNumber : null;
        dto.creationDate = iso(refund.creationDate);
        dto.totalAmount = refund.totalAmount;
        dto.totalExcludingTax = refund.totalExcludingTax;
        dto.totalVat = refund.totalVat;
        for (RefundLine line : refund.lines) {
            SyncPayloads.RefundLineDto lineDto = new SyncPayloads.RefundLineDto();
            TicketLine originalLine = TicketLine.findById(line.originalLineId);
            lineDto.originalLineUid = originalLine != null ? originalLine.lineUid : null;
            lineDto.productLabel = line.productLabel;
            lineDto.quantity = line.quantity;
            lineDto.price = line.price;
            lineDto.vatRate = line.vatRate;
            dto.lines.add(lineDto);
        }
        return dto;
    }

    /**
     * Maps a technical journal event to its payload.
     *
     * @param event the event entity
     * @return the payload
     */
    private SyncPayloads.EventDto toDto(TechnicalEvent event) {
        SyncPayloads.EventDto dto = new SyncPayloads.EventDto();
        dto.eventUid = event.eventUid;
        dto.terminalId = event.terminalId;
        dto.type = event.eventType.name();
        dto.detail = event.detail;
        dto.operatorBadgeId = event.operatorBadgeId;
        dto.eventDate = iso(event.eventDate);
        return dto;
    }

    /**
     * Formats a timestamp as ISO-8601, tolerating null.
     *
     * @param dateTime the timestamp, or null
     * @return the ISO string, or null
     */
    private String iso(LocalDateTime dateTime) {
        return dateTime != null ? dateTime.format(DateTimeFormatter.ISO_LOCAL_DATE_TIME) : null;
    }
}

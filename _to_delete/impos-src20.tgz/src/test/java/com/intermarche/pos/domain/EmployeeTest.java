package com.intermarche.pos.domain;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import io.quarkus.hibernate.orm.panache.PanacheQuery;
import java.time.LocalDateTime;
import java.util.Objects;
import java.util.Set;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.when;

/**
 * Unit tests for {@link Employee}, targeting 100% branch coverage.
 * <p>
 * The branching methods are {@code isCurrentlyLocked} (the {@code lockedUntil}
 * null guard combined with the {@code isAfter} check), {@code getRoles} (the
 * {@code role} null guard) and {@code verifyPassword} (the two-operand null
 * guard). {@code findLogin} and {@code findActiveLogin} resolve the Panache
 * static finder, which under plain {@code mvn test} falls back to
 * {@link PanacheEntityBase}, so they are intercepted with
 * {@link org.mockito.Mockito#mockStatic}. {@code hashPassword} and the passing
 * arm of {@code verifyPassword} exercise the real BCrypt round-trip. The
 * remaining accessors, {@code present} and {@code getChecksum} are exercised for
 * line coverage. Every test is fully isolated and asserts absolute expected
 * values.
 */
class EmployeeTest {

    /**
     * Builds a mocked {@link PanacheQuery} whose {@code firstResult()} yields the
     * given employee, mirroring the finder's terminal call.
     *
     * @param employee the employee to return, or null for none
     * @return the mocked query
     */
    @SuppressWarnings("unchecked")
    private PanacheQuery<Employee> query(Employee employee) {
        PanacheQuery<Employee> query = mock(PanacheQuery.class);
        when(query.firstResult()).thenReturn(employee);
        return query;
    }

    /**
     * A fresh employee is active by default and has zero failed attempts via the
     * field initializers.
     */
    @Test
    void defaultsAreActiveAndUnlocked() {
        Employee employee = new Employee();
        Assertions.assertTrue(employee.active);
        Assertions.assertEquals(0, employee.failedAttempts);
        Assertions.assertNull(employee.lockedUntil);
    }

    /**
     * isCurrentlyLocked returns false when lockedUntil is null (first operand
     * false arm).
     */
    @Test
    void isCurrentlyLockedNullReturnsFalse() {
        Employee employee = new Employee();
        employee.lockedUntil = null;
        Assertions.assertFalse(employee.isCurrentlyLocked());
    }

    /**
     * isCurrentlyLocked returns true when lockedUntil is in the future (both
     * operands true).
     */
    @Test
    void isCurrentlyLockedFutureReturnsTrue() {
        Employee employee = new Employee();
        employee.lockedUntil = LocalDateTime.now().plusHours(1);
        Assertions.assertTrue(employee.isCurrentlyLocked());
    }

    /**
     * isCurrentlyLocked returns false when lockedUntil is in the past (first
     * operand true, second false).
     */
    @Test
    void isCurrentlyLockedPastReturnsFalse() {
        Employee employee = new Employee();
        employee.lockedUntil = LocalDateTime.now().minusHours(1);
        Assertions.assertFalse(employee.isCurrentlyLocked());
    }

    /**
     * getLoginName returns the loginName field.
     */
    @Test
    void getLoginNameReturnsLoginName() {
        Employee employee = new Employee();
        employee.loginName = "jdoe";
        Assertions.assertEquals("jdoe", employee.getLoginName());
    }

    /**
     * getPassword returns the password hash field.
     */
    @Test
    void getPasswordReturnsPassword() {
        Employee employee = new Employee();
        employee.password = "hash";
        Assertions.assertEquals("hash", employee.getPassword());
    }

    /**
     * getRoles returns an empty set when role is null (null-guard true arm).
     */
    @Test
    void getRolesNullReturnsEmptySet() {
        Employee employee = new Employee();
        employee.role = null;
        Assertions.assertEquals(Set.of(), employee.getRoles());
    }

    /**
     * getRoles returns the singleton role name when role is set (null-guard false
     * arm).
     */
    @Test
    void getRolesNonNullReturnsSingletonName() {
        Employee employee = new Employee();
        employee.role = Employee.EmployeeRole.CASHIER;
        Assertions.assertEquals(Set.of("CASHIER"), employee.getRoles());
    }

    /**
     * isEnabled mirrors the active flag when active.
     */
    @Test
    void isEnabledTrueWhenActive() {
        Employee employee = new Employee();
        employee.active = true;
        Assertions.assertTrue(employee.isEnabled());
    }

    /**
     * isEnabled mirrors the active flag when inactive.
     */
    @Test
    void isEnabledFalseWhenInactive() {
        Employee employee = new Employee();
        employee.active = false;
        Assertions.assertFalse(employee.isEnabled());
    }

    /**
     * getSubjectId returns the string form of the entity id.
     */
    @Test
    void getSubjectIdReturnsIdAsString() {
        Employee employee = new Employee();
        employee.id = 42L;
        Assertions.assertEquals("42", employee.getSubjectId());
    }

    /**
     * getFullName concatenates first and last name with a single space.
     */
    @Test
    void getFullNameConcatenatesNames() {
        Employee employee = new Employee();
        employee.firstName = "Jane";
        employee.lastName = "Doe";
        Assertions.assertEquals("Jane Doe", employee.getFullName());
    }

    /**
     * getEmail returns the email field.
     */
    @Test
    void getEmailReturnsEmail() {
        Employee employee = new Employee();
        employee.email = "jane@example.com";
        Assertions.assertEquals("jane@example.com", employee.getEmail());
    }

    /**
     * setPassword replaces the stored password hash.
     */
    @Test
    void setPasswordUpdatesPassword() {
        Employee employee = new Employee();
        employee.setPassword("newHash");
        Assertions.assertEquals("newHash", employee.password);
    }

    /**
     * present formats the badge, full name and email into the descriptive string.
     */
    @Test
    void presentFormatsDescriptiveString() {
        Employee employee = new Employee();
        employee.badgeId = "B01";
        employee.firstName = "Jane";
        employee.lastName = "Doe";
        employee.email = "jane@example.com";
        Assertions.assertEquals("Employee[B01] Jane Doe (jane@example.com)", employee.present());
    }

    /**
     * hashPassword produces a BCrypt hash that verifyPassword accepts, exercising
     * the passing arm of the real BCrypt round-trip.
     */
    @Test
    void hashPasswordRoundTripsWithVerifyPassword() {
        Employee employee = new Employee();
        employee.password = Employee.hashPassword("1234");
        Assertions.assertTrue(employee.verifyPassword("1234"));
    }

    /**
     * verifyPassword returns false for a raw PIN that does not match the stored
     * hash (BCrypt.checkpw false arm).
     */
    @Test
    void verifyPasswordWrongPinReturnsFalse() {
        Employee employee = new Employee();
        employee.password = Employee.hashPassword("1234");
        Assertions.assertFalse(employee.verifyPassword("9999"));
    }

    /**
     * verifyPassword returns false when the stored hash is null (first operand
     * true arm, short-circuit).
     */
    @Test
    void verifyPasswordNullHashReturnsFalse() {
        Employee employee = new Employee();
        employee.password = null;
        Assertions.assertFalse(employee.verifyPassword("1234"));
    }

    /**
     * verifyPassword returns false when the raw PIN is null (first operand false,
     * second operand true arm).
     */
    @Test
    void verifyPasswordNullRawReturnsFalse() {
        Employee employee = new Employee();
        employee.password = "hash";
        Assertions.assertFalse(employee.verifyPassword(null));
    }

    /**
     * findLogin returns the query's first result when an account matches the badge
     * or login name.
     */
    @Test
    void findLoginReturnsMatch() {
        Employee found = new Employee();
        PanacheQuery<Employee> query = query(found);
        try (MockedStatic<PanacheEntityBase> mocked = mockStatic(PanacheEntityBase.class)) {
            mocked.when(() -> Employee.find("badgeId = ?1 or loginName = ?1", "B01")).thenReturn(query);
            Assertions.assertSame(found, Employee.findLogin("B01"));
        }
    }

    /**
     * findLogin returns null when no account matches.
     */
    @Test
    void findLoginReturnsNullWhenNoMatch() {
        PanacheQuery<Employee> query = query(null);
        try (MockedStatic<PanacheEntityBase> mocked = mockStatic(PanacheEntityBase.class)) {
            mocked.when(() -> Employee.find("badgeId = ?1 or loginName = ?1", "B99")).thenReturn(query);
            Assertions.assertNull(Employee.findLogin("B99"));
        }
    }

    /**
     * findActiveLogin returns the query's first result when an active account
     * matches.
     */
    @Test
    void findActiveLoginReturnsMatch() {
        Employee found = new Employee();
        PanacheQuery<Employee> query = query(found);
        try (MockedStatic<PanacheEntityBase> mocked = mockStatic(PanacheEntityBase.class)) {
            mocked.when(() -> Employee.find("(badgeId = ?1 or loginName = ?1) and active = true", "B01"))
                    .thenReturn(query);
            Assertions.assertSame(found, Employee.findActiveLogin("B01"));
        }
    }

    /**
     * findActiveLogin returns null when no active account matches.
     */
    @Test
    void findActiveLoginReturnsNullWhenNoMatch() {
        PanacheQuery<Employee> query = query(null);
        try (MockedStatic<PanacheEntityBase> mocked = mockStatic(PanacheEntityBase.class)) {
            mocked.when(() -> Employee.find("(badgeId = ?1 or loginName = ?1) and active = true", "B99"))
                    .thenReturn(query);
            Assertions.assertNull(Employee.findActiveLogin("B99"));
        }
    }

    /**
     * getChecksum returns the Objects.hash of the seven business fields.
     */
    @Test
    void getChecksumMatchesObjectsHash() {
        Employee employee = new Employee();
        employee.firstName = "Jane";
        employee.lastName = "Doe";
        employee.password = "hash";
        employee.role = Employee.EmployeeRole.MANAGER;
        employee.badgeId = "B01";
        employee.active = true;
        employee.email = "jane@example.com";
        int expected = Objects.hash("Jane", "Doe", "hash", Employee.EmployeeRole.MANAGER, "B01", true,
                "jane@example.com");
        Assertions.assertEquals(expected, employee.getChecksum());
    }

    /**
     * The EmployeeRole enum exposes exactly its four declared constants and
     * round-trips through valueOf.
     */
    @Test
    void employeeRoleEnumHasFourConstants() {
        Assertions.assertEquals(4, Employee.EmployeeRole.values().length);
        Assertions.assertEquals(Employee.EmployeeRole.ADMIN, Employee.EmployeeRole.valueOf("ADMIN"));
        Assertions.assertEquals(Employee.EmployeeRole.MANAGER, Employee.EmployeeRole.valueOf("MANAGER"));
        Assertions.assertEquals(Employee.EmployeeRole.PICKER, Employee.EmployeeRole.valueOf("PICKER"));
        Assertions.assertEquals(Employee.EmployeeRole.CASHIER, Employee.EmployeeRole.valueOf("CASHIER"));
    }
}

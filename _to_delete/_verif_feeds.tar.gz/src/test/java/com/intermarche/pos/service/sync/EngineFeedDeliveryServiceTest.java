package com.intermarche.pos.service.sync;

import com.intermarche.pos.domain.EngineFeed;
import com.sun.net.httpserver.HttpServer;
import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;

import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

/**
 * Unit tests for {@link EngineFeedDeliveryService}: the catalog walk (skip
 * of absent and acknowledged feeds), the ACK on a 2xx answer, the
 * stop-at-first-failure discipline that preserves the application order,
 * and the Basic-auth header. The engine is a real local {@code HttpServer}
 * (pure JDK) so the HTTP path is exercised for real; the entity statics
 * are intercepted with {@code mockStatic} and the recorders are a mocked
 * {@link EngineFeedService}.
 */
class EngineFeedDeliveryServiceTest {

    /** The service under test. */
    private EngineFeedDeliveryService service;

    /** The mocked feed keeper receiving the acknowledgements. */
    private EngineFeedService engineFeedService;

    /** The local fake engine. */
    private HttpServer server;

    /** Status the fake engine answers per path. */
    private final Map<String, Integer> statusByPath = new ConcurrentHashMap<>();

    /** Bodies received by the fake engine per path. */
    private final Map<String, String> bodyByPath = new ConcurrentHashMap<>();

    /** Authorization headers received per path. */
    private final Map<String, String> authByPath = new ConcurrentHashMap<>();

    /**
     * Starts the fake engine and wires a fresh service on it.
     *
     * @throws Exception when the local server cannot start
     */
    @BeforeEach
    void setUp() throws Exception {
        server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        server.createContext("/", exchange -> {
            String path = exchange.getRequestURI().getPath();
            bodyByPath.put(path, new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8));
            String auth = exchange.getRequestHeaders().getFirst("Authorization");
            if (auth != null) authByPath.put(path, auth);
            int status = statusByPath.getOrDefault(path, 200);
            byte[] answer = "ok".getBytes(StandardCharsets.UTF_8);
            exchange.sendResponseHeaders(status, answer.length);
            exchange.getResponseBody().write(answer);
            exchange.close();
        });
        server.start();
        service = new EngineFeedDeliveryService();
        service.url = Optional.of("http://127.0.0.1:" + server.getAddress().getPort());
        service.user = Optional.of("pos");
        service.password = Optional.of("secret");
        service.timeoutMillis = 5000;
        engineFeedService = mock(EngineFeedService.class);
        service.engineFeedService = engineFeedService;
    }

    /**
     * Stops the fake engine.
     */
    @AfterEach
    void tearDown() {
        server.stop(0);
    }

    /**
     * Builds a feed row mock with the given versions.
     *
     * @param code the feed code
     * @param version the stored version
     * @param appliedVersion the acknowledged version, or null
     * @return the feed mock
     */
    private EngineFeed feed(String code, String version, String appliedVersion) {
        EngineFeed feed = mock(EngineFeed.class);
        feed.code = code;
        feed.content = "CONTENT-" + code;
        feed.version = version;
        feed.appliedVersion = appliedVersion;
        return feed;
    }

    /**
     * Builds a mocked Panache query yielding one first result.
     *
     * @param result the entity the query returns, or null
     * @return the mocked query
     */
    @SuppressWarnings("unchecked")
    private static io.quarkus.hibernate.orm.panache.PanacheQuery<EngineFeed> queryOf(EngineFeed result) {
        io.quarkus.hibernate.orm.panache.PanacheQuery<EngineFeed> query =
                mock(io.quarkus.hibernate.orm.panache.PanacheQuery.class);
        org.mockito.Mockito.when(query.firstResult()).thenReturn(result);
        return query;
    }

    /**
     * Stubs every catalog code to null except the given rows.
     *
     * @param mocked the static mock in scope
     * @param rows the feed rows present on this node
     */
    private void stubCatalog(MockedStatic<PanacheEntityBase> mocked, List<EngineFeed> rows) {
        for (EngineFeedService.FeedDef def : EngineFeedService.CATALOG) {
            EngineFeed match = rows.stream()
                    .filter(feed -> feed.code.equals(def.code())).findFirst().orElse(null);
            mocked.when(() -> EngineFeed.find("code", def.code())).thenReturn(queryOf(match));
        }
    }

    /**
     * A pending feed is POSTed verbatim with Basic auth and acknowledged on
     * the 2xx answer; absent and already-acknowledged feeds are skipped.
     */
    @Test
    void deliverPendingPostsAndAcknowledges() {
        EngineFeed pending = feed("PRODUCTS", "v2", "v1");
        EngineFeed applied = feed("STORES", "v1", "v1");
        try (MockedStatic<PanacheEntityBase> mocked = mockStatic(PanacheEntityBase.class)) {
            stubCatalog(mocked, List.of(pending, applied));
            service.deliverPending();
        }
        verify(engineFeedService).markApplied("PRODUCTS", "v2");
        assertEquals("CONTENT-PRODUCTS", bodyByPath.get("/products/import"));
        assertTrue(authByPath.get("/products/import").startsWith("Basic "));
        assertTrue(bodyByPath.keySet().stream().noneMatch(p -> p.contains("stores")));
    }

    /**
     * A non-2xx answer records the error and STOPS the walk: the feeds
     * after the failing one are not delivered this cycle (application-order
     * preservation).
     */
    @Test
    void deliverPendingStopsAtFirstFailure() {
        statusByPath.put("/products/import", 503);
        EngineFeed failing = feed("PRODUCTS", "v2", null);
        EngineFeed waiting = feed("OFFERS", "v9", null);
        try (MockedStatic<PanacheEntityBase> mocked = mockStatic(PanacheEntityBase.class)) {
            stubCatalog(mocked, List.of(failing, waiting));
            service.deliverPending();
        }
        verify(engineFeedService).markError(org.mockito.ArgumentMatchers.eq("PRODUCTS"),
                org.mockito.ArgumentMatchers.contains("HTTP 503"));
        verify(engineFeedService, never()).markApplied(org.mockito.ArgumentMatchers.eq("OFFERS"),
                org.mockito.ArgumentMatchers.any());
        assertTrue(bodyByPath.keySet().stream().noneMatch(p -> p.contains("offers")));
    }

    /**
     * An unreachable engine records the connection error without killing
     * the loop (exception arm of {@code deliver} + {@code deliverSafely}).
     */
    @Test
    void deliverSafelySurvivesUnreachableEngine() {
        service.url = Optional.of("http://127.0.0.1:1");
        EngineFeed pending = feed("PRODUCTS", "v2", null);
        try (MockedStatic<PanacheEntityBase> mocked = mockStatic(PanacheEntityBase.class)) {
            stubCatalog(mocked, List.of(pending));
            service.deliverSafely();
        }
        verify(engineFeedService).markError(org.mockito.ArgumentMatchers.eq("PRODUCTS"),
                org.mockito.ArgumentMatchers.any());
        verify(engineFeedService, never()).markApplied(org.mockito.ArgumentMatchers.any(),
                org.mockito.ArgumentMatchers.any());
    }
}

package com.intermarche.pos.service.sync;

import com.intermarche.pos.domain.EngineFeed;
import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

/**
 * Unit tests for {@link EngineFeedService}: the catalog contract (order,
 * lookup), the store upsert with its SHA-256 version short-circuit, the
 * acknowledgement and error recorders, and the hash helper. Pure unit —
 * the entity statics are intercepted with {@code mockStatic}, the rows are
 * Mockito mocks whose public fields are driven directly.
 */
class EngineFeedServiceTest {

    /** The service under test — stateless, one instance suffices. */
    private final EngineFeedService service = new EngineFeedService();

    /**
     * The catalog ships shared referentials before engine-specific feeds,
     * offers last (delivery-order doctrine).
     */
    @Test
    void catalogOrdersSharedBeforeSpecific() {
        assertEquals("STORES", EngineFeedService.CATALOG.get(0).code());
        assertEquals("OFFERS", EngineFeedService.CATALOG.get(EngineFeedService.CATALOG.size() - 1).code());
        assertTrue(indexOf("PRODUCTS") < indexOf("OFFERS"));
        assertTrue(indexOf("FAMILIES") < indexOf("PRICES"));
    }

    /**
     * Returns the catalog index of a feed code.
     *
     * @param code the feed code
     * @return the index in the catalog
     */
    private int indexOf(String code) {
        for (int i = 0; i < EngineFeedService.CATALOG.size(); i++) {
            if (EngineFeedService.CATALOG.get(i).code().equals(code)) return i;
        }
        return -1;
    }

    /**
     * {@code catalogEntry} resolves a known code (present arm) and yields
     * empty for an unknown one (absent arm).
     */
    @Test
    void catalogEntryResolvesKnownAndRejectsUnknown() {
        assertEquals("/offers/import", EngineFeedService.catalogEntry("OFFERS").orElseThrow().enginePath());
        assertTrue(EngineFeedService.catalogEntry("NOPE").isEmpty());
    }

    /**
     * {@code store} creates the row on first sight (null arm): content,
     * version and timestamp are set and persisted.
     */
    @Test
    void storeCreatesNewFeed() {
        try (MockedStatic<PanacheEntityBase> mocked = mockStatic(PanacheEntityBase.class)) {
            mocked.when(() -> EngineFeed.find("code", "OFFERS")).thenReturn(queryOf(null));
            String version = service.store("OFFERS", "CODE|TYPE\nA|X\n");
            assertEquals(EngineFeedService.sha256("CODE|TYPE\nA|X\n"), version);
        }
    }

    /**
     * {@code store} on an unchanged content returns the same version
     * without touching the row (short-circuit arm).
     */
    @Test
    void storeSkipsUnchangedContent() {
        EngineFeed existing = mock(EngineFeed.class);
        existing.code = "OFFERS";
        existing.version = EngineFeedService.sha256("SAME");
        try (MockedStatic<PanacheEntityBase> mocked = mockStatic(PanacheEntityBase.class)) {
            mocked.when(() -> EngineFeed.find("code", "OFFERS")).thenReturn(queryOf(existing));
            String version = service.store("OFFERS", "SAME");
            assertEquals(existing.version, version);
            verify(existing, never()).persist();
        }
    }

    /**
     * {@code store} on a changed content refreshes the row (changed arm):
     * new content, new version, new timestamp, persisted.
     */
    @Test
    void storeRefreshesChangedContent() {
        EngineFeed existing = mock(EngineFeed.class);
        existing.code = "OFFERS";
        existing.version = EngineFeedService.sha256("OLD");
        try (MockedStatic<PanacheEntityBase> mocked = mockStatic(PanacheEntityBase.class)) {
            mocked.when(() -> EngineFeed.find("code", "OFFERS")).thenReturn(queryOf(existing));
            String version = service.store("OFFERS", "NEW");
            assertEquals(EngineFeedService.sha256("NEW"), version);
            assertEquals("NEW", existing.content);
            assertEquals(version, existing.version);
            assertNotNull(existing.receivedAt);
            verify(existing).persist();
        }
    }

    /**
     * {@code markApplied} records the acknowledged version, stamps the
     * time and clears the error (found arm); an unknown code is a no-op
     * (null arm).
     */
    @Test
    void markAppliedRecordsAcknowledgement() {
        EngineFeed feed = mock(EngineFeed.class);
        feed.code = "OFFERS";
        feed.lastError = "old error";
        try (MockedStatic<PanacheEntityBase> mocked = mockStatic(PanacheEntityBase.class)) {
            mocked.when(() -> EngineFeed.find("code", "OFFERS")).thenReturn(queryOf(feed));
            mocked.when(() -> EngineFeed.find("code", "NOPE")).thenReturn(queryOf(null));
            service.markApplied("OFFERS", "v1");
            assertEquals("v1", feed.appliedVersion);
            assertNotNull(feed.appliedAt);
            assertNull(feed.lastError);
            verify(feed).persist();
            service.markApplied("NOPE", "v1");
        }
    }

    /**
     * {@code markError} records the message, truncated to the column size
     * (long arm), and ignores an unknown code (null arm).
     */
    @Test
    void markErrorRecordsTruncatedMessage() {
        EngineFeed feed = mock(EngineFeed.class);
        feed.code = "OFFERS";
        try (MockedStatic<PanacheEntityBase> mocked = mockStatic(PanacheEntityBase.class)) {
            mocked.when(() -> EngineFeed.find("code", "OFFERS")).thenReturn(queryOf(feed));
            mocked.when(() -> EngineFeed.find("code", "NOPE")).thenReturn(queryOf(null));
            service.markError("OFFERS", "x".repeat(600));
            assertEquals(500, feed.lastError.length());
            verify(feed).persist();
            service.markError("NOPE", "err");
        }
    }

    /**
     * {@code sha256} produces the well-known digest of an empty string.
     */
    @Test
    void sha256MatchesKnownVector() {
        assertEquals("e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
                EngineFeedService.sha256(""));
    }

    /**
     * Builds a mocked Panache query yielding one first result.
     *
     * @param result the entity the query returns, or null
     * @return the mocked query
     */
    @SuppressWarnings("unchecked")
    private static io.quarkus.hibernate.orm.panache.PanacheQuery<EngineFeed> queryOf(EngineFeed result) {
        io.quarkus.hibernate.orm.panache.PanacheQuery<EngineFeed> query =
                mock(io.quarkus.hibernate.orm.panache.PanacheQuery.class);
        org.mockito.Mockito.when(query.firstResult()).thenReturn(result);
        return query;
    }
}

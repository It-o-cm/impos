# impos-hw — handoff for lot 4 (POS-facing HTTP daemon)

## What exists (lots 1-3, all proven on the physical POS on 2026-09-04)
- Pure Java 21, no dependency, single jar: `mvn package` -> `target/impos-hw-0.1.0-SNAPSHOT.jar`.
- `discover`: sysfs inventory + 3-level catalog resolution (VID_PID / VID / PRODUCT_KEYWORD) + passive bus evidence.
- `printer-test`, `drawer-test`: ESC/POS on `/dev/usb/lp0` (`driver/ReceiptPrinter`, `EscPosPrinter`, `DrawerProbe`).
- `scan-watch`, `scan-bridge`: IBM hand-held HID scanner (`driver/BarcodeScanner`, `IbmHidScanner`) -> `PosScanPublisher`
  -> `POST /api/pos/scan` (text/plain body = code).

## Facts about the POS (openSUSE Leap 15.6, offline, root@10.63.31.152, work dir /root/Henri)
- Printer: Epson TM-H6000V, 04b8:0202, serial 583547460027320000, node /dev/usb/lp0 (usblp on a vendor-class interface).
  Answers GS I 66/67 and DLE EOT 1/2/4. Code page 858 validated.
- Cash drawer: present, on the printer's DK connector. Measured with `drawer-test` on 2026-09-07: output 0, pin 3 low at
  rest, high once open -> open = high. No other wiring; the daemon pulses the connector and reads pin 3.
- Scanner: Zebra/Symbol 05e0:0890, serial 19257010552664, IBM hand-held USB mode (two HID interfaces, usage page 0xff45).
  hidraw number changes at every plug -> always locate by identity 05e0:0890:19257010552664 (see Main.locateScannerNode).
  Report: 12 | len | symbology (03 = EAN-13) | flags | one binary digit per byte | 16.
- Customer display: Diebold Nixdorf BA9x, 2f7c:6003, hidraw, usage page 0x80 — protocol not known yet, NOT in scope.
- TPE: Verifone P400, 11ca:0300, /dev/ttyACM0 — protocol depends on the payment application, NOT in scope.
- 6 native UARTs ttyS0-5, nothing known on them. No scale.

## Lot 4 — what to build
1. A `serve` command: one process that
   - runs the scan bridge in a background thread (existing `IbmHidScanner` + `PosScanPublisher`),
   - listens on HTTP (jdk.httpserver, still no dependency; port and POS URL configurable),
   - implements EXACTLY the surface impos' hardware rest-client calls today. The contract lives in impos:
     `ui/hardware/RealHardwareResource` (current in-process stub), the `@RegisterRestClient` hardware client it wraps,
     and `src/mock/.../MockHardwareResource` (the test double of the same surface, incl. POST /drawer/close and
     GET /printer/content). Read those three before writing any endpoint.
   - printing goes through `driver/ReceiptPrinter` on the node chosen by discovery (`Main.printerNode`);
     drawer endpoints answer CLOSED / no-op; display endpoints answer 501 or log-only; anything unbound answers
     503 NO_DEVICE_BOUND so impos shows its degraded hardware banner.
2. Keep the CLI commands working; `serve` is an addition.
3. Rules of the house: English code and comments, Javadoc on EVERY method (constructors, private, overrides), no
   single-class packages, strict scope, no git operations.

## Not in scope yet (lot 5)
Pull of HARDWARE_PROFILES from the store node (6th referential domain), inventory outbox, persisted bindings.

package com.intermarche.hw.driver;

import java.io.IOException;
import java.lang.foreign.Arena;
import java.lang.foreign.FunctionDescriptor;
import java.lang.foreign.Linker;
import java.lang.foreign.MemorySegment;
import java.lang.foreign.SymbolLookup;
import java.lang.foreign.ValueLayout;
import java.lang.invoke.MethodHandle;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.function.Consumer;

/**
 * The payment client of the till, driven through the vendor's documented interface.
 *
 * <p>The payment terminal is not driven by the POS: a certified client process owns the
 * reader and the bank dialogue, and the POS talks to that process through
 * {@code libWCL_DLL.so}. Five functions make the whole interface — start the client,
 * send a message, wait for one, read it, stop the client — and the library takes care of
 * starting and stopping the client executable itself.
 *
 * <p>Messages are ASCII, a flat sequence of {@code {TAG}value} with no separator: the
 * value of a tag runs to the opening brace of the next one. Two tags are always present,
 * {@code {SV}} the service code and {@code {CD}} the command code, and the service code
 * must ALSO be passed alongside the message — the library checks the two agree.
 * {@code {SS}}, {@code {PS}} and {@code {F}} are added by the library itself, which is
 * why a message written straight to the lower transport is rejected: it never gets them.
 *
 * <p>Two constraints come from the library, not from us. The client's files are all
 * relative, so the JVM must run with its working directory set to the client's
 * directory. And {@code java.lang.foreign} is final only from Java 22 on, which is why
 * this project builds for a later release than the POS it serves.
 */
public final class WimClient implements AutoCloseable {

    /** The vendor library, relative to the client directory. */
    public static final String LIBRARY = "libWCL_DLL.so";

    /** Émission or wait succeeded. */
    public static final int OK = 0;

    /** The client is stopped. */
    public static final int ERROR_EXEC = 1;

    /** The message syntax is wrong. */
    public static final int ERROR_SYNTAX_1 = 3;

    /** The message syntax is wrong. */
    public static final int ERROR_SYNTAX_2 = 4;

    /** An operation is already running; the message was ignored, do not give up. */
    public static final int ERROR_BUSY = 5;

    /** An abort was refused at this stage; the message was ignored. */
    public static final int ERROR_CHRONO = 6;

    /** No message available from the client. */
    public static final int NO_MESSAGE = 7;

    /** Fatal error. */
    public static final int ERROR_INTERNAL = 8;

    /** Size the vendor requires for a receiving buffer: 20 KB plus one byte. */
    private static final int RECEIVE_BUFFER = 20 * 1024 + 1;

    /**
     * Size of a sending buffer, generous on purpose: the library APPENDS its own tags
     * to the message in place, so the buffer is a workspace and not a payload.
     */
    private static final int SEND_BUFFER = 4096;

    /** Longest service code the interface exchanges. */
    private static final int SERVICE_CODE_BUFFER = 32;

    /**
     * Tag carrying the result code of a completed request.
     *
     * <p>It is what tells a final answer from a progress message: while a request runs,
     * the client pushes display messages of its own, and only the message that concludes
     * the request carries a result.
     */
    private static final String RESULT_TAG = "{RS}";

    /** Client type; the specification fixes it. */
    private static final int TYPE_CLIENT = 1;

    /** Event mode; the specification fixes it. */
    private static final int MODE_EVENT = 1;

    /** Interface mode; the specification fixes it. */
    private static final int MODE_INTERFACE = 0;

    /** Debug level; the specification fixes it. */
    private static final int DEBUG_LEVEL = 1;

    /** Trace file size limit, in KB — the specification demands more than one megabyte. */
    private static final int TRACE_MODULO_KB = 4096;

    /** Language; the specification fixes it at 250, French. */
    private static final int LANGUAGE_FRENCH = 250;

    /** Echo mode of what the reader displays. */
    private static final int MODE_ECHO = 0;

    /** Maximum wait for a message, in seconds; the specification recommends 20. */
    private static final int MESSAGE_TIMEOUT_SECONDS = 20;

    /** Offline mode; the specification fixes it. */
    private static final int MODE_OFFLINE = 0;

    /** Sealing; the specification fixes it. */
    private static final int SEALING = 0;

    /** Days kept; the specification fixes it. */
    private static final int DAYS_KEPT = 0;

    /** The arena owning the library handle and the buffers. */
    private final Arena arena = Arena.ofConfined();

    /** Where the client narrates the dialogue. */
    private final Consumer<String> log;

    /** The client's own directory. */
    private final Path clientDirectory;

    /** Holds the instance identifier the library fills in at start-up. */
    private final MemorySegment instanceHolder = arena.allocate(ValueLayout.JAVA_INT);

    /** {@code SWimApiOpen}. */
    private final MethodHandle open;

    /** {@code SWimApiSendMessage}. */
    private final MethodHandle send;

    /** {@code SWimApiWaitSynchro}. */
    private final MethodHandle waitSynchro;

    /** {@code SWimApiGetMessage}. */
    private final MethodHandle get;

    /** {@code SWimApiClose}. */
    private final MethodHandle closeHandle;

    /** Whether the client was started by this object. */
    private boolean started;

    /**
     * Loads the vendor library from a client directory.
     *
     * @param clientDirectory the client's own directory, holding the library and its
     *                        {@code W*} folders
     * @param log             destination of the dialogue log lines
     * @throws IOException if the library is not there or lacks the expected symbols
     */
    public WimClient(Path clientDirectory, Consumer<String> log) throws IOException {
        this.log = log;
        this.clientDirectory = clientDirectory;
        Path library = clientDirectory.resolve(LIBRARY);
        if (!Files.isReadable(library)) {
            throw new IOException("vendor library not found: " + library);
        }
        SymbolLookup lookup = SymbolLookup.libraryLookup(library, arena);
        Linker linker = Linker.nativeLinker();
        this.open = bind(linker, lookup, "SWimApiOpen", FunctionDescriptor.of(
                ValueLayout.JAVA_INT,
                ValueLayout.ADDRESS, ValueLayout.JAVA_INT, ValueLayout.JAVA_INT,
                ValueLayout.JAVA_INT, ValueLayout.JAVA_INT, ValueLayout.ADDRESS,
                ValueLayout.JAVA_INT, ValueLayout.JAVA_INT, ValueLayout.JAVA_INT,
                ValueLayout.ADDRESS, ValueLayout.JAVA_INT, ValueLayout.JAVA_INT,
                ValueLayout.JAVA_INT, ValueLayout.ADDRESS, ValueLayout.JAVA_INT,
                ValueLayout.ADDRESS, ValueLayout.JAVA_INT));
        this.send = bind(linker, lookup, "SWimApiSendMessage", FunctionDescriptor.of(
                ValueLayout.JAVA_INT, ValueLayout.JAVA_INT, ValueLayout.ADDRESS,
                ValueLayout.ADDRESS, ValueLayout.ADDRESS));
        this.waitSynchro = bind(linker, lookup, "SWimApiWaitSynchro", FunctionDescriptor.of(
                ValueLayout.JAVA_INT, ValueLayout.JAVA_INT, ValueLayout.JAVA_LONG));
        this.get = bind(linker, lookup, "SWimApiGetMessage", FunctionDescriptor.of(
                ValueLayout.JAVA_INT, ValueLayout.JAVA_INT, ValueLayout.ADDRESS,
                ValueLayout.ADDRESS, ValueLayout.ADDRESS));
        this.closeHandle = bind(linker, lookup, "SWimApiClose", FunctionDescriptor.of(
                ValueLayout.JAVA_INT, ValueLayout.JAVA_INT, ValueLayout.JAVA_INT));
    }

    /**
     * Binds one native function, naming the missing symbol rather than failing blankly.
     *
     * @param linker     the native linker
     * @param lookup     the loaded library
     * @param symbol     the symbol name
     * @param descriptor its signature
     * @return the handle
     * @throws IOException if the library does not carry that symbol
     */
    private static MethodHandle bind(Linker linker, SymbolLookup lookup, String symbol,
            FunctionDescriptor descriptor) throws IOException {
        MemorySegment address = lookup.find(symbol)
                .orElseThrow(() -> new IOException("symbol not found in " + LIBRARY + ": " + symbol));
        return linker.downcallHandle(address, descriptor);
    }

    /**
     * Starts the payment client.
     *
     * <p>Every fixed parameter of the seventeen the specification defines is a named
     * constant here rather than a bare literal, because "TOUJOURS VALORISÉ À 1" is a
     * requirement of the interface, not a choice of ours.
     *
     * @param stationId the acceptance point number
     * @return the library's result code, {@link #OK} on success
     * @throws IOException if the call itself failed
     */
    public int start(int stationId) throws IOException {
        MemorySegment fileTrace = nativeString(clientDirectory.resolve("WLOG/CLIENT").toString());
        MemorySegment path = nativeString(clientDirectory.toAbsolutePath().toString());
        try {
            int code = (int) open.invokeExact(instanceHolder, TYPE_CLIENT, MODE_EVENT,
                    MODE_INTERFACE, DEBUG_LEVEL, fileTrace, TRACE_MODULO_KB, stationId,
                    LANGUAGE_FRENCH, path, MODE_ECHO, MESSAGE_TIMEOUT_SECONDS, MODE_OFFLINE,
                    MemorySegment.NULL, SEALING, MemorySegment.NULL, DAYS_KEPT);
            started = code == OK;
            log.accept("tpe          SWimApiOpen -> " + describe(code)
                    + (started ? " (instance " + instance() + ")" : ""));
            return code;
        } catch (Throwable t) {
            throw new IOException("SWimApiOpen failed: " + t, t);
        }
    }

    /**
     * Sends one message to the payment client.
     *
     * @param serviceCode the service code, which must be the value the message carries
     *                    under its {@code {SV}} tag
     * @param message     the message, a flat sequence of {@code {TAG}value}
     * @return the library's result code
     * @throws IOException if the call itself failed
     */
    public int sendMessage(String serviceCode, String message) throws IOException {
        MemorySegment service = nativeString(serviceCode);
        // The buffer must hold the message AND the room the library needs to append the
        // tags it adds itself. Sizing it to the text is what earns "Buffer trop petit
        // pour recevoir le tag F": the length passed is a CAPACITY, not a length.
        MemorySegment buffer = arena.allocate(SEND_BUFFER);
        byte[] raw = message.getBytes(StandardCharsets.ISO_8859_1);
        MemorySegment.copy(raw, 0, buffer, ValueLayout.JAVA_BYTE, 0, raw.length);
        buffer.set(ValueLayout.JAVA_BYTE, raw.length, (byte) 0);
        MemorySegment length = arena.allocate(ValueLayout.JAVA_INT);
        length.set(ValueLayout.JAVA_INT, 0, SEND_BUFFER);
        log.accept("tpe          > [" + serviceCode + "] " + message);
        try {
            int code = (int) send.invokeExact(instance(), service, buffer, length);
            log.accept("tpe          SWimApiSendMessage -> " + describe(code));
            return code;
        } catch (Throwable t) {
            throw new IOException("SWimApiSendMessage failed: " + t, t);
        }
    }

    /**
     * Waits for a message to become available.
     *
     * @param timeoutMillis how long to wait
     * @return the library's result code, {@link #NO_MESSAGE} when nothing came
     * @throws IOException if the call itself failed
     */
    public int waitForMessage(long timeoutMillis) throws IOException {
        try {
            return (int) waitSynchro.invokeExact(instance(), timeoutMillis);
        } catch (Throwable t) {
            throw new IOException("SWimApiWaitSynchro failed: " + t, t);
        }
    }

    /**
     * Reads the message the client made available.
     *
     * @return the message, empty when none could be read
     * @throws IOException if the call itself failed
     */
    public String getMessage() throws IOException {
        MemorySegment service = arena.allocate(SERVICE_CODE_BUFFER);
        MemorySegment buffer = arena.allocate(RECEIVE_BUFFER);
        MemorySegment length = arena.allocate(ValueLayout.JAVA_INT);
        length.set(ValueLayout.JAVA_INT, 0, RECEIVE_BUFFER);
        try {
            int code = (int) get.invokeExact(instance(), service, buffer, length);
            String message = javaString(buffer);
            log.accept("tpe          < [" + javaString(service) + "] " + describe(code)
                    + (message.isEmpty() ? " (rien)" : " " + message));
            return message;
        } catch (Throwable t) {
            throw new IOException("SWimApiGetMessage failed: " + t, t);
        }
    }

    /**
     * Sends one message and waits for the answer that concludes it.
     *
     * <p>A request is not answered by a single message. While it runs, the client
     * pushes what the reader shows -- two display lines at a time, a firmware upload
     * progressing, a server connection being made -- and those messages arrive on the
     * same channel as the answer. They are narrated and skipped; only the message
     * carrying {@link #RESULT_TAG} ends the exchange. The timeout is therefore the
     * budget for the WHOLE request, not for one read: a session opening that updates the
     * reader takes minutes of progress messages before it concludes.
     *
     * @param serviceCode   the service code of the request
     * @param message       the request
     * @param timeoutMillis how long to wait for the answer, progress messages included
     * @return the answer, empty when none came
     * @throws IOException if a call failed
     */
    public String exchange(String serviceCode, String message, long timeoutMillis)
            throws IOException {
        int sent = sendMessage(serviceCode, message);
        if (sent != OK) {
            return "";
        }
        long deadline = System.currentTimeMillis() + timeoutMillis;
        long remaining = timeoutMillis;
        while (remaining > 0) {
            int waited = waitForMessage(remaining);
            if (waited != OK) {
                log.accept("tpe          SWimApiWaitSynchro -> " + describe(waited));
                return "";
            }
            String answer = getMessage();
            if (answer.contains(RESULT_TAG)) {
                return answer;
            }
            remaining = deadline - System.currentTimeMillis();
        }
        log.accept("tpe          no result within " + timeoutMillis + " ms");
        return "";
    }

    /** {@inheritDoc} */
    @Override
    public void close() {
        if (started) {
            try {
                int code = (int) closeHandle.invokeExact(instance(), 0);
                log.accept("tpe          SWimApiClose -> " + describe(code));
            } catch (Throwable t) {
                log.accept("tpe          SWimApiClose failed: " + t);
            }
            started = false;
        }
        arena.close();
    }

    /**
     * The instance identifier the library filled in at start-up.
     *
     * @return the identifier
     */
    public int instance() {
        return instanceHolder.get(ValueLayout.JAVA_INT, 0);
    }

    /**
     * Names a result code, the numbers alone saying nothing to whoever reads the log.
     *
     * @param code the library's result code
     * @return the code with its meaning
     */
    public static String describe(int code) {
        String meaning = switch (code) {
            case OK -> "OK";
            case ERROR_EXEC -> "client stopped";
            case ERROR_SYNTAX_1, ERROR_SYNTAX_2 -> "message syntax rejected";
            case ERROR_BUSY -> "an operation is already running";
            case ERROR_CHRONO -> "abort refused at this stage";
            case NO_MESSAGE -> "no message available";
            case ERROR_INTERNAL -> "fatal error";
            default -> "unknown code";
        };
        return code + " (" + meaning + ")";
    }

    /**
     * Copies a message into native memory, NUL-terminated.
     *
     * <p>Single-byte encoding on purpose: the protocol is ASCII, and a character widened
     * to two bytes would shift every field after it.
     *
     * @param message the message to copy
     * @return the native buffer holding it
     */
    private MemorySegment nativeString(String message) {
        byte[] raw = message.getBytes(StandardCharsets.ISO_8859_1);
        MemorySegment buffer = arena.allocate(raw.length + 1L);
        MemorySegment.copy(raw, 0, buffer, ValueLayout.JAVA_BYTE, 0, raw.length);
        buffer.set(ValueLayout.JAVA_BYTE, raw.length, (byte) 0);
        return buffer;
    }

    /**
     * Reads a NUL-terminated message out of native memory.
     *
     * @param buffer the native buffer
     * @return the message, empty when the buffer starts with a NUL
     */
    private static String javaString(MemorySegment buffer) {
        int length = 0;
        while (length < buffer.byteSize() && buffer.get(ValueLayout.JAVA_BYTE, length) != 0) {
            length++;
        }
        byte[] raw = new byte[length];
        MemorySegment.copy(buffer, ValueLayout.JAVA_BYTE, 0, raw, 0, length);
        return new String(raw, StandardCharsets.ISO_8859_1);
    }
}

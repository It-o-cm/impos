package com.intermarche.pos.ui.invoice;

import com.intermarche.pos.ui.DrawerMustBeClosed;
import com.intermarche.pos.ui.PosState;
import io.quarkus.qute.Location;
import io.quarkus.qute.Template;
import io.quarkus.qute.TemplateInstance;
import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.FormParam;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import java.net.URI;

/**
 * JAX-RS resource of the invoice screen, under its own {@code /invoice} prefix.
 *
 * <p>Three steps and one commitment: naming the ticket, naming the customer and
 * looking at the finished document are all free — they write nothing and draw no
 * number — while {@code /invoice/issue} is the point of no return. That is what makes
 * the abandon of {@code LC-08-04-14} real rather than nominal.
 *
 * <p>Everything before the issue is a GET or a form POST that lands back on the same
 * screen; the issue redirects to the issued document, so a browser refresh re-reads a
 * document instead of issuing a second one.
 */
@Path("/invoice")
@DrawerMustBeClosed
public class InvoiceResource {

    /** The register state, carrying the invoice sub-state the screen reads. */
    @Inject
    PosState state;

    /** The invoice flow. */
    @Inject
    InvoiceService invoiceService;

    /** The screen where the ticket and the customer are named. */
    @Inject
    @Location("invoice-request")
    Template requestPage;

    /** The document itself, laid out as it will be issued. */
    @Inject
    @Location("invoice")
    Template documentPage;

    /**
     * Opens the screen on its first step, with the closed-ticket shortlist and the
     * register's last ticket pre-filled.
     *
     * @return the request page
     */
    @GET
    @Produces(MediaType.TEXT_HTML)
    public TemplateInstance showInvoiceScreen() {
        invoiceService.open();
        return requestPage.data("state", state);
    }

    /**
     * Names the ticket the document will state.
     *
     * @param ticketNumber the number of the closed ticket to bill
     * @return the request page, on the customer step when the ticket was found
     */
    @POST
    @jakarta.ws.rs.Path("/ticket")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.TEXT_HTML)
    public TemplateInstance chooseTicket(@FormParam("ticketNumber") String ticketNumber) {
        invoiceService.chooseTicket(ticketNumber);
        return requestPage.data("state", state);
    }

    /**
     * Names the ticket from the shortlist, without typing its number.
     *
     * @param ticketNumber the number of the closed ticket to bill
     * @return the request page, on the customer step
     */
    @GET
    @jakarta.ws.rs.Path("/ticket/{ticketNumber}")
    @Produces(MediaType.TEXT_HTML)
    public TemplateInstance pickTicket(@PathParam("ticketNumber") String ticketNumber) {
        invoiceService.chooseTicket(ticketNumber);
        return requestPage.data("state", state);
    }

    /**
     * Looks customers up by name.
     *
     * @param search what the operator typed
     * @return the request page, carrying the matches
     */
    @POST
    @jakarta.ws.rs.Path("/customer/search")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.TEXT_HTML)
    public TemplateInstance searchCustomers(@FormParam("search") String search) {
        invoiceService.searchCustomers(search);
        return requestPage.data("state", state);
    }

    /**
     * Names the customer the document is addressed to.
     *
     * @param id the database id of the customer
     * @return the request page, on the review step
     */
    @GET
    @jakarta.ws.rs.Path("/customer/{id}")
    @Produces(MediaType.TEXT_HTML)
    public TemplateInstance chooseCustomer(@PathParam("id") Long id) {
        invoiceService.chooseCustomer(id);
        return requestPage.data("state", state);
    }

    /**
     * Opens the form that creates a customer at the register.
     *
     * @return the request page, showing the creation form
     */
    @GET
    @jakarta.ws.rs.Path("/customer/new")
    @Produces(MediaType.TEXT_HTML)
    public TemplateInstance newCustomer() {
        state.invoice.creatingCustomer = true;
        state.invoice.error = "";
        state.touch();
        return requestPage.data("state", state);
    }

    /**
     * Creates the customer and addresses the document to it.
     *
     * @param companyName the business name
     * @param contactName the contact's name
     * @param street      the street line
     * @param postalCode  the postal code
     * @param city        the town
     * @param siret       the SIRET
     * @param vatNumber   the intra-community VAT number
     * @param phone       the telephone number
     * @param email       the electronic address
     * @return the request page, on the review step when the creation worked
     */
    @POST
    @jakarta.ws.rs.Path("/customer/create")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.TEXT_HTML)
    public TemplateInstance createCustomer(@FormParam("companyName") String companyName,
            @FormParam("contactName") String contactName,
            @FormParam("street") String street,
            @FormParam("postalCode") String postalCode,
            @FormParam("city") String city,
            @FormParam("siret") String siret,
            @FormParam("vatNumber") String vatNumber,
            @FormParam("phone") String phone,
            @FormParam("email") String email) {
        invoiceService.createCustomer(companyName, contactName, street, postalCode, city,
                siret, vatNumber, phone, email);
        return requestPage.data("state", state);
    }

    /**
     * Shows the document as it will be issued — no number yet, nothing written.
     *
     * @return the document page, or the request page when a step is still missing
     */
    @GET
    @jakarta.ws.rs.Path("/preview")
    @Produces(MediaType.TEXT_HTML)
    public TemplateInstance preview() {
        InvoiceDocument document = invoiceService.preview();
        if (document == null) {
            return requestPage.data("state", state);
        }
        return documentPage.data("document", document).data("issued", false);
    }

    /**
     * Issues the document: draws its number, writes it and prints it.
     *
     * @return a redirect to the issued document, or back to the screen on refusal
     */
    @POST
    @jakarta.ws.rs.Path("/issue")
    public Response issue() {
        Long issued = invoiceService.issue();
        if (issued == null) {
            return Response.seeOther(URI.create("/invoice/preview")).build();
        }
        return Response.seeOther(URI.create("/invoice/document/" + issued)).build();
    }

    /**
     * Shows an issued document again.
     *
     * @param id the database id of the document
     * @return the document page, or the request page when there is no such document
     */
    @GET
    @jakarta.ws.rs.Path("/document/{id}")
    @Produces(MediaType.TEXT_HTML)
    public TemplateInstance showDocument(@PathParam("id") Long id) {
        InvoiceDocument document = invoiceService.issued(id);
        if (document == null) {
            return requestPage.data("state", state);
        }
        return documentPage.data("document", document).data("issued", true);
    }

    /**
     * Gives up the document being prepared and leaves the screen.
     *
     * @return a redirect to the sale screen
     */
    @GET
    @jakarta.ws.rs.Path("/abandon")
    public Response abandon() {
        invoiceService.abandon();
        return Response.seeOther(URI.create("/")).build();
    }
}

Client 13.1.7 OS Linux Rocky v9

Environnement : 
Adresse itm-integration.verifone.com
Ports 23040 et 23041
Ilot label A99054
